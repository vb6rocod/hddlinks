#!/usr/local/bin/Resource/www/cgi-bin/php
<?php echo "<?xml version='1.0' encoding='UTF8' ?>";
$host = "http://127.0.0.1/cgi-bin";
?>
<rss version="2.0" xmlns:media="http://purl.org/dc/elements/1.1/" xmlns:dc="http://purl.org/dc/elements/1.1/">
<mediaDisplay name="threePartsView" itemBackgroundColor="0:0:0" backgroundColor="0:0:0" sideLeftWidthPC="0" itemImageXPC="5" itemXPC="20" itemYPC="20" itemWidthPC="65" capWidthPC="70" unFocusFontColor="101:101:101" focusFontColor="255:255:255" idleImageXPC="5" idleImageYPC="5" idleImageWidthPC="8" idleImageHeightPC="10">
        <idleImage>image/POPUP_LOADING_01.png</idleImage>
        <idleImage>image/POPUP_LOADING_02.png</idleImage>
        <idleImage>image/POPUP_LOADING_03.png</idleImage>
        <idleImage>image/POPUP_LOADING_04.png</idleImage>
        <idleImage>image/POPUP_LOADING_05.png</idleImage>
        <idleImage>image/POPUP_LOADING_06.png</idleImage>
        <idleImage>image/POPUP_LOADING_07.png</idleImage>
        <idleImage>image/POPUP_LOADING_08.png</idleImage>
		<backgroundDisplay>
			<image  offsetXPC=0 offsetYPC=0 widthPC=100 heightPC=100>
			image/mele/backgd.jpg
			</image>
		</backgroundDisplay>
		<image  offsetXPC=0 offsetYPC=2.8 widthPC=100 heightPC=15.6>
		image/mele/rss_title.jpg
		</image>
		<text  offsetXPC=40 offsetYPC=8 widthPC=35 heightPC=10 fontSize=20 backgroundColor=-1:-1:-1 foregroundColor=255:255:255>
  Revision3 SD 480p
		</text>
</mediaDisplay>
<channel>
	<title>SD</title>
	<link>./revision3.rss</link>

<item>
<title>Anime TV</title>
<link>http://revision3.com/animetv/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/animetv/animetv.jpg" width="120" height="120" />
</item>
<item>
<title>App Judgement</title>
<link>http://revision3.com/appjudgement/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/appjudgment/appjudgment.jpg" width="120" height="120" />
</item>
<item>
<title>ByteJacker</title>
<link>http://revision3.com/bytejacker/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/bytejacker/bytejacker.jpg" width="120" height="120" />
</item>
<item>
<title>CO-Op</title>
<link>http://revision3.com/coop/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/coop/coop.jpg" width="120" height="120" />
</item>
<item>
<title>Digg Dialogg</title>
<link>http://revision3.com/diggdialogg/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/diggdialogg/diggdialogg.jpg" width="120" height="120" />
</item>
<item>
<title>DiggNation</title>
<link>http://revision3.com/diggnation/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/diggnation/diggnation.jpg" width="120" height="120" />
</item>
<item>
<title>Film Riot</title>
<link>http://revision3.com/filmriot/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/filmriot/filmriot.jpg" width="120" height="120" />
</item>
<item>
<title>Hak 5</title>
<link>http://revision3.com/hak5/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/hak5/hak5.jpg" width="120" height="120" />
</item>
<item>
<title>HD Nation</title>
<link>http://revision3.com/hdnation/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/hdnation/hdnation.jpg" width="120" height="120" />
</item>
<item>
<title>iFanboy</title>
<link>http://revision3.com/ifanboy/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/ifanboy/ifanboy.jpg" width="120" height="120" />
</item>
<item>
<title>INST MSGS</title>
<link>http://revision3.com/instmsgs/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/instmsgs/instmsgs.jpg" width="120" height="120" />
</item>
<item>
<title>LandLine TV</title>
<link>http://revision3.com/landlinetv/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/landlinetv/landlinetv.jpg" width="120" height="120" />
</item>
<item>
<title>Pixel Perfect</title>
<link>http://revision3.com/pixelperfect/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/pixelperfect/pixelperfect.jpg" width="120" height="120" />
</item>
<item>
<title>ROFL</title>
<link>http://revision3.com/rofl/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/rofl/rofl.jpg" width="120" height="120" />
</item>
<item>
<title>Scam School</title>
<link>http://revision3.com/scamschool/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/scamschool/scamschool.jpg" width="120" height="120" />
</item>
<item>
<title>Tekzilla</title>
<link>http://revision3.com/tekzilla/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/tekzilla/tekzilla.jpg" width="120" height="120" />
</item>
<item>
<title>Totally Rad Show</title>
<link>http://revision3.com/trs/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/trs/trs.jpg" width="120" height="120" />
</item>
<item>
<title>Web Zeroes</title>
<link>http://revision3.com/webzeroes/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/webzeroes/webzeroes.jpg" width="120" height="120" />
</item>
<item>
<title>XLR8RTV</title>
<link>http://revision3.com/xlr8rtv/feed/MP4-Large</link>
<media:thumbnail url="http://bitcast-a.bitgravity.com/revision3/images/shows/xlr8rtv/xlr8rtv.jpg" width="120" height="120" />
</item>

</channel>
</rss>
