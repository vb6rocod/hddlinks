#!/usr/local/bin/Resource/www/cgi-bin/php
<?php
function str_between($string, $start, $end){ 
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
function enc($string) {
  $local3="";
  $arg1=strlen($string);
  $arg2="mediadirect";
  $l_arg2=strlen($arg2);
  $local4=0;
  while ($local4 < $arg1) {
    $m1=ord($string[$local4]);
    $m2=ord($arg2[$local4 % $l_arg2]);
    $local3=$local3.chr($m1 ^ $m2);
    $local4++;
  }
  return $local3;
}
//http://www.dolcetv.ro/tv-live-Mooz-RO-115?ajaxrequest=1
//$link = $_GET["file"];
$query = $_GET["file"];
if($query) {
   $queryArr = explode(',', $query);
   $link = urldecode($queryArr[0]);
   $buf = $queryArr[1];
}
/*
$s="http://www.tastez.ro/tv.php?query=voyo&chn=".$link;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $s);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch,CURLOPT_REFERER,"http://www.dolcetv.ro");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
$conn1=str_between($html,"connectionArgs&quot;:[","]");
$conn1=str_replace("&quot;","",$conn1);
$t1=explode(",",$conn1);
//print_r($t1);
$c1=" -C O:1";
$c2=" -C NN:0:".$t1[0].".000000";
$c3=" -C NS:1:".$t1[1];
$c4=" -C NN:2:".$t1[2].".000000";
$c5=" -C NS:3:".$t1[3];
$c6=" -C O:0 ";
*/
// -v -x 15348 -w 2324d94075f150cad1ea0e09b5513924e7cc8b382656a1e38109e41237eb4373 -p http://voyo.ro -W http://voyo.ro/static/shared/app/flowplayer/13-flowplayer.cluster-3.2.1-01-004.swf
// -r "rtmp://185.133.64.234/voyoro_ios_live10/_definst_/voyoro_ios_live10-3.stream?eyJtZWQiOjYwNjIyNTAyLCJsaWMiOiJkMGZjOTkzOTI5OWJkYjVhMzE5OTFlMGMxYzEzZmFkMSIsInByb2QiOjMxOTcsImRldiI6IjJkMWVmM2UyOTIxNGVkZjliMTEzODk5YmY2OTQ5OWI1IiwiYWlkIjoiIn0="
/*
$rtmp=str_between($html,"host&quot;:&quot;","&quot;");
$w="http://voyo.ro/static/shared/app/flowplayer/13-flowplayer.cluster-3.2.1-01-004.swf";
$y="linear3?".str_between($html,"{0}?","&quot;");
$l="-b ".$buf;
$l="";
$exec=$l.' -q -v -x 15348 -w 2324d94075f150cad1ea0e09b5513924e7cc8b382656a1e38109e41237eb4373 ';
$exec=$exec.'-W "'.$w.'" ';
$exec=$exec.$c1.$c2.$c3.$c4.$c5.$c6;
$exec=$exec.'-y "'.$y.'" -r '.$rtmp;
*/
//$exec=str_replace(" ","%20",$exec);
//echo $exec;
//$html = file_get_contents("http://cgi.somee.com/vtok.php");
//$id_t = str_between($html,'##','##' );
//   $token =str_replace("\/","/",$id_t);
$html = file_get_contents("http://hd4all.ml/d/vtok.php");
$id_t = str_between($html,'##','##' );
   $id_t =str_replace("\/","/",$id_t);
   $l="".urldecode($id_t)."";
   $token = base64_decode($l);
   //$l="".$link."?".$l."";
//echo $token;
//die();
$out=" -v -x 15348 -w 2324d94075f150cad1ea0e09b5513924e7cc8b382656a1e38109e41237eb4373 -p http://voyo.ro";
$out .=" -W http://voyo.ro/static/shared/app/flowplayer/13-flowplayer.cluster-3.2.1-01-004.swf -r ".$link."?".$token;

$out="#!/bin/sh
cat <<EOF
Content-type: video/mp4

EOF
exec /usr/local/etc/www/cgi-bin/scripts/rtmpdump ".$out;
$fp = fopen('/usr/local/etc/www/cgi-bin/scripts/util/m.cgi', 'w');
fwrite($fp, $out);
fclose($fp);
exec("chmod +x /usr/local/etc/www/cgi-bin/scripts/util/m.cgi");
sleep (1);
$link="http://127.0.0.1/cgi-bin/scripts/util/m.cgi?".mt_rand();
print $link;

//$l="Rtmp-options:-b ".$buf;
//$l="Rtmp-options:";
//$l=$l." -W ".$w;
//$l=$l.$c1.$c2.$c3.$c4.$c5.$c6;
//$l=$l."-y ".$y;
//$l=$l.",".$rtmp;
//$l=str_replace(" ","%20",$l);
print $exec;

?>
