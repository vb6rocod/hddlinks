# hddlinks_MP
hddlinks for MP

Vesiunea hddlinks pentru media playerele cu cip Realtek (1073-1186).
Necesita firmware custom. Prin intermediul aplicatiei puteti viziona filme, seriale, clipuri etc.
Dupa aproape 10 ani de suport am cam ajuns la final. O sa mai acord suport doar ocazional.
Va recomand sa treceti la playere cu Android, ofera mai multe posibilitati.
