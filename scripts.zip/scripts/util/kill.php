#!/usr/local/bin/Resource/www/cgi-bin/php
<?php
exec ("killall m3u8.php");
exec ("killall m3u8yt.php");
exec ("killall m3u8p.php");
exec ("killall m3u8g.php");
exec ("killall spyce.php");
exec ("killall ts.php");
exec ("killall filmon_link.php");
exec ("killall adevarul_link.php");
exec ("killall arconaitv_link.php");
exec ("killall rtmpdump");
exec ("killall wget");
?>
