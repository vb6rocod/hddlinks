#!/usr/local/bin/Resource/www/cgi-bin/php
<?php
function str_between($string, $start, $end){ 
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
$link = $_GET["file"];
$link=urldecode($link);
if (strpos($link,"http") === false) {
$url="http://www.online-filmek.org/surl/urls.php?surl=".$link;
$url1="http://adf.ly/1431126/".$url;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER,$url1);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_NOBODY, true);
  $h1 = curl_exec($ch);

  $t1=explode("Location:",$h1);
  $t2=explode("\n",$t1[1]);
  $l=trim($t2[0]);
  if (strpos($l,"zixshare") !== false) {
  //echo $l;
  $movie=file_get_contents("http://127.0.0.1/cgi-bin/scripts/filme/php/link1.php?file=".urlencode($l));
  $movie="http://127.0.0.1/cgi-bin/scripts/util/wget.cgi?link=".$movie.";";
  } else {
  $movie=file_get_contents("http://127.0.0.1/cgi-bin/scripts/filme/php/link1.php?file=".urlencode($l));
  }
} else {
  $movie=file_get_contents("http://127.0.0.1/cgi-bin/scripts/filme/php/link1.php?file=".urlencode($link));
}
print $movie;
?>
