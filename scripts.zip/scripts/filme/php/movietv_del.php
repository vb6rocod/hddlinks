#!/usr/local/bin/Resource/www/cgi-bin/php
<?php
$exec="rm -f /tmp/movietv.txt";
exec ($exec);
?>
