<?php
$videos_arr=array();

$l="http://www.seenow.ro/smarttv/placeholder/list/id/9/start/0/limit/999";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  $h=curl_exec($ch);
  curl_close($ch);

$p=json_decode($h,1);
$items=$p['items'];
$items = array_values($items);
$videos_arr = array_merge($videos_arr,$items);

$l="http://www.seenow.ro/smarttv/placeholder/list/id/60/start/0/limit/999";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  $h=curl_exec($ch);
  curl_close($ch);

$p=json_decode($h,1);
$items=$p['items'];
$items = array_values($items);
$videos_arr = array_merge($videos_arr,$items);

$l="http://www.seenow.ro/smarttv/placeholder/list/id/62/start/0/limit/999";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  $h=curl_exec($ch);
  curl_close($ch);

$p=json_decode($h,1);
$items=$p['items'];
$items = array_values($items);
$videos_arr = array_merge($videos_arr,$items);

$l="http://www.seenow.ro/smarttv/placeholder/list/id/564/start/0/limit/999";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  $h=curl_exec($ch);
  curl_close($ch);

$p=json_decode($h,1);
$items=$p['items'];
$items = array_values($items);
$videos_arr = array_merge($videos_arr,$items);

$l="http://www.seenow.ro/smarttv/placeholder/list/id/5514/start/0/limit/999";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  $h=curl_exec($ch);
  curl_close($ch);

$p=json_decode($h,1);
$items=$p['items'];
$items = array_values($items);
$videos_arr = array_merge($videos_arr,$items);

$l="http://www.seenow.ro/smarttv/placeholder/list/id/5658/start/0/limit/999";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  $h=curl_exec($ch);
  curl_close($ch);

$p=json_decode($h,1);
$items=$p['items'];
$items = array_values($items);
$videos_arr = array_merge($videos_arr,$items);

?>