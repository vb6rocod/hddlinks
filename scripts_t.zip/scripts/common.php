<?php
$t1 = dirname($_SERVER['SCRIPT_FILENAME']);
$t1 = substr($t1, 0, strripos($t1,'/scripts'));
if (file_exists("/data/data/ru.kslabs.ksweb/tmp/"))
  $base_cookie="/data/data/ru.kslabs.ksweb/tmp/";
else
  $base_cookie=$t1."/cookie/";
$base_pass=$t1."/parole/";
$base_fav=$t1."/data/";
$base_sub=$t1."/scripts/subs/";
$base_script=$t1."/scripts/";
?>
