<?php
if (file_exists("D:\\Program Files\\xampp\\htdocs\\mobile\\")) {
$base_cookie="D:\\Program Files\\xampp\\htdocs\\mobile\\cookie\\";
$base_pass="D:\\Program Files\\xampp\\htdocs\\mobile\\parole\\";
$base_fav="D:\\Program Files\\xampp\\htdocs\\mobile\\data\\";
$base_sub="D:\\Program Files\\xampp\\htdocs\\mobile\\scripts\\subs\\";
}
else if (file_exists("C:\\Program Files (x86)\\EasyPHP-DevServer-14.1VC9\\data\\localweb\\")) {
$base_cookie="C:\\Program Files (x86)\\EasyPHP-DevServer-14.1VC9\\data\\localweb\\cookie\\";
$base_pass="C:\\Program Files (x86)\\EasyPHP-DevServer-14.1VC9\\data\\localweb\\parole\\";
$base_fav="C:\\Program Files (x86)\\EasyPHP-DevServer-14.1VC9\\data\\localweb\\data\\";
$base_sub="C:\\Program Files (x86)\\EasyPHP-DevServer-14.1VC9\\localweb\\scripts\\subs\\";
} else {
$base_cookie="/data/data/ru.kslabs.ksweb/tmp/";
$base_pass=$_SERVER['DOCUMENT_ROOT']."/parole/";
$base_fav=$_SERVER['DOCUMENT_ROOT']."/data/";
$base_sub=$_SERVER['DOCUMENT_ROOT']."/scripts/subs/";
}
?>
