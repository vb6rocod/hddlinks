<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$noob=file_get_contents($base_cookie."n.dat");
$cookie=$base_cookie."noob.dat";
$id = $_GET["query"];
$serv = $_GET["serv"];
$hd_o = $_GET["hd"];
$title = $_GET["title"];
$subtracks = "";
if ($hd_o=="NU")
 $hd=0;
else
 $hd=1;
$tv= $_GET["tv"];
if (!$tv) {
 $l=$noob."/?".$id;
 $tv="0";
} else {
 $l=$noob."/?".$id."&tv=1";
}
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  //http://noobroom7.com/fork.php?type=flv&auth=0&loc=15&hd=0&tv=0&file=1633&start=0
  if ($hd==1) {
  if (!preg_match("/Watch in 1080p/i",$html))
    $hd=0;
  }
  $auth=str_between($html,"auth=","&");
   if ($tv=="0") {
     if ($hd==0)
     $movie= $noob."/".$serv."/".$auth."/".$id.".mp4";
     else
     $movie= $noob."/".$serv."/".$auth."/".$id."_hd.mp4";
   } else {
     if ($hd==0)
     $movie= $noob."/".$serv."/".$auth."/episode_".$id.".mp4";
     else
     $movie= $noob."/".$serv."/".$auth."/episode_".$id."_hd.mp4";
     }
//$movie=$noob."/fork.php?type=flv&auth=".$auth."&loc=".$serv."&hd=".$hd."&tv=".$tv."&file=".$id;
if ($hd==0)
$movie_file=$id.".mp4";
else
$movie_file=$id."_hd.mp4";
$h=file_get_contents($cookie);
$t1=explode("0	noob",$h);
$t2=explode("\n",$t1[1]);
$n=$t2[0];
$t1=explode("0	auth",$h);
$t2=explode("\n",$t1[1]);
$a=$t2[0];
$cookie_ref="lvca_unique_user=1; place=1; noob=".$n." auth=".$a;
  if ($tv=="0")
    $file="http://hdforall.uphero.com/srt/".$id.".srt";
  else
    $file="http://hdforall.uphero.com/srt/tv/".$id.".srt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  if (strpos($h,"1.srt") === false) {
  if ($tv=="0")
    $file="http://hdforall.uphero.com/srt/en/".$id.".srt";
  else
    $file="http://hdforall.uphero.com/srt/tv/en/".$id.".srt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  }
  if (strpos($h,"1.srt") === false) {
  if ($tv=="0")
    $file="http://nobsub.googlecode.com/hg/m/".$id.".srt";
  else
    $file="http://nobsub.googlecode.com/hg/s/".$id.".srt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  }
if ($tv=="0") {
  if ($hd==0)
  $srt_name=$id.".srt";
  else
  $srt_name=$id."_hd.srt";
} else {
  if ($hd==0)
  $srt_name="episode_".$id.".srt";
  else
  $srt_name="episode_".$id."_hd.srt";
  /*
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $movie);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_NOBODY, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  $srt_name=str_between($h,'filename="','"');
  $srt_name=str_replace(".mp4",".srt",$srt_name);
  */
}
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $file);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);

$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
if ( ($h) && strpos($h,"302 Found") == false && strpos(strtolower($h),"doctype html") == false )  {
if ($flash != "direct") {
 if (function_exists("mb_convert_encoding")) {
	$h=mb_convert_encoding($h, 'UTF-8');
    $h = str_replace("ª","Ş",$h);
    $h = str_replace("º","ş",$h);
    $h = str_replace("Þ","Ţ",$h);
    $h = str_replace("þ","ţ",$h);
	$h = str_replace("ã","ă",$h);
	$h = str_replace("Ã","Ă",$h);

    $h = str_replace("Å£","ţ",$h);
    $h = str_replace("Å¢","Ţ",$h);
    $h = str_replace("Å","ş",$h);
	$h = str_replace("Ă®","î",$h);
	$h = str_replace("Ă¢","â",$h);
	$h = str_replace("Ă","Î",$h);
	$h = str_replace("Ã","Â",$h);
	$h = str_replace("Ä","ă",$h);
} else {
    $h = str_replace("�","S",$h);
    $h = str_replace("�","s",$h);
    $h = str_replace("�","T",$h);
    $h = str_replace("�","t",$h);
    $h=str_replace("�","a",$h);
	$h=str_replace("�","a",$h);
	$h=str_replace("�","i",$h);
	$h=str_replace("�","A",$h);
}
}
   $new_file = $base_sub.$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h);
   fclose($fh);

    $subtracks='"tracks": [{"file": "../subs/'.$srt_name.'", "default": true}]';

}
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Referer: '.$noob.'/index.php');
//header('Referer: http://p.jwpcdn.com/6/10/jwplayer.flash.swf');
header('Cookie: '.$cookie_ref);
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
} else {
  $l=$noob."/fork.php?type=flv&auth=".$auth."&loc=".$serv."&hd=".$hd."&tv=".$tv;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, 1);
  curl_setopt($ch, CURLOPT_NOBODY, 1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch, CURLOPT_REFERER,$noob."/player.swf");
  curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language: ro-ro,ro;q=0.8,en-us;q=0.6,en-gb;q=0.4,en;q=0.2","Accept-Encoding: gzip, deflate"));
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html = curl_exec($ch);
  curl_close($ch);
  $link=trim(str_between($html,"Location:","/index.php"));
  $type="flv";
  $movie1=$link."/index.php?file=".$id."&start=0&hd=".$hd."&auth=".$auth."&type=".$type."&tv=".$tv."&loc=".$serv;

echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"image": "'.$noob.'/2img/'.$id.'.jpg",
"sources": [{"default": true, "file": "'.$movie1.'", "type": "flv"},{"file": "'.$movie.'", "type": "mp4"}],
'.$subtracks.'
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"androidhls": true,
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
?>
