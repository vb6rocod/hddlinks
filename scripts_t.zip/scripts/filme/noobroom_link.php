<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$noob=file_get_contents($base_cookie."n.dat");
$cookie=$base_cookie."noob.dat";
$id = $_GET["query"];
$serv = $_GET["serv"];
$hd_o = $_GET["hd"];
if ($hd_o=="NU")
 $hd=0;
else
 $hd=1;
$tv= $_GET["tv"];
if (!$tv) {
 $l=$noob."/?".$id;
 $tv="0";
} else {
 $l=$noob."/?".$id."&tv=1";
}
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  //http://noobroom7.com/fork.php?type=flv&auth=0&loc=15&hd=0&tv=0&file=1633&start=0
  if ($hd==1) {
  if (!preg_match("/Watch in 1080p/i",$html))
    $hd=0;
  }
  $auth=str_between($html,"auth=","&");
   if ($tv=="0") {
     if ($hd==0)
     $movie= $noob."/".$serv."/".$auth."/".$id.".mp4";
     else
     $movie= $noob."/".$serv."/".$auth."/".$id."_hd.mp4";
   } else {
     if ($hd==0)
     $movie= $noob."/".$serv."/".$auth."/episode_".$id.".mp4";
     else
     $movie= $noob."/".$serv."/".$auth."/episode_".$id."_hd.mp4";
     }
//$movie=$noob."/fork.php?type=flv&auth=".$auth."&loc=".$serv."&hd=".$hd."&tv=".$tv."&file=".$id;
if ($hd==0)
$movie_file=$id.".mp4";
else
$movie_file=$id."_hd.mp4";
$h=file_get_contents($cookie);
$t1=explode("0	noob",$h);
$t2=explode("\n",$t1[1]);
$n=$t2[0];
$t1=explode("0	auth",$h);
$t2=explode("\n",$t1[1]);
$a=$t2[0];
$cookie_ref="lvca_unique_user=1; place=1; noob=".$n." auth=".$a;
  if ($tv=="0")
    $file="http://hdforall.uphero.com/srt/".$id.".srt";
  else
    $file="http://hdforall.uphero.com/srt/tv/".$id.".srt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  if (strpos($h,"302 Found") !== false) {
  if ($tv=="0")
    $file="http://hdforall.uphero.com/srt/en/".$id.".srt";
  else
    $file="http://hdforall.uphero.com/srt/tv/en/".$id.".srt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  }
  if (!$h) {
  if ($tv=="0")
    $file="http://nobsub.googlecode.com/hg/m/".$id.".srt";
  else
    $file="http://nobsub.googlecode.com/hg/s/".$id.".srt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  }
if ($tv=="0") {
  if ($hd==0)
  $srt_name=$id.".srt";
  else
  $srt_name=$id."_hd.srt";
} else {
  if ($hd==0)
  $srt_name="episode_".$id.".srt";
  else
  $srt_name="episode_".$id."_hd.srt";
  /*
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $movie);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_NOBODY, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  $srt_name=str_between($h,'filename="','"');
  $srt_name=str_replace(".mp4",".srt",$srt_name);
  */
}
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $file);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);
if ($h) {
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
   $new_file = $base_sub.$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h);
   fclose($fh);
}
header('Content-type: application/vnd.apple.mpegURL');
header('Referer: '.$noob.'/index.php');
//header('Referer: http://p.jwpcdn.com/6/8/jwplayer.flash.swf');
header('Cookie: '.$cookie_ref);
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
?>
