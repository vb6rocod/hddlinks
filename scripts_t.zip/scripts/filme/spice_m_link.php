<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$link = $_GET["file"];
$title = urldecode($_GET["title"]);
include ("../common.php");
$cookie=$base_cookie."ustv.dat";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
  //echo $h;
//die();
//jsAppData=new Array("591","rtmp://edge3.spicetvnetwork.de:1935/filme","mp4:FILME/KnockedUp2007/KNOCKEDUP2007_P1.mp4","130547afd81a7ff881bf51fa5cdc3289877e482aa581eb8d35b29affe6d143c0","http://www.ustv.ro/storage/fsub/knocked-up-1.sub");

$h=str_between($h,"jsAppData=new Array(",")");
$h=str_replace('"',"",$h);
$t1=explode(",",$h);
$rtmp=$t1[1];
$rtmp=str_replace("rtmp","http",$rtmp);
$str=$t1[2];
$id=$t1[3];
$sub=$t1[4];
$title = preg_replace('/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s', '', $title);
$srt_name=$title.".srt";
$movie_name= $title;
$movie_file=$movie_name.".mp4";
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $sub);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);
if ($h) {
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
   $new_file = $base_sub.$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h);
   fclose($fh);
}
$out=$rtmp."/_definst_/".$str."/".$movie_name.".m3u8?".$id;

//$out="http://edge4.spicetvnetwork.de:1935/seriale/_definst_/".$str."/".$movie_name.".m3u8?".$id;
//echo $out;
//die();
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $out");
?>
