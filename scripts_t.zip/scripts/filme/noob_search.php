<!doctype html>
<?php
include ("../common.php");
$src = urldecode($_GET["src"]);
$tit="CAUTARE: ".$src;
$search=str_replace("+"," ",urldecode($src));
$numai_sub="NU";
$alfabetic="DA";
$noob=file_get_contents($base_cookie."n.dat");
$cookie=$base_cookie."noob.dat";
$noob_serv=$base_cookie."noob_serv.dat";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $$noob."/func.js");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,$noob);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
$t1=explode('src="',$h);
$t2=explode("'",$t1[1]);
$baseimg=$t2[0];
$f=$base_pass."airfun.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$air=$t1[0];
} else {
$air="NU";
}
$noob_opt_serv=$base_fav."noob_opt_p.dat";
if (!file_exists($noob_opt_serv)) {
$opt_serv="18";
$opt_hd="NU";
} else {
  $handle = fopen($noob_opt_serv, "r");
  $c = fread($handle, filesize($noob_opt_serv));
  fclose($handle);
  $a=explode("|",$c);
  $opt_serv=trim($a[0]);
  $opt_hd=trim($a[1]);
}
$l=$noob."/latest.php";
?>
<html>



   <head>

      <meta charset="utf-8">
      <title><?php echo $tit; ?></title>
	  <link rel="stylesheet" type="text/css" href="../custom.css" />

      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js?_=835925279"></script>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js?_=101377612"></script>
      <script type="text/javascript" src="../jquery-1.10.1.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <script type="text/javascript" src="<?php echo $noob; ?>/func.js"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
    function myFunc(url2) {
         msg = 'noobroom_link.php?query=' + url2 + '&serv=' + document.getElementById('menu').value + '&hd=' + document.getElementById('opt').value;
         window.open(msg);
    }
</script>
<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(title, link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'mod=add&title='+ title +'&link='+link;
  var php_file='noob_m_add.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
    }
  }
}
function ajaxrequest1(link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'menu='+ document.getElementById('menu').value +'&opt='+document.getElementById('opt').value;
  var php_file='noob_opt1.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
    }
  }
}
</script>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
});
</script>
  </head>
   <body>

	<div class="balloon"></div>

<?php
//error_reporting(0);
//set_time_limit(60);
//echo '<a class="fancybox" href="'.$baseimg.$link.'.jpg" title="">PIC</a>';
echo '<h2 style="background-color:deepskyblue;color:black;">'.$tit.'</H2>';
echo '<p><b>Filmele cu * nu au subtitrare. PIC - poster film, IMDB - detalii film, FAV - adauga la favorite.</b></p>';
$hserv=file_get_contents($noob_serv);
$serv=explode("\n",$hserv);
$nn=count($serv);
echo '<p>Alegeti unul din servere: <select name="menu" id="menu">';
for ($k=0;$k<$nn-1;$k=$k+2) {
$n=$k/2;
if ($serv[$k+1]==$opt_serv)
 echo '<option value="'.$serv[$k+1].'" selected>'.$serv[$k].'</option>';
else
 echo '<option value="'.$serv[$k+1].'">'.$serv[$k].'</option>';
}
echo '</select>
Calitate 1080p: <select name="opt" id="opt">
';
if ($opt_hd=="NU") {
echo '<option value="NU" selected>NU</option>
<option value="DA">DA</option>';
} else {
echo '<option value="NU">NU</option>
<option value="DA" selected>DA</option>';
}
echo '<input type="submit" value="Memoreaza optiunile" onclick="ajaxrequest1()";>
</p>';
?>
<?php
echo '
<table border="1px" width="100%">
';
$n=0;
$link="http://hdforall.uphero.com/srt/";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $html = curl_exec($ch);
  curl_close($ch);
  if ($html) $videos = explode("<li>", $html);
if (!$html) {
$link="http://nobsub.googlecode.com/hg/m/list.txt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $html = curl_exec($ch);
  curl_close($ch);
  if ($html) {
   $videos = explode(",", $html);
   $videos = array_values($videos);
   foreach($videos as $video) {
     $srt[$video]="exista";
   }
}
} else {
unset($videos[0]);
$videos = array_values($videos);
$p=0;
foreach($videos as $video) {
  $t1=explode('>',$video);
  $t2=explode('<',$t1[1]);
  $t3=explode('.',$t2[0]);
  $id_srt=trim($t3[0]);
  if (strpos($video,".srt") !== false) $srt[$id_srt]="exista";
}
}
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,$l);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);


//
//$videos = explode("href='/?", $html);
$match="/".$search."/i";
$videos = explode("<br>", $html);
unset($videos[0]);
$videos = array_values($videos);
$title="";

foreach($videos as $video) {
//echo $video."<BR>";
   $t0=explode("href='/?",$video);
 if (sizeof ($t0) > 1 ) {
   $t1=explode("'",$t0[1]);
   $link=$t1[0];

   $t1=explode('>',$t0[1]);
   $t2=explode('<',$t1[1]);
   $title=$t2[0];
}
   $t1=explode("<",$video);
   if (preg_match("(\d+)",$t1[0],$m))
     $year=" (".$m[0].")";
   else
     $year="";

   if ($link && (preg_match($match,$title)))  $arr[]=array($title, $link,$year);
   //if ($link) $arr[]=array($title, $link,$year);
   //echo $link."-".$title."-".$year."<BR>";
}
if( !empty( $arr ) ) {
if ($arr) {
if ($alfabetic=="DA") asort($arr);
foreach ($arr as $key => $val) {
 $title=$arr[$key][0];
 $link=$arr[$key][1];
 $year=$arr[$key][2];
   if (!array_key_exists($link, $srt))
      $title1=$title.$year." (*)";
   else
      $title1=$title.$year;
   if ($numai_sub=="DA" && !array_key_exists($link, $srt)) $title="";
   if ($title) {
   if ($n == 0) echo "<TR>"."\n\r";
   if ($air=="DA") {
   echo '
   <TD style="color:white;"><font size="4"><a class="tippable" id="'.$link.'" href="javascript:myFunc(\''.urlencode($link).'&tv=0\');">'.$title1.'</font></a>
   ';
   } else {
   echo '
   <TD style="color:white;"><font size="4"><a href="javascript:myFunc(\''.urlencode($link).'&tv=0\');">'.$title1.'</font></a>
   ';
   }
   echo '</TD>'."\n\r";
   echo '<TD style=align="right" width="5px"><a class="fancybox" href="'.$baseimg.$link.'.jpg" title=""><b>PIC</b></a>|<a class="various fancybox.ajax" href="imdb.php?id='.$link.'"><b>IMDB</b></a>|<a onclick="ajaxrequest('."'".$title.$year."', '".$link."')".'"'." style='cursor:pointer;'>".'<b>FAV</b></a></TD>'."\n\r";
    $n++;
    if ($n > 1) {
     echo '</TR>'."\n\r";
     $n=0;
    }
   }
}
}
}
 if ($n<2) echo "</TR>"."\n\r";
?>
</table>
<br></body>
</html>
