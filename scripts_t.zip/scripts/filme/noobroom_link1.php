<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$noob=file_get_contents($base_cookie."n.dat");
$cookie=$base_cookie."noob.dat";
$id = $_GET["query"];
$serv = $_GET["serv"];
$hd = $_GET["hd"];
$tv= $_GET["tv"];
if (!$tv) {
 $l=$noob."/?".$id;
 $tv="0";
} else {
 $l=$noob."/?".$id."&tv=1";
}
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  //http://noobroom7.com/fork.php?type=flv&auth=0&loc=15&hd=0&tv=0&file=1633&start=0
  $auth=str_between($html,"auth=","&");
   if ($tv=="0")
     $movie= $noob."/".$serv."/".$auth."/".$id.".mp4";
   else
     $movie= $noob."/".$serv."/".$auth."/episode_".$id.".mp4";
//$movie=$noob."/fork.php?type=flv&auth=".$auth."&loc=".$serv."&hd=".$hd."&tv=".$tv."&file=".$id;
$movie_file=$id.".mp4";
$h=file_get_contents($cookie);
$t1=explode("0	noob",$h);
$t2=explode("\n",$t1[1]);
$n=$t2[0];
$t1=explode("0	auth",$h);
$t2=explode("\n",$t1[1]);
$a=$t2[0];
$cookie_ref="lvca_unique_user=1; place=1; noob=".$n." auth=".$a;
  if ($tv=="0")
    $file="http://hdforall.uphero.com/srt/".$id.".srt";
  else
    $file="http://hdforall.uphero.com/srt/tv/".$id.".srt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  if (strpos($h,"302 Found") !== false) {
  if ($tv=="0")
    $file="http://hdforall.uphero.com/srt/en/".$id.".srt";
  else
    $file="http://hdforall.uphero.com/srt/tv/en/".$id.".srt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  }
  if (!$h) {
  if ($tv=="0")
    $file="http://nobsub.googlecode.com/hg/m/".$id.".srt";
  else
    $file="http://nobsub.googlecode.com/hg/s/".$id.".srt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  }
if ($tv=="0")
  $srt_name=$id.".srt";
else {
  $srt_name="episode_".$id.".srt";
  /*
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $movie);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_NOBODY, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  $srt_name=str_between($h,'filename="','"');
  $srt_name=str_replace(".mp4",".srt",$srt_name);
  */
}
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $file);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);
if ($h) {
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
    $h = str_replace("�","S",$h);
    $h = str_replace("�","s",$h);
    $h = str_replace("�","T",$h);
    $h = str_replace("�","t",$h);
   $new_file = "../subs/".$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h);
   fclose($fh);
}
  $l=$noob."/fork.php?type=flv&auth=".$auth."&loc=".$serv."&hd=".$hd."&tv=".$tv;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, 1);
  curl_setopt($ch, CURLOPT_NOBODY, 1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch, CURLOPT_REFERER,$noob."/player.swf");
  curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language: ro-ro,ro;q=0.8,en-us;q=0.6,en-gb;q=0.4,en;q=0.2","Accept-Encoding: gzip, deflate"));
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html = curl_exec($ch);
  curl_close($ch);

  $link=trim(str_between($html,"Location:","/index.php"));

  $movie_link=$link."/index.php?type=flv&hd=".$hd."&auth=".$auth."&tv=0";
  $mysrt="../subs/".$srt_name;
?>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Noobroom</title>


      <style type="text/css">
         html { height: 100%; }
         body { height: 100%; margin:0; padding:0; background: #000000 }
         table { border-spacing: 0; border-collapse: collapse }
         td { padding: 0 }
         #header { background: #000000 url('Noobroom_files/opa.png'); border-bottom: 1px solid #ffffff; height: 120px }
         #footer { background: #000000 url('Noobroom_files/opa.png'); border-top: 1px solid #ffffff; height: 60px }
         a.hoverz:link { text-decoration:underline; }
         a.hoverz:active { text-decoration:underline; }
         a.hoverz:visited { text-decoration:underline; }
         a.hoverz:hover { text-decoration:underline; }
         a.hoverz:visited:hover { text-decoration:underline; }
         .balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
      </style>

      <script type="text/javascript" src="jwplayer.js"></script>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js?_=11226600"></script>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js?_=1251994273"></script>


   <body>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"players": [{"type":"flash","src":"player.swf"}],
"file": "<?php echo $id; ?>",
"height": $(document).height(),
"width": $(document).width(),
"dock": "true",
"autostart": "true",
"controlbar.position": "over",
"controlbar.idlehide": "false",
"backcolor": "000000",
"frontcolor": "ffffff",
"lightcolor": "f7b01e",
"streamer": "<?php echo $movie_link; ?>",
"volume": "100",
<?php
echo '"plugins": {"captions-2": {"file": "'.$mysrt.'","fontsize": "20"}}';
?>
});
</script>
</body></html>
