<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$query = $_GET["file"];
if($query) {
   $queryArr = explode(',', $query);
   $link = $queryArr[0];
   $pg_tit = urldecode($queryArr[1]);
   $pg = preg_replace('/[^A-Za-z0-9_]/','_',$pg_tit);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$pass = trim(file_get_contents($base_pass."serialepenet.txt"));
$post = "cod=".$pass."&activare=Activeaza";
$cookie = $base_cookie."serialepenet.dat";
if (!file_exists($cookie)) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $link);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
curl_setopt($ch, CURLOPT_REFERER, $link);
curl_setopt ($ch, CURLOPT_POST, 1);
curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
$html = curl_exec($ch);
curl_close($ch);
$t1=explode("Urmareste online serialul",$html);
$t2=explode("<",$t1[1]);
$info=trim($t2[0]);
} else {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $link);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
curl_setopt($ch, CURLOPT_REFERER, $link);
//curl_setopt($ch, CURLOPT_REFERER, "http://serialepenet.ro/andromeda/sezon_1");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
$html = curl_exec($ch);
curl_close($ch);
$t1=explode("Urmareste online serialul",$html);
$t2=explode("<",$t1[1]);
$info=trim($t2[0]);
}
$t1=explode('iframe src="',$html);
$t2=explode('"',$t1[1]);
$l=trim($t2[0]);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $l);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
curl_setopt($ch, CURLOPT_ENCODING, '');
//curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
curl_setopt($ch, CURLOPT_USERAGENT,"");
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language: ro-ro,ro;q=0.8,en-us;q=0.6,en-gb;q=0.4,en;q=0.2","Accept-Encoding: gzip, deflate"));
curl_setopt($ch, CURLOPT_REFERER, $link);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
$html = curl_exec($ch);
curl_close($ch);
if (strpos($html,"href") === false) {
if (function_exists("gzdecode"))
  $html=gzdecode($html);
}
//echo $html;
//die();
$t1=explode("file=",$html);
$t2=explode("&",$t1[1]);
$movie=$t2[0];
$t1=explode("file=",$html);
$t2=explode("&",$t1[2]);
$srt=$t2[0];
$movie_file=substr(strrchr($movie, "/"), 1);
$t1=explode("?",$movie_file);
$movie_file=$t1[0];
$srt_name = substr($movie_file, 0, -3)."srt";
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
//echo $srt;
if ($srt) {
$out="";
$n=0;
$html = file_get_contents($srt);
if(preg_match('/(\d\d):(\d\d):(\d\d),(\d\d\d) --> (\d\d):(\d\d):(\d\d),(\d\d\d)/', $html)) {
 $out=$html;
} else {
$videos = explode('<p', $html);
unset($videos[0]);
$videos = array_values($videos);
$n=1;
foreach($videos as $video) {
$t1=explode('begin="',$video);
$t2=explode('"',$t1[1]);
$start=$t2[0];
if (strlen($start)==5) {
$start="00:".$start.",000";
} else {
$start=$start.",000";
}
$t1=explode('end="',$video);
$t2=explode('"',$t1[1]);
$end=$t2[0];
if (strlen($end)==5) {
$end="00:".$end.",000";
} else {
$end=$end.",000";
}
$line=str_between($t1[1],">","</p");
$line=str_replace("<br/>","\r\n",$line);
$out = $out.$n."\r\n";
$out = $out.$start." --> ".$end."\r\n";
$out = $out.$line."\r\n";
$out = $out."\r\n";
$n++;
}
}
$new_file = $base_sub.$srt_name;
$fh = fopen($new_file, 'w');
fwrite($fh, $out);
fclose($fh);
}
//http://s4.serialepenet.ro:81/video/60b1d68609119cc012edb6e22dd68661/5360ac52/531.mp4?start=0
//Cookie: trafic_h=568fbd6de4dbl9dee59fda9fb200dbd5*1395064814*serialepenet.ro*1395064814*1395068897*2; SESS5ca2e6b4aab79870689f71b256a8b5a6=c0c2d7f55a5ccb8af8a64fec75198ac1

//header('Content-Type: video/mp4');

if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Referer: http://serialepenet.ro/476-embed-236/player/player.swf');
//header('Content-Length: 292364116');
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$pg_tit.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$movie.'"}],
"tracks": [{"file": "../subs/'.$srt_name.'", "default": true}]
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
?>
