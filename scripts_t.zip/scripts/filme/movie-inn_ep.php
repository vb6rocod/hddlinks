<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$id = $_GET["id"];
$cookie=$base_cookie."movie-inn.dat";
  $link="http://www.movie-inn.com/series.php?id=".$id;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER,"http://www.movie-inn.com/main.php?page=series");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  $html=str_between($html,'<div id="content">','</body>');
 $html=str_replace("./","http://www.movie-inn.com/",$html);
 //$html=str_replace("series.php","movie-inn_ep.php",$video);
?>
<html>

	<title>.::Movie Inn::.</title>

			<head>
			<meta http-equiv="Content-type" content="text/html; charset=utf-8">
			<link rel="stylesheet" href="http://www.movie-inn.com/css/style.css" type="text/css" />
			<!--genres button-->
				<script type="text/javascript" src="http://www.movie-inn.com/js/jquery-ui-1.8.2.custom.min.js"></script>
			<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js'></script>
				<script type="text/javascript" src="http://www.movie-inn.com/js/login.js"></script>
			<script>
			$(function () {
			  $("#fixed-bar")
			    .css({position:'fixed',bottom:'0px'})
			    .hide();
			  $(window).scroll(function () {
			    if ($(this).scrollTop() > 400) {
			      $('#fixed-bar').fadeIn(200);
			    } else {
			      $('#fixed-bar').fadeOut(200);
			    }
			  });
			  $('.go-top').click(function () {
			    $('html,body').animate({
			      scrollTop: 0
			    }, 1000);
			    return false;
			  });
			});
			</script>
		    <div id="fb-root"></div>
		</head>
	<body id="top">

				<div id="content">
<?php
echo $html;
?>
<br></body></html>
