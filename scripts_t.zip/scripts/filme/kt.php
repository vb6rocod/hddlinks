<?php
$x=$_GET["link"];
file_put_contents("kt.txt",$x);
?>
