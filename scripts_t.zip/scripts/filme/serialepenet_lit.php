<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
      <meta charset="utf-8">
      <title>Serialepenet -  litere</title>

      <script type="text/javascript" src="../jquery-1.10.1.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />



<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(title, link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'mod=add&title='+ title +'&link='+link;
  var php_file='serialepenet_add.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
    }
  }
}
</script>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
});
</script>
</head>
<body><h3></h3>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function isort($a,$b) {
    return strtolower($a)>strtolower($b);
}
$query = $_GET["file"];
if($query) {
   $queryArr = explode(',', $query);
   $link = $queryArr[0];
   $pg_tit = urldecode($queryArr[1]);
}
$html = file_get_contents($link);
$t1=explode('<div class="view view-listaseriale',$html);
$html=$t1[1];

$videos = explode('span class="field-content"', $html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
    $t1 = explode('href="', $video);
    $t2 = explode('"', $t1[1]);
    $link="http://serialepenet.ro".$t2[0];
    $t2 = explode('>', $t1[1]);
    $t3 = explode('<',$t2[1]);
    $title = $t3[0];
    $title = ucfirst($title);
    $movie[$title] = $link;
}
uksort($movie,"isort");
$n=0;
echo '<table border="2" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="6"><font size="4">'.$pg_tit.'</font></TD></TR>';
foreach ($movie as $key => $val) {
    $title=$key;
    $link= "serialepenet.php?file=".$val.",".urlencode($title);
   if ($n == 0) echo "<TR>"."\n\r";
   echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
   echo '<TD align="right" width="5px"><a class="various fancybox.ajax" href="serialepenet_info.php?id='.$val.'"><font size="4">INFO</font></a>|<a onclick="ajaxrequest('."'".$title."', '".$val."')".'"'." style='cursor:pointer;'>".'<font size="4">FAV</font></a></TD>'."\n\r";
   echo '</TD>'."\n\r";
   $n++;
   if ($n > 2) {
   echo '</TR>'."\n\r";
   $n=0;
   }
}
 if ($n < 3) {
 echo '</TR>';
 $n=0;
 }
?>
</table>
<br></body>
</html>
