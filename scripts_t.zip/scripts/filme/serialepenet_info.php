<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>info</title>
</head>
<body>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$link = $_GET["id"];
$html = file_get_contents($link);
$t1=explode("<div id='serial_description'>",$html);
$t2=explode("src='",$t1[1]);
$t3=explode("'",$t2[1]);
$img="http://serialepenet.ro/".$t3[0];
$img=str_replace(" ","%20",$img);
$annotation=str_between($t1[1],"'serial_description_text'>","</span>");
$annotation=str_replace("</b>",":",$annotation);
$annotation = preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$annotation);
$t=str_between($html,"<title>","</title>");
$t=explode("serial",$t);
$t=trim($t[0]);
if ($t <> "") {
$pg_tit = $t;
}
echo '<h3>'.$pg_tit.'</h3>';
echo '<img src="'.$img.'"><span><font size="4">'.$annotation.'</font></span>';
?>
<br></body>
</html>
