<?php
include ("../common.php");
error_reporting(0);
function decode_entities($text) {
    $text= html_entity_decode($text,ENT_QUOTES,"ISO-8859-1"); #NOTE: UTF-8 does not work!
    $text= preg_replace('/&#(\d+);/me',"chr(\\1)",$text); #decimal notation
    $text= preg_replace('/&#x([a-f0-9]+);/mei',"chr(0x\\1)",$text);  #hex notation
    return $text;
}
//if (file_exists("D:\\Adobe"))
  $filelink = $_GET["file"];
  //$filelink=str_replace(",","%2C",$filelink);
  //echo $filelink;
//else
//  $filelink=$_ENV["QUERY_STRING"];
//$filelink = $_GET["file"];
//$filelink="http://www.seriale.filmesubtitrate.info/2011/08/against-wall-sezon-1-ep-1-pilot-serial.html";
$t1=explode(",",$filelink);
$filelink = urldecode($t1[0]);
$filelink = str_replace("*",",",$filelink);
$filelink = str_replace("@","&",$filelink); //seriale.subtitrate.info
$filelink=str_replace("www.seriale.filmesubtitrate.info","www.fsplay.net",$filelink);
$filelink=str_replace("www.filmesubtitrate.info","www.fsplay.net",$filelink);
$pg = urldecode($t1[1]);

function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}


/**####################################**/
/** Here we start.......**/
$last_link = "";
//if (strpos($filelink,"onlinemoca") === false) {
if (strpos($filelink,"filmeonlinesubtitrate") !== false) {

  $post="pageviewnr=1";
  $ch = curl_init($filelink);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch,CURLOPT_REFERER,$filelink);
  //curl_setopt ($ch, CURLOPT_POST, 1);
  //curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);  // RETURN THE CONTENTS OF THE CALL
  curl_setopt($ch, CURLOPT_HEADER, true);
  $html = curl_exec($ch);
  curl_close ($ch);
  //$l = str_between($html,"Link: <",">;");
  //echo $l;
  //Link: <http://www.filmeonlinesubtitrate.tv/?p=5382>; rel=shortlink
  //$AgetHeaders = @get_headers($filelink);
  //echo $AgetHeaders;
} elseif (strpos($filelink,"990.ro") !== false) {
    $link1 = str_replace("download","",$filelink);
    $link1 = str_replace("seriale2","player-seriale",$link1);

  $ch = curl_init($link1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch,CURLOPT_REFERER,$filelink);
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);  // RETURN THE CONTENTS OF THE CALL
  $html = curl_exec($ch);
  curl_close ($ch);

  $link1=str_replace(urldecode("%0D"),"",$link1);
  $filelink=$link1;
//} elseif (strpos($filelink,"filmedivix") !== false) {
//  $html=file_get_contents($filelink);
//  $filelink="http://filmedivix.com/filmeonline/".str_between($html,"filmedivix.com/filmeonline/",'"');
//  $html = file_get_contents($filelink);
} elseif (strpos($filelink,"http://filmehd.net") !== false) {
  $html=file_get_contents($filelink);
  $i1=str_between($html,"js_content.php","'");
  $filelink="http://filmehd.net/js_content.php".$i1;
  $html=file_get_contents($filelink);
  //echo $html;
} elseif (strpos($filelink,"fsplay.net") !== false) {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $filelink);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.fsplay.net");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html=curl_exec($ch);
  curl_close($ch);
  $html= decode_entities($html);
  //echo $html;
} else {
  $html = file_get_contents($filelink);
  if (strpos($filelink,"vezi-online.net") !== false) {
    //$h1=str_between($html,'class="player">','</div');
    $h1=explode('class="player">',$html);
    $t1=explode("document.write(unescape('",$h1[1]);
    $t2=explode("'",$t1[1]);
    if ($t2[0]) $html=urldecode($t2[0]);
  }
}
//echo $html;
$mysrt=str_between($html,"captions.file=","&");
if(!$mysrt)
 $mysrt=str_between($html,'captions-2": { file: "','"');
$mysrt = str_replace(" ","%20",$mysrt);
if (strpos($mysrt,"http") === false && $mysrt) {
  $t=explode("/",$filelink);
  $mysrt="http://".$t[2].$mysrt;
}
//echo $mysrt;
/**################ All links ################**/
if(preg_match_all("/(\/\/.*?)(\"|\')+/i",$html,$matches)) {
$links=$matches[1];
//print_r ($links);
}
$s="/adf\.ly|vidxden\.c|divxden\.c|vidbux\.c|movreel\.c|videoweed\.(c|e)|novamov\.(c|e)|vk\.com";
$s=$s."|movshare\.net|youtube\.com|youtube-nocookie\.com|flvz\.com|rapidmov\.net|putlocker\.com|mixturevideo\.com|played\.to|";
$s=$s."peteava\.ro\/embed|peteava\.ro\/id|content\.peteava\.ro|divxstage\.net|divxstage\.eu";
$s=$s."|vimeo\.com|googleplayer\.swf|filebox\.ro\/get_video|vkontakte\.ru|megavideo\.com|videobam\.com";
$s=$s."|fastupload|video\.rol\.ro|zetshare\.net\/embed|ufliq\.com|stagero\.eu|ovfile\.com|videofox\.net";
$s=$s."|trilulilu|proplayer\/playlist-controller.php|viki\.com|modovideo\.com|roshare\.info|ishared\.eu|";
$s=$s."filebox\.com|glumbouploads\.com|uploadc\.com|sharefiles4u\.com|zixshare\.com|uploadboost\.com";
$s=$s."|nowvideo\.eu|nowvideo\.co|vreer\.com|180upload\.com|dailymotion\.com|nosvideo\.com|vidbull\.com|purevid\.com|videobam\.com|streamcloud\.eu|donevideo\.com|upafile\.com|docs\.google|mail\.ru|superweb\.rol|moviki\.ru|entervideos\.com/i";
$s="/fastupload|superweb|roshare|vkontakte\.ru|vk\.com|mail\.ru/";
for ($i=0;$i<count($links);$i++) {
  if (strpos($links[$i],"http") !== false) {
    $t1=explode("http:",$links[$i]);
   if (sizeof ($t1) > 1 ) {
    $cur_link="http:".$t1[1];
	}
  } else {
  $cur_link="http:".$links[$i];
  }
  $t1=explode(" ",$cur_link);     //vezi-online
  $cur_link=$t1[0];
  $t1=explode("&stretching",$cur_link);    //vezi-online
  $cur_link=$t1[0];
  if (strpos($cur_link,"entervideos.com/vidembed") !==false) {
  $t1=explode("&",$cur_link);    //
  $cur_link=$t1[0];
  }
  $cur_link=str_replace(urldecode("%0D"),"",$cur_link);
  if (preg_match($s,$cur_link)) {
    if ($cur_link <> $last_link) {
     $t1=explode("proxy.link=",$cur_link); //vezi-filme
   if (sizeof ($t1) > 1 ) {
     if ($t1[1]) {
       $t2=explode("&",$t1[1]);
       $cur_link=trim($t2[0]);
     }
   }
      if (!preg_match("/top\.mail\.ru|facebook|twitter|player\.swf|img\.youtube|youtube\.com\/user|radioarad|\.jpg|\.png|\.gif|jq\/(js|css)|fsplay\.net\?s/i",$cur_link)) {
        $t1=explode("proxy.link=",$cur_link); //filmeonline.org
      if (sizeof ($t1) > 1 ) {
        if ($t1[1] <> "") {
        $cur_link=$t1[1];
        }
      }
        if (strpos($cur_link,"captions.file") !== false) {  //http://vezi-online.net
        $a=explode("&captions.file",$cur_link);
        $mysrt=str_between($cur_link,"captions.file=","&");
        if (strpos($mysrt,"http") === false && $mysrt) {
         $t=explode("/",$filelink);
         $mysrt="http://".$t[2].$mysrt;
        }
        $cur_link=$a[0];
        }

        if (strpos($cur_link,"adf.ly") !==false) { //onlinemoca
           $a1=explode($cur_link,$html);
           $a2=explode('server/',$a1[1]);
           $a3=explode('.',$a2[1]);
           $server=$a3[0];
        } else {
          $server = str_between($cur_link,"http://","/");
        }
        $last_link=$cur_link;
        if (strpos($cur_link,"google") !==false) {
          $t1=explode("docid=",$cur_link);
          $t2=explode("&",$t1[1]);
          $docid=$t2[0];
          $mysrt_google="http://video.google.com/videotranscript?frame=c&docid=".$docid."&hl=ro&type=track&name=ro&lang=ro";
        }
        if (strpos($cur_link,"viki.com") !==false) {
          preg_match('/(viki\.com\/player\/medias\/)([\w\-]+)/', $cur_link, $match);
          $viki_id = $match[2];
        }
        $link_f[]=$cur_link;
      }
    }
  }
}
/**################ special links ##############**/

/**################ flash... mediafile,file.....############**/

//http://www.filmesubtitrate.info/2010/06/10-things-i-hate-about-you-sez1-ep1.html
//http://www.seriale.filmesubtitrate.info/2010/06/10-things-i-hate-about-you-sez1-ep1.html
//www.seriale.filmesubtitrate.info
if (strpos($filelink,"fsplay.net") !== false) {
///playerfs/plmfilmesub.php?lk=a8u25iq4cach
///playerfs/plmnowvideo.php?lk=2rzm75lkxawps
//peteava - http://www.seriale.filmesubtitrate.info/playerfs/peteava.php?lk=503993
//videoweed - http://www.seriale.filmesubtitrate.info/playerfs/plmweed.php?lk=gdubcouik7ogu&km=A.Seriale/Alcatraz%20S01E01
//novamov - http://www.seriale.filmesubtitrate.info/playerfs/plmnova.php?lk=f6uol0yy3s2sp&km=A.Seriale/Alcatraz%20S01E01
//vidbux - http://www.seriale.filmesubtitrate.info/playerfs/plmvidb.php?lk=e2tjkd08bok4&km=A.Seriale/Alcatraz%20S01E01
//vidxden - http://www.seriale.filmesubtitrate.info/playerfs/plmvidx.php?lk=1798z8fap6g3/Touch_S01E01.flv.html
///playerfs/plmvk.php?lk=106177506&id=163445800&hash=7fa53905d105372e&hd=1
$title = "";
$f = "/usr/local/bin/home_menu";
$videos = explode('player5', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
 $t1=explode('"',$video);
 $link="http://www.fsplay.net/player5".$t1[0];

 if (strpos($link,"plmfilmesub") !== false) $title="roshare";
 if (strpos($link,"peteava") !== false) $title="peteava";
 if (strpos($link,"plmweed") !== false) $title="videoweed";
 if (strpos($link,"plmnova") !== false) $title="novamov";
 if (strpos($link,"plmvidb") !== false) $title="vidbux";
 if (strpos($link,"plmvidx") !== false) $title="vidxden";
 if (strpos($link,"plmnowvideo") !== false) $title="nowvideo";
 if (strpos($link,"plmvk") !== false) $title="vk";
 //$link="link.php?file=".urlencode($link);
 if ($title <> "") {
     $link_f[]=$link;
     //echo '<font size="4"><a href="'.$link.'" target="_blank">'.$title.'</a></font>'."<BR>";
 }
}
}
$n= count($link_f);
if ($n==1) {
$base_url=$_SERVER['HTTP_REFERER'];
$dir_actual = substr($base_url, 0, strrpos($base_url, '/'))."/";
//http://sv3.fastupload.ro/download/8c6d6d1718d73a213738df00b1659a1f/5379b6e3/flv/5ec5047142943faa69655b4836b55a2a.flv?start=0
//http://sv3.fastupload.ro/download/adea3b01d789845cdd807e991b747340/5379b860/flv/93c2e705d352d5b81b55c2ea2540903f.flv
$dir_actual="http://127.0.0.1:8080/scripts/filme/";
if (!file_exists("D:\\Program Files\\xampp\\htdocs\\mobile\\"))
$movie=file_get_contents($dir_actual."link.php?file=".urlencode($link_f[0]));
else
$movie=file_get_contents("http://127.0.0.1/mobile/scripts/filme/link.php?file=".urlencode($link_f[0]));
$movie_file=substr(strrchr($movie, "/"), 1);
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
} else {
echo '
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Alege varianta</title>
   	  <link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>';
echo "<H2>Alegeti una din variantele de mai jos (sau una din parti)</H2>";
for ($k=0; $k<$n;$k++) {
 if (!preg_match("/player5/",$link_f[$k])) {
  $server= str_between($link_f[$k],"http://","/");
 } else {
  if (strpos($link_f[$k],"plmvk") !== false) $server="vk";
  if (strpos($link_f[$k],"plmfilmesub") !== false) $server="roshare";
 }
 echo '<a href="link1.php?file='.urlencode($link_f[$k]).'"><font size="6">'.$server.'</font></a><BR>';
 }
echo '<br></body>
</html>';
}
?>

