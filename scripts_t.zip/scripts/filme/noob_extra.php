<?php
$sub=$_POST["sub"];
$alf=$_POST["alf"];
include ("../common.php");
$noob_extra=$base_fav."noob_extra.dat";
$out=$sub."|".$alf;
$fh = fopen($noob_extra, 'w');
fwrite($fh, $out);
fclose($fh);
echo "Optiunile au fost salvate.";
?>
