<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
      <meta charset="utf-8">
      <title>seriale</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
</head>
<body><h4></h4>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$query = $_GET["query"];
if($query) {
   $queryArr = explode(',', $query);
   $link = $queryArr[0];
   $tit = urldecode($queryArr[1]);
}
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="3" align="center"><font size="4">'.$tit.'</font></TD></TR>';
//echo $link;
$html = file_get_contents($link);
//echo $html;
$seasons=explode('class="season',$html);
unset ($seasons[0]);
foreach ($seasons as $season) {
$t1=explode(">",$season);
$t2=explode("<",$t1[1]);
$sez=$t2[0];
$sez=trim(str_replace("&#9658;","",$sez));
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="3" align="center"><font size="4">'.$sez.'</font></TD></TR>';
$videos = explode('class="ep">', $season);
unset($videos[0]);
$videos = array_values($videos);
//$videos = array_reverse($videos);
$n=0;
foreach($videos as $video) {
//echo $video;
    $t1 = explode('<', $video);
    $tit1=$t1[0];
    $t2=explode('class="tf">',$video);
    $t3=explode('<',$t2[1]);
    $title=$tit1.$t3[0];
    $t2 = explode('href="', $video);
    $t3=explode('"',$t2[1]);
    $link = $t3[0];
    if (strpos($link,"1.bm-automobile.ro") !==false)
      $link = 'filme_link.php?file='.urlencode($link).",".urlencode($title);
    else
      $link='link1.php?file='.urlencode($link).",".urlencode($title);

      if ($n == 0) echo "<TR>"."\n\r";
		echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 2) {
         echo '</TR>'."\n\r";
         $n=0;
        }
}
}
echo '</table>';
?>
<br></body>
</html>
