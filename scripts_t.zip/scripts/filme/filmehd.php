<!DOCTYPE html>
<?php
include ("../common.php");
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page = $queryArr[1];
   $search = $queryArr[0];
   $page_title=urldecode($queryArr[2]);
   $search=str_replace("|","&",$search);
}
if (!$page)
$page_title = "Cautare: ".$search;
if ($page) {
if ($search)
  $html = file_get_contents("http://filmehd.net/".$search."/page/".$page);
else
  $html= file_get_contents("http://filmehd.net/page/".$page);
} else {
$search=str_replace(" ","+",$search);
$html= file_get_contents("http://filmehd.net/?s=".$search);
//echo $html;
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
if ($page) {
echo '<tr><TD colspan="4" align="right">';

if ($page > 1)
echo '<a href="filmehd.php?page='.$search.','.($page-1).','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="filmehd.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="filmehd.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}
$html=urlencode($html);

$videos = explode('d%3D%22post', $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
	$t1 = explode('href%3D%22', $video);
	$t2 = explode("%22", $t1[1]);
	$link = urldecode($t2[0]);
	$link = str_replace(' ','%20',$link);
	$link = str_replace('[','%5B',$link);
	$link = str_replace(']','%5D',$link);
	$t1 = explode('src%3D%22', $video);
	$t2 = explode('%22', $t1[1]);
	$image = urldecode($t2[0]);

	$t1 = explode('title%3D%22', $video);
	$t2 = explode('%22', $t1[1]);
	$t2=urldecode($t2[0]);
	$t3 = explode("&#8211;",$t2);
	$title = str_replace("– Filme online gratis subtitrate in romana","",$t3[0]);
	$title = str_replace("– Filme online gratis subtitratate in romana","",$title);
	$title = str_replace("– Filme online gratis subititrate in romana","",$title);
	$title = trim($title);
	$title=preg_replace("/online|subtitrat(e*)|film(e*)|vezi(.*)(:)|gratis/si","",$title);
	$title=trim(str_replace("&nbsp;","",$title));

	$pos = strpos($image, '.jpg');
	if (($pos !== false) && ($title <> "")){
    //$link = 'filme_link.php?file='.$link.','.urlencode($title);
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="filme_link.php?file='.urlencode($link).','.urlencode($title).'" target="_blank"><img src="'.$image.'" width="200px" height="280px"><BR><font size="4">'.$title.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
}
if ($page) {
echo '<tr><TD colspan="4" align="right">';

if ($page > 1)
echo '<a href="filmehd.php?page='.$search.','.($page-1).','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="filmehd.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="filmehd.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}
echo "</table>";
?>
<br></body>
</html>
