<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>FilmBox</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<table border="1px" width="100%">

<TR><td style="color:black;background-color:deepskyblue;text-align:center" colspan="3"><font size="4"><b>FilmBox</b></font></TD></TR></TR><TR>

<?php
$l="http://www.filmboxliveapp.net/mobilev2/android/AppConfig_ro.xml";
$html=file_get_contents($l);
$n=0;
$videos = explode('<el name', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
 $t1=explode('"',$video);
 $title=$t1[1];
 $t1=explode('type="',$video);
if (sizeof($t1)>1) {
 $t2=explode('"',$t1[1]);
 $tip=$t2[0];
}
 $t1=explode('action="',$video);
if (sizeof($t1)>1) {
 $t2=explode('"',$t1[1]);
 $action=$t2[0];
 $t1=explode('value="',$video);
 $t2=explode('"',$t1[1]);
 $value=$t2[0];
}
 $link="filmbox.php?page=1&title=".$title."&value=".$value;
 if ($tip=="movie" && $action=="custom_filter_by_genre") {
 	if ($n == 0) echo "<TR>"."\n\r";
	echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
    $n++;
    if ($n > 2) {
     echo '</TR>'."\n\r";
     $n=0;
    }
}
}
 if ($n<3) echo "</TR>"."\n\r";
 echo '</table>';
?>
</body>
</HTML>
