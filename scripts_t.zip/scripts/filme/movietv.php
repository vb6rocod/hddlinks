<!DOCTYPE html>
<?php
include ("../common.php");
$page = $_GET["page"];
$tit= urldecode($_GET["title"]);
$link=urldecode($_GET["link"]);
$token=$_GET["token"];
$tip=$_GET["tip"];
if ($tip=="search" || $tip=="actor") $tit="Cauta:".$link;
$link=str_replace(" ","+",$link);
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $tit; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}

$l="http://hddlinks.netai.net/m/glob.php";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  $hsrt = curl_exec($ch);
  curl_close($ch);
$t1=explode(",",$hsrt);
if (sizeof ($t1) > 1 ) {
for ($n=0;$n<count($t1);$n++) {
$id=$t1[$n];
//echo $id;
$srt[$id]="OK";
}
} else {
$link1="http://popsubs.googlecode.com/hg/m/list.txt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $hsrt = curl_exec($ch);
  curl_close($ch);
$t1=explode(",",$hsrt);
for ($n=0;$n<count($t1);$n++) {
$id=$t1[$n];
//echo $id;
$srt[$id]="OK";
}
}
$cookie=$base_cookie."movietv.dat";
//echo $tip;
/*
$l="http://movietv.to/movies";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
$token=str_between($html,"token: '","'");
*/
if ($tip=="genres")
$l="http://movietv.to/titles/paginate?_token=".$token."&perPage=16&page=".$page."&order=release_dateDesc&type=movie&minRating=&maxRating="."&genres%5B%5D=".$link;
elseif ($tip=="release")
$l="http://movietv.to/titles/paginate?_token=".$token."&perPage=16&page=".$page."&order=".$link."&type=movie&minRating=&maxRating=";
elseif ($tip=="search")
$l="http://movietv.to/titles/paginate?_token=".$token."&perPage=16&page=1&order=release_dateDesc&query=".$link."&type=movie&minRating=&maxRating=";
elseif ($tip=="actor")
$l="http://movietv.to/titles/paginate?_token=".$token."&perPage=16&page=1&order=release_dateDesc&cast=".$link."&type=movie&minRating=&maxRating=";
$n=0;
//echo $l;

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
$p=json_decode($html,1);
//print_r ($p);
$tot_pg = intval($p["totalPages"]);
if (($p["totalPages"]*1000) != 1000*intval($p["totalPages"])) $tot_pg=$tot_pg + 1;
  
  $pg='Pagina curenta: '.$page.' din '.$tot_pg;
 

echo '<h2 style="background-color:deepskyblue;color:black">'.$tit.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";

if ( $page <>"" ) {
echo '<tr>
<TD colspan="3"><form action="movietv.php?page=">
<font size="4">'.$pg.'</font>
<font size="4">- Salt la pagina: </font>
<input type="text" name="page" id="page">
<input type="hidden" name="link" id="link" value="'.$link.'">
<input type="hidden" name="tip" id="tip" value="'.$tip.'">
<input type="hidden" name="title" id="title" value="'.$tit.'">
<input type="submit" value="GO!">
</form></td>
<TD colspan="1" align="right">';
}

if ($page > 1)
echo '<a href="movietv.php?page='.($page-1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="movietv.php?page='.($page+1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="movietv.php?page='.($page+1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
$k=count($p["items"]);
for ($i=0;$i<$k;$i++) {
  $title=$p["items"][$i]["title"];
  $image=$p["items"][$i]["poster"];
  $link1= $p["items"][$i]["link"][0]["url"];
  $id1= $p["items"][$i]["link"][0]["id"];
  $year=$p["items"][$i]["year"];
  $title=$title." (".$year.") ";
  $id_t=$p["items"][$i]["id"];
  if (!array_key_exists($id1, $srt))
     $title1=$title." *";
  else $title1=$title;
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="movietv_link.php?file='.urlencode($link1).'&id='.$id1.'&id_t='.$id_t.'&title='.urlencode(str_replace("'","\'",$title)).'" target="_blank"><img src="'.$image.'" width="160px" height="224px"><BR><font size="4">'.$title1.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="movietv.php?page='.($page-1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="movietv.php?page='.($page+1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="movietv.php?page='.($page+1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br>

</body>
</html>
