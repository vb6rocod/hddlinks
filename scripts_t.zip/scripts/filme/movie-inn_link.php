<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$cookie=$base_cookie."movie-inn.dat";
error_reporting(0);
$query=$_GET["file"];
$queryArr = explode(',', $query);
$id = $queryArr[0];
$type = $queryArr[1];
$title = $queryArr[2];
if (!$title) $title = "play now...";
if ($type=="m")
$l="http://www.movie-inn.com/movie.php?id=".$id;
else
$l="http://www.movie-inn.com/episode.php?id=".$id;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  $t1=explode("clip=",$html);
  $t2=explode('"',$t1[1]);
  $clip=$t2[0];
  //if ($type=="m")
    $l="http://www.movie-inn.com/jwlarge/index.php?clip=".$clip;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
$t1=explode('file: "',$html);
$t2=explode('"',$t1[3]);
$movie=$t2[0];
//$movie=str_replace("www.","",$movie);
$movie=str_replace("content/s_","content/",$movie);
$movie_file=substr(strrchr($movie, "/"), 1);
//http%3A%2F%2Fmovie-inn.com%3A1935%2Fvod%2Fmp4%3Achimpanzee.mp4%2Fmanifest.f4m
//http://www.movie-inn.com/content/x_men_days_of_future_past.mp4
//http://movie-inn.com:1935/vod/mp4:x_men_days_of_future_past.mp4/manifest.f4m
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
} elseif ($flash == "flash") {
$l="http://movie-inn.com/flash/index.php?clip=".$clip;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  //http://www.movie-inn.com/flash/StrobeMediaPlayback.swf
  $movie_flash=urldecode(str_between($html,'value="src=','&'));
  $poster="http://movie-inn.com".str_between($html,'poster=../','"');
  $poster=str_replace("uploads","",$poster);
  $obj=str_between($html,"</script>","</object")."</object>";
  $obj=str_replace("../uploads","http://movie-inn.com",$obj);
  $obj=str_replace("StrobeMediaPlayback.swf","http://www.movie-inn.com/flash/StrobeMediaPlayback.swf",$obj);
echo $obj;
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$movie.'"}]
}],
"height": $(document).height(),
"width": $(document).width(),
"skin": "../hd4all.xml",
"startparam": "start",
"fallback": false,
"wmode": "direct",
"primary": "html5",
"stagevideo": true
});
jwplayer("container").onReady(function(event){
if (jwplayer().getRenderingMode() == "flash") {
//jwplayer().stop();
jwplayer().remove();
}
});
</script>
</BODY>
</HTML>
';
}
?>
