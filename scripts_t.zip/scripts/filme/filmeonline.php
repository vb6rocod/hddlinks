<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
      <meta charset="utf-8">
      <title>Seriale - filmeonline</title>
<?php
$query = $_GET["query"];
if($query) {
   $queryArr = explode(',', $query);
   $link = $queryArr[0];
   $pagetitle = trim(urldecode($queryArr[1]));
   $pagetitle=str_replace(urldecode("%C2%A0"),"",$pagetitle);
}
echo '<title>'.$pagetitle.'</title>';
echo '</head><body><h2></h2>
';
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function decode_entities($text) {
    $text= html_entity_decode($text,ENT_QUOTES,"ISO-8859-1"); #NOTE: UTF-8 does not work!
    $text= preg_replace('/&#(\d+);/me',"chr(\\1)",$text); #decimal notation
    $text= preg_replace('/&#x([a-f0-9]+);/mei',"chr(0x\\1)",$text);  #hex notation
    return $text;
}
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="4"><font size="4">'.$pagetitle.'</font></TD></TR>';
$pagelink=$link;
$html = file_get_contents($link);
$n=0;
$m=0;
$t1=explode("Cuvinte cheie",$html);
//$html=$t1[0];
//echo $html;
preg_match_all('/S\d{2}E\d{2}/',$html,$r);
$v=$r[0];
for ($i=0;$i<count($v)-1;$i++) {
//$vid=str_between($html,$v[$i],"</table>");
$x=explode($v[$i],$html);
$x1=explode($v[$i+1],$x[1]);
$vid=$x1[0];
//echo $vid."<BR>";
//<div class="hosts"
$videos=explode('hosts',$vid);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $t1=explode('href="',$video);
  $t2=explode('"',$t1[1]);
  $t3=explode("http",$t2[0]);
  $link=$t3[3];
  if (!$link) $link=$t3[2];
  $t1=explode('class="',$video);
  $t2=explode('"',$t1[1]);
  $server=$t2[0];
  $title=str_replace("<br />","",$v[$i])." - Server - ".$server;
  if ($link && preg_match("/fu|su|vk/",$server)) {
  $link = "filme_link.php?file=http".urlencode($link).",".urlencode($tit." ".$title);
		if ($n == 0) echo "<TR>"."\n\r";
		echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 3) {
         echo '</TR>'."\n\r";
         $n=0;
        }
   }
}
}
//last
$x=explode($v[count($v)-1],$html);
$vid=$x[1];
$videos=explode('hosts',$vid);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $t1=explode('href="',$video);
  $t2=explode('"',$t1[1]);
  $t3=explode("http",$t2[0]);
  $link=$t3[3];
  if (!$link) $link=$t3[2];
  $t1=explode('class="',$video);
  $t2=explode('"',$t1[1]);
  $server=$t2[0];
  $title=str_replace("<br />","",$v[$i])." - Server - ".$server;
  if ($link && preg_match("/fu|su|vk/",$server)) {
  $link = "filme_link.php?file=http".urlencode($link).",".urlencode($tit." ".$title);
		if ($n == 0) echo "<TR>"."\n\r";
		echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 3) {
         echo '</TR>'."\n\r";
         $n=0;
        }
   }
}
?>
<br></body>
</html>
