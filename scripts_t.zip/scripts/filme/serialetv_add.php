<?php
$title=$_POST["title"];
$link=$_POST["link"];
$mod=$_POST["mod"];
include ("../common.php");
$filename=$base_fav."serialetv.txt";
if ($mod=="add") {
if (file_exists($filename)) {
 $h=file_get_contents($filename);
 if (strpos($h,$link) ===false) $h=$h.$title."\n".$link."\n";
} else {
   $h=$title."\n".$link."\n";
}
$fh = fopen($filename, 'w');
fwrite($fh, $h);
fclose($fh);
echo "Am adaugat serialul: ".$title;
} elseif ($mod=="del") {
  $h=file($filename);
  $n=count($h);
  for ($k=0;$k<$n;$k=$k+2) {
   if ($link <> trim($h[$k+1])) $out=$out.trim($h[$k])."\n".trim($h[$k+1])."\n";
  }
$fh = fopen($filename, 'w');
fwrite($fh, $out);
fclose($fh);
echo "Am sters de la favorite serialul: ".$title;
}
?>
