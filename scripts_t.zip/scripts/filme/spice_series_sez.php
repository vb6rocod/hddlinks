<!DOCTYPE html>
<?php
include ("../common.php");
$cookie=$base_cookie."ustv.dat";
$link = urldecode($_GET["file"]);
$page_title=urldecode($_GET["title"]);

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
$t=explode('class="secosSeInfo',$html);
$t1=explode('src="',$t[1]);
$t2=explode('"',$t1[1]);
$img=$t2[0];
$gen=str_between($t[1],'Genuri:','</p>');
$gen=str_replace("&nbsp;"," ",$gen);
$gen = "Gen: ".trim($line1 = preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$gen));
$imdb="IMDB: ".trim(str_between($t[1],'Nota IMDb:</span>','</p>'));

$desc=str_between($t[1],'class="secosSeDesc">','</p>');
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="0">'."\n\r";
echo '<tr>'."\n\r";
$html=str_between($html,'class="secosSeSez"','</div>');
$videos = explode('href="', $html);

unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
   $t2=explode('"',$video);
   $link=$t2[0];

   $t3=explode('>',$video);
   $t4=explode('<',$t3[1]);
   $title=$t4[0];
   $link="spice_series.php?file=".urlencode($link).",".urlencode($page_title." - ".$title);
   echo '<td><font size="4"><a href="'.$link.'" target="_blank"><font size="4">'.$title.'&nbsp;|&nbsp;</font></a></td>';
}
echo '</tr></table><br>';
echo '<table border="0" width="100%"><tr>'."\n\r";
echo '<td align="center"><img src="'.$img.'" height="150px" width="500px"></td>';
echo '<td style=vertical-align:top;">'.$gen."<BR>".$imdb."<BR>".$desc.'</td></tr></table>';
?>
<br></body>
</html>
