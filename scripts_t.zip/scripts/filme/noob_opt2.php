<?php
$sub=$_POST["menu"];
include ("../common.php");
$noob_extra=$base_fav."noob_opt_f.dat";
$out=$sub;
$fh = fopen($noob_extra, 'w');
fwrite($fh, $out);
fclose($fh);
echo "Optiunile au fost salvate.";
?>
