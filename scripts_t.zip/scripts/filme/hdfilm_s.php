<!DOCTYPE html>
<?php
include ("../common.php");
$search = $_GET["src"];
$src=str_replace(" ","+",$search);
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $search; ?></title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
echo '<h2 style="background-color:deepskyblue;">'.$search.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
$l="http://www.hdfilm.ro/index.php?r=result";
$post="search_movie=".$src."&submit_search_movie=";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_REFERER, "http://www.hdfilm.ro");
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  $html = curl_exec($ch);
  curl_close($ch);
$videos = explode("<td width='51px'>", $html);
unset($videos[0]);
$videos = array_values($videos);
$n=0;
foreach($videos as $video) {
 $t1=explode("src='",$video);
 $t2=explode("'",$t1[1]);
 $image="http://www.hdfilm.ro/".$t2[0];
 
 $t1=explode("href='",$video);
 $t2=explode("'",$t1[1]);
 $link="http://www.hdfilm.ro/".$t2[0];
 $link="filme_link.php?file=".urlencode($link).",";
 $t3=explode(">",$t1[1]);
 $t4=explode("<",$t3[2]);
 $title=$t4[0];
 if ($n == 0) echo "<TR>"."\n\r";
 echo '<TD width="50px" align="center"><a href="'.$link.'" target="_blank"><img src="'.$image.'" width="47px" height="56px"><BR><font size="4">'.$title.'</font></a></TD>';
 $n++;
     if ($n > 4) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }

?>
</TABLE>
<br></body>
</html>
