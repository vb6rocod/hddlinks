<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$id = $_GET["file"];
$title = $_GET["title"];
$title=urldecode($title);
$title=str_replace("\'","'",$title);
$link="http://popcornered.com/films?films=".$id;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
$movie_name=str_between($h,'data-video="media/','"');
$srt_name=str_replace("mp4","srt",$movie_name);
$movie="http://popcornered.com/media/".$movie_name;
$file="http://hddlinks.netai.net/srt/".$id.".srt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $h = curl_exec($ch);
  curl_close($ch);
if ($h) {
$list = glob("../subs/*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
	$h=mb_convert_encoding($h, 'UTF-8');
	//$h=mb_convert_encoding($h, 'Windows-1252');
    $h = str_replace("ª","Ş",$h);
    $h = str_replace("º","ş",$h);
    $h = str_replace("Þ","Ţ",$h);
    $h = str_replace("þ","ţ",$h);
	$h = str_replace("ã","ă",$h);
	$h = str_replace("Ã","Ă",$h);


    $h = str_replace("Å£","ţ",$h);
    $h = str_replace("Å¢","Ţ",$h);
    $h = str_replace("Å","ş",$h);
	$h = str_replace("Ă®","î",$h);
	$h = str_replace("Ă¢","â",$h);
	$h = str_replace("Ă","Î",$h);
	$h = str_replace("Ã","Â",$h);
	$h = str_replace("Ä","ă",$h);
 
   $new_file = "../subs/".$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h);
   fclose($fh);
}

  $type="mp4";
  $mysrt="../subs/".$srt_name;
?>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title><?php echo urldecode($title); ?></title>

      <style type="text/css">
         html { height: 100%; }
         body { height: 100%; margin:0; padding:0; background: #000000 }
         table { border-spacing: 0; border-collapse: collapse }
         td { padding: 0 }
         #header { background: #000000 url('Noobroom_files/opa.png'); border-bottom: 1px solid #ffffff; height: 120px }
         #footer { background: #000000 url('Noobroom_files/opa.png'); border-top: 1px solid #ffffff; height: 60px }
         a.hoverz:link { text-decoration:underline; }
         a.hoverz:active { text-decoration:underline; }
         a.hoverz:visited { text-decoration:underline; }
         a.hoverz:hover { text-decoration:underline; }
         a.hoverz:visited:hover { text-decoration:underline; }
         .balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
      </style>


      <script src="http://p.jwpcdn.com/6/8/jwplayer.js"></script>
      <script>jwplayer.key='a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=';</script>

      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js?_=11226600"></script>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js?_=1251994273"></script>


   <body>



<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "<?php echo $movie; ?>", "type": "<?php echo $type; ?>"}],
"tracks": [{"file": "<?php echo $mysrt; ?>", "default": true}]
}],
    captions: {
        color: '#FFFFFF',
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"startparam": "start",
"fallback": false,
"primary": "html5",
"wmode": "direct",
"stagevideo": true
});

jwplayer("container").onReady(function(event){
if (jwplayer().getRenderingMode() == 'flash') {
//jwplayer().stop();
jwplayer().remove();
}
});
</script>


</body></html>
