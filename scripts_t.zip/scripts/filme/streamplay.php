<?php
$x=$_GET["link"];
file_put_contents("streamplay.txt",$x);
?>
