<!doctype html>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie=$base_cookie."vplus.dat";
$query = $_GET["file"];
if($query) {
   $queryArr = explode(',', $query);
   $link = urldecode($queryArr[0]);
   $pg_tit = urldecode($queryArr[1]);
}
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
$t1=explode('<div class="coll_poster"',$html);
$img=str_between($t1[1],"image:url(",")");
$description=str_between($t1[1],"<p>","</p>");
$gen=str_between($html,'Genuri:','</div>');
$gen = preg_replace("/(<\/?)([^>]*>)/e","",$gen);
?>
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title><?php echo $pg_tit; ?></title>
	<link rel="shortcut icon" href="http://i.vplus.ro/it/ic/favicon.png" type="image/x-icon">
	<link rel="stylesheet" href="http://i.vplus.ro/it/css/base.css?v=6.9" type="text/css">
	<link rel="stylesheet" href="http://i.vplus.ro/it/css/dropdown.css?v=6.9" type="text/css">
	<link rel="stylesheet" href="http://i.vplus.ro/it/css/navigation.css?v=6.9" type="text/css">
	<link rel="stylesheet" href="http://i.vplus.ro/it/css/comments.css?v=6.9" type="text/css">
	<link rel="stylesheet" href="http://i.vplus.ro/it/css/vplus.css?v=6.9" type="text/css">
	<link href="http://i.vplus.ro/it/css/dark.css?v=6.9" rel="stylesheet" type="text/css">
<link href="http://i.vplus.ro/it/css/catalogue.css?v=6.9" rel="stylesheet" type="text/css">
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>

	
	</head>
	<body onload="if(self != top) top.location = self.location;(new Tooltips()).init();fix_background();" class="dark_layout">
	<div class="wrapper">
		<div id="browser_ruler"></div>
		
		<script type="text/javascript">var logged = 1</script>
		
			<div class="clear"></div>
<div class="dark">
	<div class="center">
			<div class="breadcrumb" style="position:relative;">
				<ul>
					<li class="crumb">Seriale</li>
					<li class="sep"></li>
					<li class="crumb"><?php echo $pg_tit; ?></li>
				</ul>
				<div style="position:absolute; top: 4px; right:0px;"></div>
			</div>
			<div class="clear" style="height:7px;"></div>
			<div class="center content-container">
				<div id="content" style="padding-top:0px;">
					<div class="channels" style="padding-bottom:6px;">
						<div class="right_side">
							<strong>Genuri: <?php echo $gen; ?></strong>
						</div>
						<div class="clear"></div>
					</div>
					<div class="coll_poster" title="Dexter" style="background-image:url(<?php echo $img; ?>); position:relative;">
					
					</div>
					<div class="desc">
						
						<div class="clear" style=""></div>
						<p><?php echo $description; ?></p>
					</div>
					
					<div class="clear" style="height:10px;"></div>
					
					<div class="clear"></div>				
					<div class="dark-page-content">
						<div class="center">												
							<div class="clear" style="height:4px;"></div>
							<div id="tabs" class="tabs" data="tvshowkey">
								<ul id="tabs-ul">
<?php
$html1=str_between($html,'<ul id="tabs-ul">','</ul>');
$videos = explode("<li", $html1);

unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
   $t1=explode('href="',$video);
   $t2=explode('"',$t1[1]);
   $link="http://vplus.ro".$t2[0];

   $title=str_between($video,'<span>','</span>');


   $image=$img;
   $s=$pg_tit."-".$title;
   $link = "vplay.php?file=".urlencode($link).",".urlencode($s);
    echo '
     <li class="tab"><a class="" href="'.$link.'"><span>'.$title.'</span></a></li>
    ';
}
?>
									</ul>
								<div class="clear"></div>
								<div id="tabs-content">
									<ul>
<?php
$html=str_between($html,'div id="tabs-content">','</ul>');
$videos = explode('<li', $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  $t1 = explode('href="', $video);
  $t2 = explode('"', $t1[1]);
  $link = $t2[0];
  $link = "http://vplus.ro".$link;

  $t1 = explode('background-image:url(', $video);
  $t2 = explode(')', $t1[1]);
  $image = trim($t2[0]);
  //echo $image;


  $t1 = explode('title="', $video);
  $t2 = explode('"', $t1[1]);
  $title = htmlspecialchars_decode($t2[0]);
  $link='vplus_link.php?file='.$link.'&title='.$title.' " target="_blank"';
  $subs=str_between($video,'watch subs">','<');
  if (strpos($video,"Watched") !== false)
    $watch = "Watched";
  else
    $watch = "";
  echo '
  <li>
  <a href="'.$link.'" title="'.$title.'" class="coll-episode-box">
  <span class="thumb"><span style="background-image:url('.$image.');"></span></span>
  <span class="title" title="'.$title.'">'.$title.'</span>
  ';
  if ($watch)
    echo '<span class="watch"><span class="tick"></span>'.$watch.'</span>';
  echo '
  <span class="watch subs">'.$subs.'</span>
  </a>
  </li>
  ';
}
?>
</ul>
									<div class="clear"></div>
								</div>
							<div class="clear"></div>						
						</div>
					</div>
					<div class="clear" style="height:10px;"></div>
					
					<div class="clear" style="height:10px;"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="clear" style="height:10px;"></div>
</div>
		<div class="push"></div>

	<br></body>
	
	</html>
