<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />

      <meta charset="utf-8">
      <title>Seriale - filmesubtitrate.info</title>
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>


<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(title, link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'mod=add&title='+ title +'&link='+link;
  var php_file='filmesubtitrate_add.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
    }
  }
}
</script>
</head>
<body>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function decode_entities($text) {
    $text= html_entity_decode($text,ENT_QUOTES,"ISO-8859-1"); #NOTE: UTF-8 does not work!
    $text= preg_replace('/&#(\d+);/me',"chr(\\1)",$text); #decimal notation
    $text= preg_replace('/&#x([a-f0-9]+);/mei',"chr(0x\\1)",$text);  #hex notation
    return $text;
}
//unlink ("/data/data/ru.kslabs.ksweb/tmp/roshare.dat");
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="6" align="center"><font size="4"><b>filmesubtitrate.info</b></font></TD></TR>';
echo '<TR><TD colspan="6" align="left"><a href="filmesubtitrate_fav.php"><font size="4"></b>Seriale Favorite<b></font></a></TD></TR>';
$n=0;
$l="http://www.seriale.filmesubtitrate.info/p/seriale-online-subtitrate-in-romana.html";
$l="http://www.fsplay.net/p/seriale-online-subtitrate-in-romana.html";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.fsplay.net");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html=curl_exec($ch);
  curl_close($ch);
  $html= decode_entities($html);

//$html = str_between($html,'<tr class="trxnoi">','<div class="footer1-wrapper">');
$a=explode('<tr class="trxnoi">',$html);
$html=$a[1];
	$videos=explode('href="',$html);
	unset($videos[0]);
	$videos=array_values($videos);
	foreach($videos as $video) {
		$t1=explode('"',$video);
		$link1=trim($t1[0]);
		$t3=explode(">",$video);
		$t4=explode("<",$t3[1]);
		$title=$t4[0];
		$title=preg_replace("/onlin(.*)|sub(.*)|seri(.*)|film(.*)/si","",$title);
		$title=trim(str_replace("&nbsp;","",$title));
		$link = "filmesubtitrate_info.php?query=".$link1.",".urlencode($title);
		if ($n == 0) echo "<TR>"."\n\r";
        if (($title <> "") && (strpos($link,"html") !==false)) {
          echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
          echo '<TD align="right" size="5px"><a onclick="ajaxrequest('."'".$title."', '".$link1."')".'"'." style='cursor:pointer;'>".'<font size="4">FAV</font></a></TD>'."\n\r";
        $n++;
        if ($n > 2) {
         echo '</TR>'."\n\r";
         $n=0;
        }
		}
	}
echo '</table>';
?>
<br></body>
</html>
