<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
      <meta charset="utf-8">
      <title>Favorite</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>



<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(title, link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:del,title:title, link:link}; //Array
  var the_data = 'mod=del&title='+ title +'&link='+link;
  var php_file='990_add.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
      location.reload();
    }
  }
}
</script>
</head>
<body><h4></h4>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
echo '<table align="center" border="1" width="100%">'."\n\r";
echo '<TR><td style="background-color:deepskyblue;color:black;text-align:center;" colspan="6"><b><font size="4">FAVORITE</font></b></TD></TR>';
$n=0;
include ("../common.php");
$filename=$base_fav."990.txt";
if (file_exists($filename)) {
  $h=file($filename);
  //print_r ($h);
  $m=count($h);
  for ($k=0;$k<$m;$k=$k+2) {

   $title=trim($h[$k]);
   $link1=trim($h[$k+1]);
   $arr[]=array($title, $link1);
  }
if( !empty( $arr ) ) {
asort($arr);
foreach ($arr as $key => $val) {
  $link1=$arr[$key][1];
  $title=$arr[$key][0];
  if ($n == 0) echo "<TR>"."\n\r";
   //$link = "filmesubtitrate_info.php?query=".$link1.",".urlencode($title);
   $link="990_seriale.php?file=".$link1.",".urlencode($title);
   echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
   //$n++;
   echo '<TD align="right" width="5px"><a onclick="ajaxrequest('."'".$title."', '".$link1."')".'"'." style='cursor:pointer;'>".'<font size="4">DEL</font></a></TD>'."\n\r";
   $n++;
   if ($n > 2) {
   echo '</TR>'."\n\r";
   $n=0;
   }
}
}
if ($n<3) echo '</TR>'."\n\r";
echo '</table>';
}
?>
<br></body>
</html>
