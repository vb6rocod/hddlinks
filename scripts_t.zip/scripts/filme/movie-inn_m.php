<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$page = $_GET["page"];
$filename = $base_pass."movie-inn.txt";
$cookie=$base_cookie."movie-inn.dat";
if (file_exists($filename)) {
  $handle = fopen($filename, "r");
  $c = fread($handle, filesize($filename));
  fclose($handle);
  $a=explode("|",$c);
  $user=$a[0];
  $pass=trim($a[1]);
if (!file_exists($cookie)) {
  $l="http://www.movie-inn.com/checkpass.php";
  $post="name=".$user."&pass=".$pass."&submit=Login";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.movie-inn.com/index.php");
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
}
}
  $link="http://www.movie-inn.com/main.php?p=".$page;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.movie-inn.com/main.php?movies");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
$pg=str_between($html,'<div style="float: right; display: inline;">','<br/>');
$pg=str_replace("p=","page=",$pg);
$pg=str_replace('./','http://www.movie-inn.com/',$pg);
$pg='<br/><div style="float: right; display: inline;">'.$pg.'<br/><br/>&nbsp;</div><br></body></html>';

?>
<html>

	<title>.::Movie Inn::.</title>

			<head>
			<meta http-equiv="Content-type" content="text/html; charset=utf-8">
			<link rel="stylesheet" href="http://www.movie-inn.com/css/style.css" type="text/css" />
			<link rel="stylesheet" type="text/css" href="../custom.css" />
			<!--genres button-->
				<script type="text/javascript" src="http://www.movie-inn.com/js/jquery-ui-1.8.2.custom.min.js"></script>

			<script>
			$(function () {
			  $("#fixed-bar")
			    .css({position:'fixed',bottom:'0px'})
			    .hide();
			  $(window).scroll(function () {
			    if ($(this).scrollTop() > 400) {
			      $('#fixed-bar').fadeIn(200);
			    } else {
			      $('#fixed-bar').fadeOut(200);
			    }
			  });
			  $('.go-top').click(function () {
			    $('html,body').animate({
			      scrollTop: 0
			    }, 1000);
			    return false;
			  });
			});
			</script>
		    <div id="fb-root"></div>
		</head>

	<body id="top">

		<div id="content">
			<div style="font-size:13px;"><br/>
<?php
$out="";
$videos = explode('<div style="padding:', $html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
 $video=str_replace("./","http://www.movie-inn.com/",$video);
 $video=str_replace("movie.php","movie-inn_link.php",$video);
 $out=$out.'<div style="padding:'.$video;
}
$t1=explode("</div></div>",$out);
$out=$t1[0].'</div></div>'.$pg;
echo $out;
?>
