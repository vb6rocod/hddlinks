<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>popcornered</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie=$base_cookie."popcornered.dat";
$pop=$base_pass."popcornered.txt";
if (file_exists($pop) && !file_exists($cookie)) {
  $handle = fopen($pop, "r");
  $c = fread($handle, filesize($pop));
  fclose($handle);
  $a=explode("|",$c);
  $a1=str_replace("?","@",$a[0]);
  $user=urlencode($a1);
  $user=str_replace("@","%40",$user);
  $pass=trim($a[1]);

$l="http://popcornered.com/login";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);

  $token=str_between($html,'name="_token" type="hidden" value="','"');
  
  $post="_token=".$token."&login_username=".$user."&login_password=".$pass."&checkbox=yes";
  curl_setopt ($ch, CURLOPT_REFERER, "http://popcornered.com/login?login");
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  $html = curl_exec($ch);
  curl_close($ch);
  //if (strpos($html,"Thanks for logging in") !== false) echo "LOGOUT!!!!!!!!!!!!!!!";
}
$init="http://popcornered.com/search_results?covers";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $init);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><td style="background-color:deepskyblue;text-align:center;color:black;" colspan="4"><font size="4"><b>popcornered</b></font></TD></TR>';
echo '<TR><TD colspan="4"><font size="4"><form action="popcornered_s.php" target="_blank">Cautare film:  <input type="text" id="page" name="page"><input type="submit" value="send"></form></font></td>
</TR>';
echo '<TR><TD><font size="4">'.'<a href="popcornered.php?page=1,new,Cele+mai+noi" target="_blank"><b>Cele mai noi</b></a></font></TD>';
echo '<TD><font size="4">'.'<a href="popcornered.php?page=1,a-z,Alfabetic" target="_blank"><b>Alfabetic</b></a></font></TD>';
echo '<TD><font size="4">'.'<a href="popcornered.php?page=1,year,By+Year" target="_blank"><b>By Year</b></a></font></TD>';
echo '<TD><font size="4">'.'<a href="popcornered.php?page=1,rating,Highest+Rated" target="_blank"><b>Highest Rated</b></a></font></TD></TR>';

echo "</TR>"."\n\r";
echo '</table>';
?>
<p>Contribuiti cu subtitrari <a href="http://hddlinks.netai.net/popcornered_main.php" target="_blank"><b>aici</b>.</a></p>
<BODY>
</HTML>
