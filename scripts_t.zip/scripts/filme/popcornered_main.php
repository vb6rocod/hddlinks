<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>popcornered</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><td style="background-color:deepskyblue;text-align:center;color:black;" colspan="4"><font size="4"><b>popcornered</b></font></TD></TR>';
echo '<TR><TD colspan="4"><font size="4"><form action="popcornered_s.php" target="_blank">Cautare film:  <input type="text" id="page" name="page"><input type="submit" value="send"></form></font></td>
</TR>';
echo '<TR><TD><font size="4">'.'<a href="popcornered.php?page=1,new,Cele+mai+noi" target="_blank"><b>Cele mai noi</b></a></font></TD>';
echo '<TD><font size="4">'.'<a href="popcornered.php?page=1,a-z,Alfabetic" target="_blank"><b>Alfabetic</b></a></font></TD>';
echo '<TD><font size="4">'.'<a href="popcornered.php?page=1,year,By+Year" target="_blank"><b>By Year</b></a></font></TD>';
echo '<TD><font size="4">'.'<a href="popcornered.php?page=1,rating,Highest+Rated" target="_blank"><b>Highest Rated</b></a></font></TD></TR>';

echo "</TR>"."\n\r";
echo '</table>';
?>
<p>Contribuiti cu subtitrari <a href="http://hddlinks.netai.net/popcornered_main.php" target="_blank"><b>aici</b>.</a></p>
<BODY>
</HTML>
