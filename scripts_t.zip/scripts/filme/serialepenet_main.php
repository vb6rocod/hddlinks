<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
      <meta charset="utf-8">
      <title>serialepenet.ro</title>
</head>
<body><h3></h3>
<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$pass = trim(file_get_contents($base_pass."serialepenet.txt"));
$check="http://hddlinks.pht.ro/c.php?";
if ($pass) {
$lp=$check."s5=".$pass;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $lp);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_exec($ch);
  curl_close($ch);
}
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="3"><font size="4">Serialepenet.ro</font></TD></TR>';
echo '<TR><TD colspan="3"><a href="serialepenet_fav.php"><font size="4"><b>Favorite</b></font></TD></TR>';
$n=0;
$html = file_get_contents("http://serialepenet.ro/lista_seriale");
$videos = explode('views-summary views-summary-unformatted', $html);

unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
   $t1=explode('href="',$video);
   $t2=explode('"',$t1[1]);
   $link="http://serialepenet.ro".$t2[0];
   $t3=explode(">",$t1[1]);
   $t4=explode("<",$t3[1]);
   $title="Litera: ".$t4[0];
   $link = "serialepenet_lit.php?file=".$link.",".urlencode($title);
   if ($n == 0) echo "<TR>"."\n\r";
   echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
   echo '</TD>'."\n\r";
   $n++;
   if ($n > 2) {
   echo '</TR>'."\n\r";
   $n=0;
   }
}
//
// Categorie
$t1=explode('<h3>Categorii</h3>',$html);
$html=$t1[1];
$videos = explode('<span class="field-content">', $html);

unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
   $t1=explode('href="',$video);
   $t2=explode('"',$t1[1]);
   $link="http://serialepenet.ro".$t2[0];
   $t3=explode(">",$t1[1]);
   $t4=explode("<",$t3[1]);
   $title=$t4[0];
   $link = "serialepenet_cat.php?file=".$link.",".urlencode($title);
   if ($n == 0) echo "<TR>"."\n\r";
   echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
   echo '</TD>'."\n\r";
   $n++;
   if ($n > 2) {
   echo '</TR>'."\n\r";
   $n=0;
   }
}
 if ($n < 3) {
 echo '</TR>';
 $n=0;
 }
?>
</table>
<br></body>
</html>
