<!DOCTYPE html>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
//$tit = urldecode($_GET["title"]);
$noob=file_get_contents($base_cookie."n.dat");
$cookie=$base_cookie."noob.dat";
$noob_serv=$base_cookie."noob_serv.dat";
$f=$base_pass."airfun.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$air=$t1[0];
} else {
$air="NU";
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />

      <meta charset="utf-8">
      <title>Noobroom - Seriale</title>


	  
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="func.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
    function myFunc(url2) {
         msg = 'noobroom_link.php?query=' + url2 + '&serv=' + document.getElementById('menu').value;
         window.open(msg);
    }
</script>
<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(title, link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'mod=add&title='+ title +'&link='+link;
  var php_file='noob_s_add.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
    }
  }
}
</script>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
  </head>
   <body>

	<div class="balloon"></div>
<h2 style="background-color:deepskyblue;color:black;text-align:center;">Seriale</H2>
<p><b>PIC - poster film, FAV - adauga la favorite.</b></p>
<?php
echo '
<table border="1px" width="100%">
';
$n=0;
$l=$noob."/series.php";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);

$videos = explode('<table>', $html);
unset($videos[0]);
$videos = array_values($videos);

$title="";
$year="";
$link="";

foreach($videos as $video) {
  $t1 = explode("href='", $video);
 if (sizeof ($t1) > 1 ) {
  $t2 = explode("'", $t1[1]);
  $link =$noob.$t2[0];
  $link1=$t2[0];


  $t3 = explode('>', $t1[2]);
  $t2 = explode('<', $t3[1]);
  $title = trim($t2[0]);
  $title=str_replace("&amp;","&",$title);
  $title=str_replace("&","&amp;",$title);
  $title=str_replace("\'","'",$title);
  $t1=explode("src='",$video);
  $t2=explode("'",$t1[1]);
  if (strpos($t2[0],"http")=== false)
    $img=$noob."/".$t2[0];
  else
    $img=$t2[0];
 }
  if (strpos($link,"episodes") !==false) $arr[]=array($title, $link1,$img);
}
if ($arr) {
asort($arr);
foreach ($arr as $key => $val) {
 $title=$arr[$key][0];
 $link1=$arr[$key][1];
 $img=$arr[$key][2];
 $link=$noob.$link1;
 $link="noob_s1.php?query=".urlencode($link)."&title=".urlencode($title);
   if ($n == 0) echo "<TR>"."\n\r";
   if ($air=="DA") {
   echo '
   <TD><font size="4"><a class="tippable" id="'.$img.'" href="'.$link.'" target="_blank">'.$title.'</font></a></TD>
   ';
   echo '<td style="text-align:right;width:5px"><a class="fancybox" href="'.$img.'" title=""><b>PIC</b></a>|<a onclick="ajaxrequest('."'".$title."', '".$link1."')".'"'." style='cursor:pointer;'>".'<b>FAV</b></a></TD>'."\n\r";
   $k = 2;
   } elseif ($air=="NU") {
   echo '
   <TD><font size="4"><a href="'.$link.'" target="_blank">'.$title.'</font></a></TD>
   ';
   echo '<td style="text-align:right;width:5px"><a class="fancybox" href="'.$img.'" title=""><b>PIC</b></a>|<a onclick="ajaxrequest('."'".$title."', '".$link1."')".'"'." style='cursor:pointer;'>".'<b>FAV</b></a></TD>'."\n\r";
   $k = 2;
   } else {
   echo '
   <TD align="center" width="20%"><a href="'.$link.'" target="_blank"><img src="'.$img.'" width="160px" height="224px"><BR><font size="4">'.$title.'</font></a><BR><a onclick="ajaxrequest('."'".$title."', '".$link1."')".'"'." style='cursor:pointer;'>".'<b>FAV</b></a></TD>
   ';
   $k = 5;
   }
   //echo '</TD>'."\n\r";
    $n++;
    if ($n == $k) {
     echo '</TR>'."\n\r";
     $n=0;
    }
}
}
if ($n<3) echo "</TR>"."\n\r";
echo "</TABLE>";
?>
<br></body>
</html>
