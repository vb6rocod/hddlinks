<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />

      <meta charset="utf-8">
      <title>Seriale - filmesubtitrate.info</title>
<?php
$query = $_GET["query"];
if($query) {
   $queryArr = explode(',', $query);
   $link = $queryArr[0];
   $pagetitle = trim(urldecode($queryArr[1]));
   $pagetitle=str_replace(urldecode("%C2%A0"),"",$pagetitle);
}
echo '<title>'.$pagetitle.'</title>';
echo '</head><body><h2></h2>
';
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function decode_entities($text) {
    $text= html_entity_decode($text,ENT_QUOTES,"ISO-8859-1"); #NOTE: UTF-8 does not work!
    $text= preg_replace('/&#(\d+);/me',"chr(\\1)",$text); #decimal notation
    $text= preg_replace('/&#x([a-f0-9]+);/mei',"chr(0x\\1)",$text);  #hex notation
    return $text;
}

$link=str_replace("www.filmesubtitrate.info","www.seriale.filmesubtitrate.info",$link);
$pagelink=$link;
$n=0;
$m=0;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.fsplay.net");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html=curl_exec($ch);
  curl_close($ch);
  $html= decode_entities($html);
$serial_file=substr(strrchr($link,"/"),1);
$serial_file=ltrim($serial_file,"seriale-online-");
$pos=strlen(stristr($serial_file, '-'));
if ($pos >= 1) {
	$serial=substr($serial_file,0,-$pos);
} else {
	$serial=substr($serial_file,0,-1*(strlen($serial_file)-5));
}
$t=explode(" ",$pagetitle);
$s="/";
for ($i=0;$i<count($t);$i++) {
 if (($t[$i] <> "") && (strlen($t[$i])>1) &&(!preg_match("/the|2010|2011|2012/i",$t[$i])))
    $s=$s."".$t[$i]."|";
}
$s=substr($s,0,-1);
$s=$s."/i";
//echo $s;
//10-things
if ($serial=="10") $serial="10-things";
if ($serial=="greys") $serial="grey";
//if (!$serial) $serial="-";
$find="/".$serial."|nobels"."/";
//echo $find;
$a1=explode("<tbody>",$html);
$c=count($a1);
//echo $c;
//if ($c==1) $c=2;
$m=0;
for ($k=1;$k<$c;$k++) {
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="2"><font size="4">'.$pagetitle.'</font></TD></TR>';
$a2=explode("</tbody>",$a1[$k]);
$html=$a2[0];
$videos=explode('<li',$html);
unset($videos[0]);
$videos=array_values($videos);
foreach($videos as $video) {
    $video=str_replace('<span class="Apple-style-span" style="font-size: large;">','',$video);
	$t1=explode('href="',$video);
	$t2=explode('"',$t1[1]);
	$link=trim($t2[0]);

	$t3=explode(">",$t1[1]);
	$t4=explode("<",$t3[1]);
	$title=$t4[0];
	//echo $link."<BR>".$title."<BR>";
	//$title=preg_replace("/onlin(.*)|sub(.*)|seri(.*)|film(.*)/si","",$title);
	$title=trim(str_replace("&nbsp;","",$title));
	//case 24 s6 ep 2
	if ($title == "") {
		$t1=explode('href="',$video);
		$t2=explode('"',$t1[2]);
		$link=trim($t2[0]);
		$t3=explode(">",$t1[2]);
		$t4=explode("<",$t3[1]);
		$title=trim($t4[0]);
		$title=str_replace("&nbsp;","",$title);
	}
	//$title=preg_replace("/onlin(.*)|sub(.*)|seri(.*)|film(.*)/si","",$title);
	$title=trim(str_replace("&nbsp;","",$title));
	if ($title) {
        $m++;
		$link="filme_link.php?file=".urlencode($link).",".urlencode($title);
		if ($n == 0) echo "<TR>"."\n\r";
		echo '<TD><font size="4">'.'<a href="'.$link.'">'.$title.'</a></font>';
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 1) {
         echo '</TR>'."\n\r";
         $n=0;
        }
	}
}
echo '</table>';
}

if ($c==1) {
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="2"><font size="4">'.$pagetitle.'</font></TD></TR>';
$m=0;
$html=str_between($html,'div class="contnew','<div class');
$videos=explode('<li',$html);
unset($videos[0]);
$videos=array_values($videos);
foreach($videos as $video) {
    $video=str_replace('<span class="Apple-style-span" style="font-size: large;">','',$video);
	$t1=explode('href="',$video);
	$t2=explode('"',$t1[1]);
	$link=trim($t2[0]);

    /*
    $t1=explode("<span",$video);
	$t2=explode(">",$t1[1]);
	$t4=explode("<",$t2[1]);
	$title=$t4[0];
	*/
	$t3=explode(">",$t1[1]);
	$t4=explode("<",$t3[1]);
	$title=$t4[0];
	//echo $link."<BR>".$title."<BR>";
	//$title=preg_replace("/onlin(.*)|sub(.*)|seri(.*)|film(.*)/si","",$title);
	$title=trim(str_replace("&nbsp;","",$title));
	//case 24 s6 ep 2
	if ($title == "") {
		$t1=explode('href="',$video);
		$t2=explode('"',$t1[2]);
		$link=trim($t2[0]);
		$t3=explode(">",$t1[2]);
		$t4=explode("<",$t3[1]);
		$title=trim($t4[0]);
		$title=str_replace("&nbsp;","",$title);
	}
	//$title=preg_replace("/onlin(.*)|sub(.*)|seri(.*)|film(.*)/si","",$title);
	$title=trim(str_replace("&nbsp;","",$title));
	//if ((preg_match($find, $link) !== false) && ($link <> $queryArr[0]) && ($title <> "")  && (preg_match($s,$link))){
	//if (preg_match($s,$link)) {
	if ($title && preg_match("/ep|part/i",$link)) {
	$m++;
        $m++;
		$link="filme_link.php?file=".urlencode($link).",".urlencode($title);
		if ($n == 0) echo "<TR>"."\n\r";
		echo '<TD><font size="4">'.'<a href="'.$link.'">'.$title.'</a></font>';
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 1) {
         echo '</TR>'."\n\r";
         $n=0;
        }
	}
}
echo '</table>';
}
if ($m < 1) {
$link="filme_link.php?file=".urlencode($link).",".urlencode($pagetitle);
echo '<font size="4">'.'<a href="'.$link.'">'.$pagetitle.'</a></font>';
}
?>
<br></body>
</html>
