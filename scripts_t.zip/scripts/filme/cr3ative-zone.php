<!DOCTYPE html>
<?php
include ("../common.php");
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page = $queryArr[0];
   $search = $queryArr[1];
   $page_title=urldecode($queryArr[2]);
   $search=str_replace("|","&",$search);
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
//http://www.hdfilm.ro/index.php?p=filme&gen=Actiune&page=1
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="2" align="right">';
$search1=str_replace("&","|",$search);
if ($page > 1)
echo '<a href="cr3ative-zone.php?page='.($page-1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="cr3ative-zone.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="cr3ative-zone.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
$html=file_get_contents(urldecode($search)."-".$page."-2");
$videos = explode('div class="user-avatar-', $html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {

//  link
  $v1 = explode('href="', $video);
  $v2 = explode('"', $v1[1]);
  $link = $v2[0];

//  titlu

  $v3 = explode('title="',$video);
  $v4 = explode('"',$v3[1]);
  $v5 = explode("Online",$v4[0]);
  $title = trim($v5[0]);

//  imagine
  //$v0=explode("images--",$video);
  $v1 = explode('src="', $video);
  $v2 = explode('"', $v1[1]);
  $image = $v2[0];
//  descriere
  $v1 = explode('class="cell-news-center">', $video);
  $v2 = explode('</p', $v1[1]);
  //$v3=explode("calitate de exceptie.",$v2[0]);
  $descriere = $v2[0];
  $descriere = preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$descriere);
	if (strlen($descriere)>=1000) {
       $descriere = substr($descriere,0,1000);
       $descriere = substr($descriere,0,-strlen(strrchr($descriere," ")))."...";
       }
  echo '<TR>';
  echo '<td align="center"><a href="filme_link.php?file='.urlencode($link).',"><img src="'.$image.'" width="200px" height="280px"><BR><font size="4">'.$title.'</font></a></TD>';
  echo '<td style="vertical-align:top;">'.$descriere.'</td>';
  echo '</tr>';
}
echo '<tr><TD colspan="2" align="right">';
$search1=str_replace("&","|",$search);
if ($page > 1)
echo '<a href="cr3ative-zone.php?page='.($page-1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="cr3ative-zone.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="cr3ative-zone.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>
