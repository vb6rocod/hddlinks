<?php
include ("../common.php");
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$id = $_GET["file"];
$title = $_GET["title"];
$year = $_GET["year"];
$image = $_GET["image"];
$id1= $_GET["out"];
$file="http://panel.erstream.com/api/er/Get?cid=".$id."&format=8&customerid=16&action=redirect&id=".$id."";
$h=file_get_contents($file);
/*
//pentru mp4
$file="http://panel.erstream.com/api/er/Get?cid=".$id."&format=4&customerid=16&action=redirect&id=".$id."";
$r=get_headers($file);
$out=trim(str_between($r[4],"Location:","mp4"))."mp4";
//
*/
$movie_file=$title.".m3u8";
$title = preg_replace('~[^\\pL\d.]+~u', ' ', $title);
  $link=str_between($h,'<id>','</id>');
  $out="http://w-bk1.ercdn.net/filmbox/_definst_/smil:".$link."/".$movie_file;
//$out="http://spi-live.ercdn.net/spi/docuboxhd_0_3/playlist.m3u8";
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "m3u8"}],
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": "../hd4all.xml",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
';
}
?>
</BODY>
</HTML>

