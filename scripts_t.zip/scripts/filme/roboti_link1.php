<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function s_dec($s) {
/*
	By: Nick A. Gaun
	Sekator500 <sekator500@gmail.com>
*/

	$sA = str_split($s);
	$sA = array_reverse($sA);
	$sA = array_slice($sA,3);
	$tS = $sA[0];
	$sA[0] = $sA[19 % count($sA)];
	$sA[19] = $tS;
	$sA = array_reverse($sA);
	$sA = array_slice($sA,2);

	return implode($sA);
}
include ("../common.php");
$cookie=$base_cookie."vimeo.dat";
$link = $_GET["file"];
$cur_link=urldecode($link);
$a_itags=array(37,22,18);
if(preg_match('/youtube\.com\/(v\/|watch\?v=|embed\/)([\w\-]+)/', $cur_link, $match)) {
  $id = $match[2];
  $link = 'http://www.youtube.com/get_video_info?&video_id=' . $id . '&el=leanback&ps=xl&eurl=https://s.ytimg.com/yts/swfbin/apiplayer-vflhRmAoN.swf&hl=en_US&sts=1588';
  //echo $link;
  //$html=file_get_contents($link);
  //$html = urldecode($html);
  //$link   = "http://www.youtube.com/watch?v=".$id;
  //echo $link;
  $html   = file_get_contents($link);
  //echo $html;
  //preg_match('#config = {(?P<out>.*)};#im', $html, $out);
  //$parts  = json_decode('{'.$out['out'].'}', true);
  //print_r ($parts);
  //$videos = explode(',', $parts['args']['url_encoded_fmt_stream_map']);
  parse_str($html,$parts);
  $videos = explode(',',$parts['url_encoded_fmt_stream_map']);
foreach ($videos as $video) {
//		$vid = urldecode(urldecode($video));
		//$vid = str_replace(array('sig=', '---'), array('signature=', '.'), $vid);
/**		$vid=str_replace('"',"",$vid);
		$vid=str_replace('sig=',"signature=",$vid);
		$vid=str_replace(" ","%20",$vid);
		parse_str($vid, $output);
**/
		parse_str($video, $output);

		if (in_array($output['itag'], $a_itags)) break;
	}
	//$path = $output['url'].'&';
	//echo $path;
//  unset($output['url']);

	//if (isset($output['fexp']))          unset($output['fexp']);
	if (isset($output['type']))          unset($output['type']);
	if (isset($output['mv']))            unset($output['mv']);
	if (isset($output['sver']))          unset($output['sver']);
	if (isset($output['mt']))            unset($output['mt']);
	if (isset($output['ms']))            unset($output['ms']);
	if (isset($output['quality']))       unset($output['quality']);
	if (isset($output['codecs']))        unset($output['codecs']);
	if (isset($output['fallback_host'])) unset($output['fallback_host']);

	//$r=urldecode($path.http_build_query($output));
	if (isset($output['sig'])) {
		$signature=($output['sig']);
	} else {
		$signature=s_dec($output['s']);
	}
	$link=$output['url']."&signature=".$signature;
	$out=$link;
	//echo $out;
  }
if (strpos($cur_link,'vimeo.com') !==false){
if (strpos($cur_link,"player.vimeo.com") !== false) {
//$link= "http://127.0.0.1/cgi-bin/scripts/util/vimeo.cgi?stream,,".urlencode($cur_link);
     $t1=explode("?",$cur_link);
     $cur_link=$t1[0];
     $t1=explode("/",$cur_link);
     $id=$t1[4];
  } else {
     $t1=explode("/",$cur_link);
     $id=$t1[3];
  }
  $cookie=$base_cookie."vimeo.dat";
  $l="http://vimeo.com/".$id;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  $l1=str_between($html,'data-config-url="','"');
  $l1=str_replace("&amp;","&",$l1);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h1 = curl_exec($ch);
  curl_close($ch);
  //echo $h1;
  if (strpos($h1,'hd":') !== false) {
    $t1=explode('hd":',$h1);
    $link=str_between($t1[1],'url":"','"');
  } else {
    $t1=explode('sd":',$h1);
    $link=str_between($t1[1],'url":"','"');
  }
/*

  $l1="http://player.vimeo.com/config/".$id."?type=moogaloop&referrer=vimeo.com&cdn_server=a.vimeocdn.com&player_server=player.vimeo.com&clip_id=".$id;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h1 = curl_exec($ch);
  curl_close($ch);

  $sig_param=str_between($h1,'signature":"','"');
  $player_url=str_between($h1,'player_url":"','"');
  $time_param=str_between($h1,'"timestamp":',',');
  if (strpos($h1,'hd":0') !== false)
    $hd="sd";
  else
    $hd="hd";
  $stream_url="http://".$player_url."/play_redirect?clip_id=".$id."&sig=".$sig_param."&time=".$time_param."&quality=".$hd."&codecs=H264,VP8,VP6&type=moogaloop&embed_location=&seek=0";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $stream_url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://a.vimeocdn.com/p/flash/moogaloop/5.2.49/moogaloop.swf?v=1.0.0");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch, CURLOPT_NOBODY, true);
  curl_setopt($ch, CURLOPT_HEADER  ,1);
  $html = curl_exec($ch);
  curl_close($ch);
  $t1=explode("Location:",$html);
  $t2=explode("\n",$t1[1]);
  $link=trim($t2[0]);
*/
  $out=$link;
}
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="video.mp4"');
header("Location: $out");
?> 
