<?php
$sub=$_POST["menu"];
$alf=$_POST["opt"];
include ("../common.php");
$noob_extra=$base_fav."noob_opt_p.dat";
$out=$sub."|".$alf;
$fh = fopen($noob_extra, 'w');
fwrite($fh, $out);
fclose($fh);
echo "Optiunile au fost salvate.";
?>
