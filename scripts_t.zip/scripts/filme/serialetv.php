<?php
include ("../common.php");
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$query = $_GET["file"];
$queryArr = explode(',', $query);
$link = urldecode($queryArr[0]);
$tit = urldecode($queryArr[1]);
$html = urldecode(file_get_contents($link));
//echo $html;
$videos = explode('section caption="', $html);

unset($videos[0]);
$videos = array_values($videos);
//$videos = array_reverse($videos);
foreach($videos as $video) {
    $t3=explode('Site/redirect/?to=',$video);
    $t4=explode('"',$t3[1]);
    $link=urldecode($t4[0]);
    if (!$link) {
    $t3=explode('superweb?superweb=',$video);
    $t4=explode('"',$t3[1]);
    $link=urldecode($t4[0]);
    }
    $title = str_between($link,"http://","/");
    if (preg_match("/roshare|rosharing|vk\.com|fasupload|superweb/",$link))
      $l[$link]=$title;
}
if (count($l)==1) {
$dir_actual="http://127.0.0.1:8080/scripts/filme/";
if (!file_exists("D:\\Program Files\\xampp\\htdocs\\mobile\\"))
$movie=file_get_contents($dir_actual."link.php?file=".key($l));
else
$movie=file_get_contents("http://127.0.0.1/mobile/scripts/filme/link.php?file=".urlencode(key($l)));
$movie_file=substr(strrchr($movie, "/"), 1);
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
} else {
echo '
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Alege varianta</title>
   	  <link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>';
echo '<h2 style="background-color:deepskyblue;color:black">'.$tit."</H2>";
echo "<H2>Alegeti una din variantele de mai jos</H2>";
foreach($l as $key => $value) {
 echo '<a href="link1.php?file='.urlencode($key).'" target="_blank"><font size="6">'.$value.'</font></a><BR>';
}
echo '<br></body>
</html>';
}
?>
