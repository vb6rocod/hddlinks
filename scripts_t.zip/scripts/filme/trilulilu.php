<!DOCTYPE html>
<?php
include ("../common.php");
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page = $queryArr[0];
   $search = $queryArr[1];
   $page_title=urldecode($queryArr[2]);
   $search=str_replace("|","&",$search);
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
//http://www.hdfilm.ro/index.php?p=filme&gen=Actiune&page=1
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="trilulilu.php?page='.($page-1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="trilulilu.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="trilulilu.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
if (strpos($search,"canal/") === false) {
$page1=25*($page-1);
} else {
$page1=12*($page-1);
}
//http://www.trilulilu.ro/muzica?ref=header&mimetype=&offset=25
$search=urldecode($search);
if (strpos($search,"cele-mai-tari") === false)
  $html=file_get_contents($search."&offset=".$page1);
else
  $html=file_get_contents($search."&offset=".$page1);
$n=0;
$videos = explode('div class=" mlxl plxl', $html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
    $t1 = explode('href="', $video);
 if (sizeof ($t1) > 2 ) {
    $t2 = explode('"', $t1[2]);
    $link = $t2[0];

    $t3 = explode('title="', $video);
    $t2 = explode('"', $t3[1]);
    $title = trim($t2[0]);
    //$title=fix_s($title);
    $t1 = explode('src="', $video);
    $t2 = explode('"', $t1[1]);
    $image = $t2[0];
    $descriere=$title;

    $t0=explode('class="duration',$video);
 if (sizeof ($t0) > 1 ) {
    $t1=explode('>',$t0[1]);
    $t2=explode('<',$t1[1]);
    $durata="Durata:".trim($t2[0]);
 }
  if ((strpos($title,"Vizion") === false) && ($title <> "") && preg_match("/video/",$image)) {
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="trilulilu_link.php?file='.urlencode($link).'"><img src="'.$image.'" width="200px" height="106px"><BR><font size="4">'.$title.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
  }
 }
}
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="trilulilu.php?page='.($page-1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="trilulilu.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="trilulilu.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>
