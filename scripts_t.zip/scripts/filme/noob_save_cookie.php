<?php
include ("../common.php");
$cookie=$base_cookie."noob.dat";
$cookie1=$base_cookie."noob.txt";
  $handle = fopen($cookie, "r");
  $c = fread($handle, filesize($cookie));
  fclose($handle);
  $fh = fopen($cookie1, 'w');
  fwrite($fh, $c);
  fclose($fh);
echo "Am salvat cookie...";
?>
