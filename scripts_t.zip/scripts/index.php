<!DOCTYPE html>
<?php
include ("common.php");
$f=$base_pass."adult.txt";
if (!file_exists($f)) {
//echo '<h2 style="background-color:deepskyblue;color:black"><center>Activati sau dezactivati sectiunea Adult din setari!</center></h2>';
} else {
$h=file_get_contents($f);
$t1=explode("|",$h);
$adult=$t1[0];
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>HD4ALL</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="custom.css" />
<style>
html { height: 100%;}
.balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
</style>



<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(url) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'url='+url;
  var php_file='../update.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
      location.reload();
    }
  }
}
</script>
</head>
<body>

<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function is_valid_date($value, $format = 'dd.mm.yyyy'){
    if(strlen($value) >= 6 && strlen($format) == 10){

        // find separator. Remove all other characters from $format
        $separator_only = str_replace(array('m','d','y'),'', $format);
        $separator = $separator_only[0]; // separator is first character

        if($separator && strlen($separator_only) == 2){
            // make regex
            $regexp = str_replace('mm', '(0?[1-9]|1[0-2])', $format);
            $regexp = str_replace('dd', '(0?[1-9]|[1-2][0-9]|3[0-1])', $regexp);
            $regexp = str_replace('yyyy', '(19|20)?[0-9][0-9]', $regexp);
            $regexp = str_replace($separator, "\\" . $separator, $regexp);
            if($regexp != $value && preg_match('/'.$regexp.'\z/', $value)){

                // check date
                $arr=explode($separator,$value);
                $day=$arr[0];
                $month=$arr[1];
                $year=$arr[2];
                if(@checkdate($month, $day, $year))
                    return true;
            }
        }
    }
    return false;
}
$p=$_SERVER['SCRIPT_FILENAME'];
$script_directory = substr($p, 0, strrpos($p, '/'));
$f_version=$script_directory."/version_m.txt";
if (file_exists($f_version)) {
  $curr_vers=trim(file_get_contents($script_directory."/version_m.txt"));
  $l="http://hdforall.freehostia.com/version_m.txt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $h = curl_exec($ch);
  curl_close($ch);
  $t=explode("\n",$h);
  $avb_vers=trim($t[0]);
  $serv_update=trim($t[1]);
$valid_date = is_valid_date($avb_vers);
if ($valid_date) {
if ($avb_vers <> $curr_vers) {
  $info = "O nouă versiune este disponibilă (".$avb_vers.")! Apasati aici pentru actualizare.";
  echo '<p><a onclick="ajaxrequest('."'".$serv_update."')".'"'." style='cursor:pointer;'>".'<font size="4">'.$info.'</font></a></p>';
} else {
  $info = "";
}
} else {
  $info="Eroare citire data versiune disponibila!";
  echo '<p>'.$info.'</p>';
}
}
include ("common.php");
$f=$base_pass."seenow1.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if ($user=="DA") {
   $seenow="DA";
} else {
$seenow="NU";
}
} else {
$seenow="NU";
}
$f=$base_pass."flash.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$flash=$t1[0];
} else {
$flash=="NU";
}
?>
<H2></H2>
<table align="center" width="90%">
<tr>
<TD><font size="5">HD4ALL</font></TD>
<TD align="right"><a href="settings.php?&tip=" target="_blank"><font size="5">Setări</font></a></TD>
</TR>
</TABLE>
<table border="1" align="center" width="90%">
<TR>
<td style="background-color:deepskyblue;color:black;text-align:center" colspan="4"><b><font size="4">Filme şi Seriale</font></b></TD>
</TR>
<TR>
<TD><a href="filme/noob_m_main.php" target="_blank"><font size="4">Noobroom (premium)</font></TD>
<TD><a href="filme/noob_m_main1.php" target="_blank"><font size="4">Noobroom (flash)</font></TD>
<TD><a href="filme/serialepenet_main.php" target="_blank"><font size="4">Serialepenet.ro</font></TD>
<!--<TD><a href="filme/filmesubtitrate.php" target="_blank"><font size="4">filmesubtitrate.info</font></TD>-->
<TD><a href="filme/serial-online_main.php" target="_blank"><font size="4">serial-online</font></TD>
</TR>
<TR>

<TD><a href="filme/vplus_m.php?page=1" target="_blank"><font size="4">vplus (filme)</font></TD>
<TD><a href="filme/vplus_s_main.php?page=1" target="_blank"><font size="4">vplus (seriale)</font></TD>
<TD><a href="filme/movie-inn_m.php?page=1,,movie-inn" target="_blank"><font size="4">movie-inn.com (filme)</font></TD>
<TD><a href="filme/movie-inn_s.php?page=1,,movie-inn" target="_blank"><font size="4">movie-inn.com (seriale)</font></TD>
</TR>
<TR>
<TD><a href="filme/990_filme_main.php" target="_blank"><font size="4">990.ro - (filme)</font></TD>
<TD><a href="filme/990_s.php" target="_blank"><font size="4">990.ro (seriale)</font></TD>
<TD><a href="filme/seriale-filme_main.php" target="_blank"><font size="4">seriale-filme</font></TD>
<!--<TD><a href="filme/filmesubtitrate_m.php?page=1,http://www.fsplay.net/filme-online-subtitrate,filmesubtitrate.info" target="_blank"><font size="4">filmesubtitrate.info (filme)</font></TD>-->
<TD><a href="filme/filmeonline_main.php" target="_blank"><font size="4">filmeonline (seriale)</font></TD>
</TR>
<tr>
<TD><a href="filme/filmbox_main.php" target="_blank"><font size="4">filmbox</font></TD>
<TD><a href="filme/filmehd_main.php" target="_blank"><font size="4">filmehd.net</font></TD>
<TD><a href="filme/onlinehd_main.php" target="_blank"><font size="4">onlinehd</font></TD>
<TD><a href="filme/divxonline_main.php" target="_blank"><font size="4">divxonline</font></TD>
</TR>
<TR>
<TD><a href="filme/cr3ative-zone_main.php" target="_blank"><font size="4">cr3ative-zone.ucoz.ro</font></TD>
<TD><a href="filme/filme-bune_main.php" target="_blank"><font size="4">filme-bune</font></TD>
<TD><a href="filme/filmeonline3d_main.php" target="_blank"><font size="4">filmeonline3d</font></TD>
<TD><a href="filme/filmeonline2013_main.php" target="_blank"><font size="4">filmeonline2013</font></TD>
</TR>
<TR>
<!--
<TD><a href="filme/spice_movie.php?page=1,http://www.ustv.ro/filme-online/,Toate+Filmele" target="_blank"><font size="4">Spice TV (filme)</font></TD>
<TD><a href="filme/spice_series_main.php?page=1,http://www.ustv.ro/seriale-online,Seriale" target="_blank"><font size="4">Spice TV (seriale)</font></TD>
-->
<TD><a href="filme/filmefullhd_main.php" target="_blank"><font size="4">filmefullhd</font></TD>
<TD><a href="filme/topvideohd_main.php" target="_blank"><font size="4">topvideohd</font></TD>
<!--<TD><a href="filme/serialetv_main.php" target="_blank"><font size="4">serialetv</font></TD>-->
<!--<TD><a href="filme/popcornered_main.php" target="_blank"><font size="4">popcornered</font></TD>-->
<!--<TD><a href="filme/movietv_main.php" target="_blank"><font size="4">movietv</font></TD>-->
<TD></TD>
<TD></TD>
</TR>
<!--
<TR>
<TD><a href="filme/hdfilm_main.php" target="_blank"><font size="4">hdfilm</font></TD>
<TD></TD>
<TD></TD>
<TD></TD>
</TR>
-->
</table>

<?php
$f=$base_pass."seenow1.txt";
if (file_exists($f)) {
$t="Seenow";
$seenow="DA";
} else {
$t="Seenow (FreeZone/Abonament)";
$seenow="NU";
/*
 $txt="DA|xxx";
 $fh = fopen($f, 'w');
 fwrite($fh, $txt);
 fclose($fh);
*/
}

echo '
<br>
<table border="1" align="center" width="90%">
<TR>
<td style="background-color:deepskyblue;color:black;text-align:center" colspan="4"><b><font size="4">'.$t.'</font></b></TD>
</TR>
';
if ($seenow=="DA") {
echo '
<TR>

<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/disney-movies-on-demand-5187-pagina-,Disney+Movies" target="_blank"><font size="4">Disney Movies</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/filme-hollywood-25-pagina-,Filme+Hollywood" target="_blank"><font size="4">Filme Hollywood</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/filme-romanesti-23-pagina-,Filme+Romanesti" target="_blank"><font size="4">Filme Romanesti</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/axn-now-447-pagina-,AXN Now" target="_blank"><font size="4">AXN Now</font></TD>
</TR>

<TR>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/pay-per-view-27-pagina-,Filme+Premium" target="_blank"><font size="4">Filme Premium</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/tv-62-pagina-,Filmbox+Live" target="_blank"><font size="4">Filmbox Live</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/filmbox-filme-128-pagina-,Filmbox+Filme" target="_blank"><font size="4">Filmbox Filme</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/filmbox-seriale-129-pagina-,Filmbox+Seriale" target="_blank"><font size="4">Filmbox Seriale</font></TD>
</TR>
<TR>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/desene-animate-3032-pagina-,Desene+animate" target="_blank"><font size="4">Desene animate</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/documentare-38-pagina-,Documentare" target="_blank"><font size="4">Documentare</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/lifestyle-38-pagina-,Lifestyle" target="_blank"><font size="4">Lifestyle</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/bollywood-26-pagina-,Filme+Bollywood" target="_blank"><font size="4">Filme Bollywood</font></TD>
</TR>
<TR>
<TD width="25%"><a href="tv/seenow.php" target="_blank"><font size="4">Seenow TV</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/avantaj-61-pagina-,Avantaj" target="_blank"><font size="4">Avantaj</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/cupa-romaniei-5658-pagina-,Cupa+Romaniei" target="_blank"><font size="4">Cupa Romaniei</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/favorite-pagina-,Filme+Favorite" target="_blank"><font size="4">Filme Favorite</font></TD>
<TR>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/tv-60-pagina-,TV" target="_blank"><font size="4">TV</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/tv-by-vodafone-564-pagina-,TV+by+Vodafone" target="_blank"><font size="4">TV by Vodafone</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/koolnet-5514-pagina-,Koolnet+TV" target="_blank"><font size="4">Koolnet TV</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/emisiuni-tv-78-pagina-,Emisiuni+TV" target="_blank"><font size="4">Emisiuni TV</font></TD>
<!--TD width="25%"></TD-->
</TR>
';
}
echo '
<TR>

<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/freezone-9-pagina-,TV+(FreeZone)" target="_blank"><font size="4">TV (FreeZone)</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/emisiuni-tv-2697-pagina-,Emisiuni+TV+(FreeZone)" target="_blank"><font size="4">Emisiuni TV (FreeZone)</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/documentare-2701-pagina-,Documentare+(FreeZone)" target="_blank"><font size="4">Documentare (FreeZone)</font></TD>
';
if ($flash=="NU")
echo '<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/radio-22-pagina-,Radio+(FreeZone)" target="_blank"><font size="4">Radio (FreeZone)</font></TD>';
else
echo '<TD width="25%"><a href="tv/seenow_r1.php" target="_blank"><font size="4">Radio (FreeZone)</font></TD>';
echo'
</TR>
';
if ($seenow=="NU") {
echo '
<TR>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/tv-60-pagina-,TV" target="_blank"><font size="4">TV (abonament)</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/avantaj-61-pagina-,Avantaj" target="_blank"><font size="4">Avantaj (abonament)</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/filmbox-live-62-pagina-,Filmbox" target="_blank"><font size="4">Filmbox (abonament)</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/koolnet-5514-pagina-,KOOLNET" target="_blank"><font size="4">KOOLNET (abonament)</font></TD>
</TR>
<TR>
<TD width="50%" colspan="2"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/cupa-romaniei-5658-pagina-,Cupa+Romaniei" target="_blank"><font size="4">Cupa Romaniei (abonament)</font></TD>
<TD width="50%" colspan="2"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/tv-by-vodafone-564-pagina-,TV+by+vodafone" target="_blank"><font size="4">TV by Vodafone (abonament)</font></TD>

</TR>
';
}


?>
</table><br>
<table border="1" align="center" width="90%">
<TR>
<td style="background-color:deepskyblue;color:black;text-align:center" colspan="4"><b><font size="4">Live TV şi emisiuni TV</font></b></TD>
</TR>
<TR>
<TD><a href="tv/dolce.php" target="_blank"><font size="4">Posturi Romania</font></TD>
<TD><a href="tv/spice_tv.php" target="_blank"><font size="4">Spice TV</font></TD>
<TD><a href="tv/sopcast.php" target="_blank"><font size="4">Sopcast</font></TD>
<TD><a href="tv/sopcast1.php" target="_blank"><font size="4">Sopcast (alternativ)</font></TD>
</TR>
<TR>
<TD><a href="tv/filmon.php" target="_blank"><font size="4">Filmon</font></TD>
<TD><a href="tv/dancetrippin.php" target="_blank"><font size="4">dancetrippin.tv</font></TD>
<TD><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/biziday-3298-pagina-,Biziday" target="_blank"><font size="4">Biziday</font></TD>
<TD><a href="tv/tvrplus_e.php?page=1,http%3A%2F%2Fwww.seenow.ro%2Fb1-tv-2699-pagina-,B1+TV" target="_blank"><font size="4">B1TV</font></TD>
</TR>
<TR>
<TD><a href="tv/digi24.php" target="_blank"><font size="4">Digi24 - Stiri</font></TD>
<TD><a href="tv/digi24_e_main.php" target="_blank"><font size="4">Digi24 - Emisiuni</font></TD>
<TD><a href="tv/tvrplus_e.php?page=1,http%3A%2F%2Fwww.seenow.ro%2Frealitatea-tv-2698-pagina-,Realitatea+TV" target="_blank"><font size="4">Realitatea TV</font></TD>
<TD><a href="tv/tele-tv.php?page=1,emisiuni,Emisiuni inregistrate" target="_blank"><font size="4">tele-info</font></TD>
</TR>
<TR>
<TD><a href="filme/youtube_user.php?page=1,UCfnP_igK3BPLst-QTmIh0Wg,Agerpres" target="_blank"><font size="4">Agerpress</font></TD>
<TD><a href="filme/youtube_user.php?page=1,ArealIT,ZonaIT" target="_blank"><font size="4">ZonaIT</font></TD>
<TD><a href="tv/publika.php?page=1,,publika.md" target="_blank"><font size="4">publika.md</font></TD>
<TD><a href="tv/jurnaltv.php?page=1,,jurnaltv.md" target="_blank"><font size="4">jurnaltv.md</font></TD>
</TR>
<TR>
<TD><a href="filme/youtube_user.php?page=1,mondeniionline,Mondenii" target="_blank"><font size="4">Mondenii</font></TD>
<td><a href="tv/digisport.php?page=1,http://www.digisport.ro/Sport/VIDEO/,DigiSport" target="_blank"><font size="4">DigiSport</font></TD>
<TD><a href="tv/tvrstiri.php?page=1,,TVR+Stiri" target="_blank"><font size="4">TVR - Stiri</font></TD>
<TD><a href="tv/voyo.php" target="_blank"><font size="4">Voyo</font></TD>
</TR>
<TR>
<TD><a href="tv/protv_main.php" target="_blank"><font size="4">ProTV</font></TD>
<TD><a href="tv/plus_main.php" target="_blank"><font size="4">TVR Plus</font></TD>
<TD><a href="tv/privesc_main.php" target="_blank"><font size="4">privesc.eu</font></TD>
<TD><a href="tv/megatube_main.php" target="_blank"><font size="4">megatube.eu</font></TD></TR>
<TR>
<!--<TD><a href="tv/tastez.php?query=starnet,Starnet" target="_blank"><font size="4">Tastez.ro - Starnet</font></TD>-->
<TD><a href="tv/tastez.php?query=antena-play,Antena+Play" target="_blank"><font size="4">Tastez.ro - Antena Play</font></TD>
<TD><a href="tv/tastez.php?query=moldova,Moldova" target="_blank"><font size="4">Tastez.ro - Moldova</font></TD>
<TD><a href="tv/tastez.php?query=digi,Digi+(Doar+in+reteaua+RDS)" target="_blank"><font size="4">Tastez.ro - Digi</font></TD>
<TD><a href="tv/tastez.php?query=regional,Altele" target="_blank"><font size="4">Tastez.ro - Altele</font></TD>
</tr>

<?php
if (file_exists($_SERVER['DOCUMENT_ROOT']."/spyce.m3u")) {
echo '<TR>';
echo '<TD><a href="tv/spyce_tv.php" target="_blank"><font size="4">Spyce TV</font></TD>';
echo '<TD><a href="tv/tv_heanded.php" target="_blank"><font size="4">HTS Tvheadend</font></TD>';
echo '<TD></TD><TD></TD></TR>';
}
if ($seenow=="BA") {
echo '
<TR>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/emisiuni-tv-2697-pagina-,Emisiuni+TV" target="_blank"><font size="4">Emisiuni TV</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/documentare-2701-pagina-,Documentare" target="_blank"><font size="4">Documentare</font></TD>
';
if ($flash=="NU")
echo '<TD width="25%"><a href="tv/seenow_r.php" target="_blank"><font size="4">Radio</font></TD>';
else
echo '<TD width="25%"><a href="tv/seenow_r1.php" target="_blank"><font size="4">Radio</font></TD>';
echo'
<TD width="25%"></TD>
</TR>
';
}
?>

</table>
<br>
	<table border="1" align="center" width="90%" id="table1">
	<tr>
    <td style="background-color:deepskyblue;color:black;text-align:center" colspan="5"><b><font size="4">OneHD Concerts</font></b></TD>
    </tr>
		<tr>
			<td align="center"><font size="4"><a href="tv/onehd_pop.html" target="_blank">Pop</a></font></td>
			<td align="center"><font size="4"><a href="tv/onehd_rock.html" target="_blank">Rock</a></font></td>
			<td align="center"><font size="4"><a href="tv/onehd_dance.html" target="_blank">Dance</a></font></td>
			<td align="center"><font size="4"><a href="tv/onehd_jazz.html" target="_blank">Jazz</a></font></td>
			<td align="center"><font size="4"><a href="tv/onehd_classic.html" target="_blank">Classic</a></font></td>
		</tr>
	</table>
<br>
<table border="1" align="center" width="90%">
<TR>
<td style="background-color:deepskyblue;color:black;text-align:center" colspan="4"><b><font size="4">Videoclipuri</font></b></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/vplay_main.php" target="_blank"><font size="4">vplay</font></TD>
<TD width="25%"><a href="filme/trilulilu_main.php" target="_blank"><font size="4">trilulilu</font></TD>
<TD width="25%"><a href="filme/videoalegenet.php?page=1,http://video.alege.net/c-filme-noi-ro-,video.alege.net" target="_blank"><font size="4">video.alege.net</font></TD>
<TD width="25%"><a href="filme/bzi.php?page=1,,bzi" target="_blank"><font size="4">bzi</font></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/roboti.php?page=1,,ROboti" target="_blank"><font size="4">ROboti</font></TD>
<TD width="25%"><a href="filme/recomand.php?page=1,,ROboti+-+Recomand" target="_blank"><font size="4">ROboti Recomand</font></TD>
<TD width="25%"><a href="filme/yt_playlist.php?page=1,PLA1CEC3D2A6A0263F,Luzarii+de+pe+Electrolizei" target="_blank"><font size="4">Luzarii</font></TD>
<TD width="25%"><a href="filme/myvideo.php?page=1,,myvideo.ro" target="_blank"><font size="4">myvideo.ro</font></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/yt_playlist.php?page=1,PL8YoNHKjWTYA0PvglTn9OqpQiuyIrIrDq,Tara+lui+Fratzica" target="_blank"><font size="4">Tara lui Fratzica</font></TD>
<TD width="25%"><a href="filme/220_main.php" target="_blank"><font size="4">220.ro</font></TD>
<TD width="25%"><a href="filme/youtube_user.php?page=1,DoZaDeHas,DoZaDeHas" target="_blank"><font size="4">DoZaDeHas</font></TD>
<TD width="25%"><a href="filme/youtube.php?tip=&user=&id=" target="_blank"><font size="4">youtube</font></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/youtube_user.php?page=1,catmusicoffice,Cat+Music" target="_blank"><font size="4">Cat Music</font></TD>
<TD width="25%"><a href="filme/youtube_user.php?page=1,MediaProMusic,MediaProMusic" target="_blank"><font size="4">MediaProMusic</font></TD>
<TD width="25%"><a href="filme/youtube_user.php?page=1,musicroton,MusicROTON" target="_blank"><font size="4">MusicROTON</font></TD>
<TD width="25%"><a href="filme/youtube_user.php?page=1,hahahaproductioncom,HaHaHa+Production" target="_blank"><font size="4">HaHaHa Production</font></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/top1_main.php" target="_blank"><font size="4">top1.ro</font></TD>
<TD width="25%"><a href="filme/tare.php?page=1,,tare.ro" target="_blank"><font size="4">tare.ro</font></TD>
<TD width="25%"><a href="filme/peteava_main.php" target="_blank"><font size="4">peteava</font></TD>
<TD width="25%"><a href="filme/traznitii.php" target="_blank"><font size="4">Traznitii</font></TD>
</TR>
</TABLE><br>
<?php
if ($adult=="DA") {
echo '
<table border="1" align="center" width="90%">
<TR>
<td style="background-color:deepskyblue;color:black;text-align:center" colspan="4"><b><font size="4">Adult</font></b></TD>
</TR>
<TR>
<TD width="25%"><a href="adult/tube8_main.php" target="_blank"><font size="4">tube8</font></TD>
<!--<TD width="25%"><a href="adult/porno720p.php?page=1,http://porno720p.com,porno720p.com" target="_blank"><font size="4">porno720</font></TD>-->
<TD width="25%"><a href="adult/penthousevideos_main.php" target="_blank"><font size="4">penthousevideos</font></TD>
<TD width="25%"><a href="adult/redtube_main.php" target="_blank"><font size="4">redtube</font></TD>
<TD width="25%"><a href="adult/alotporn_main.php" target="_blank"><font size="4">alotporn</font></TD>
</tr>
<tr>
<TD width="25%"><a href="adult/extremetube_main.php" target="_blank"><font size="4">extremetube</font></TD>
<TD width="25%"><a href="adult/empflix_main.php" target="_blank"><font size="4">empflix</font></TD>
<TD width="25%"><a href="adult/moviesand_main.php" target="_blank"><font size="4">moviesand</font></TD>
<TD width="25%"><a href="adult/flytube_main.php" target="_blank"><font size="4">flytube</font></TD>
</tr>
<tr>
<TD width="25%"><a href="adult/pornomovies_main.php" target="_blank"><font size="4">pornomovies</font></TD>
<TD width="25%"><a href="adult/spankwire_main.php" target="_blank"><font size="4">spankwire</font></TD>
<TD width="25%"><a href="adult/xhamster_main.php" target="_blank"><font size="4">xhamster</font></TD>
<TD width="25%"><a href="adult/xnxx_main.php" target="_blank"><font size="4">xnxx</font></TD>
</tr>
<tr>
<TD width="25%"><a href="adult/xvideos_main.php" target="_blank"><font size="4">xvideos</font></TD>
<TD width="25%"></TD>
<TD width="25%"></TD>
<TD width="25%"></TD>
</tr>
<!-- tr><td style="background-color:deepskyblue;color:black;text-align:center;" colspan="4"><b><font size="4">Private & Satin</font></b></TD></TR -->
';
if ($seenow=="DA") {
echo '
<tr>
<TD width="25%"><a href="adult/tvrplus_e.php?page=1,,Private+Hardcore" target="_blank"><font size="4">Private Hardcore</font></TD>
<TD width="25%"><a href="adult/tvrplus_e.php?page=1,,Private+Softcore" target="_blank"><font size="4">Private Softcore</font></TD>
<TD width="25%"><a href="adult/tvrplus_e.php?page=1,,Satin+Adult+Mix" target="_blank"><font size="4">Satin Adult Mix</font></TD>
<TD width="25%"></TD>
</tr>
';
}
echo '
</table>
';
}
$f=$base_pass."adult.txt";
if (!file_exists($f)) {
echo '<h2 style="background-color:deepskyblue;color:black"><center>Activati sau dezactivati sectiunea Adult din setari!</center></h2>';
}
$list = glob($base_cookie."*.dat");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
if (file_exists("adult/private-hardcore-345-pagina-1")) {
$list = glob("adult/private*",GLOB_BRACE);
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
$list = glob("adult/satin-adult*",GLOB_BRACE);
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
}
$list = glob($base_fav."*.list");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
$add="\r\n"."127.0.0.1 dev.mediadirect.ro";
$l="c:\\windows\\system32\\drivers\\etc\\hosts";
$h=@file_get_contents($l);

if (@strpos($h,"dev.mediadirect.ro") === false && (strpos($base_pass,":") !== false)) {
 @file_put_contents($l, $add, FILE_APPEND | LOCK_EX);
}
?>
<br></body>
</html>
