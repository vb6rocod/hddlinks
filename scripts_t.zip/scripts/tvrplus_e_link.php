<?php
function rand_string( $length ) {
	$str = "";
	$characters = array_merge(range('a','f'), range('0','9'));
	$max = count($characters) - 1;
	for ($i = 0; $i < $length; $i++) {
		$rand = mt_rand(0, $max);
		$str .= $characters[$rand];
	}
 return $str;
}
function search_arr($array, $key, $value)
{
    $results = array();

    if (is_array($array)) {
        if (isset($array[$key]) && $array[$key] == $value) {
            $results[] = $array;
        }

        foreach ($array as $subarray) {
            $results = array_merge($results, search_arr($subarray, $key, $value));
        }
    }

    return $results;
}
function objectToArray($d) {

	if (is_object($d)) {
		$d = get_object_vars($d);
	}

	if (is_array($d)) {
		return array_map(__FUNCTION__, $d);
	}
	else {
		return $d;
	}
}
$id=""; $pg_id="";
$id = $_GET["file"];
if (array_key_exists("pg_id",$_GET))$pg_id = $_GET["pg_id"];
$title = urldecode($_GET["title"]);
$svr=""; $serv="";
$sub=""; $subtracks="";
$token="";
$str_name="";
$p=array();
include ("../common.php");
$filename = $base_pass."seenowtv.txt";
$cookie=$base_cookie."seenowtv.dat";
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."tv.txt")) {
$tv=trim(file_get_contents($base_pass."tv.txt"));
} else {
$tv="dinamic";
}
if ( is_numeric($id) ) {
$l="http://www.seenow.ro/smarttv/placeholder/list/id/".$pg_id."/start/0/limit/999";
//$h=file_get_contents($l);

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
//echo $h;
//die();
$t1=json_decode($h,1);
//print_r ($t1);
if ($t1) if (array_key_exists("items",$t1)) {
$items=$t1['items'];
$items = array_values($items);

$willStartPlayingUrl = "http://www.seenow.ro/smarttv/historylist/add/id/".$id;
$h=search_arr($items, 'willStartPlayingUrl', $willStartPlayingUrl);
if (!$h) $h=search_arr($items, 'title', $title);

if (sizeof($h)>0 && !(($pg_id==22 || $pg_id==5036))) {
//$t2=file_get_contents($h[0]["playURL"]);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $h[0]["playURL"]);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $t2 = curl_exec($ch);
  curl_close($ch);


$h=json_decode($t2);
$p=objectToArray($h);
}  elseif ($pg_id==22 || $pg_id==5036 )
  $p=$h[0];

}
if (array_key_exists("streamUrl",$p)) {
$l=$p["streamUrl"];
$t1=explode("token=",$l);
if (sizeof($t1)>1) {
$t2=explode('|',$t1[1]);
$token=$t2[0];
}
$t1=explode('|',$l);
$l=$t1[0];
}
if (!$p) {
$l="http://www.seenow.ro/smarttv/placeholder/view/id/".$id;
//$h=file_get_contents($l);

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);

$p=json_decode($h,1);
}

//die();
if ($p) if (array_key_exists("high quality stream name",$p)) {
$t1="";
if (array_key_exists("streamUrl",$p)) $t1=$p["streamUrl"];
if (!$t1) {
//$t2=file_get_contents($p["playURL"]);
if (array_key_exists("playURL",$p)) {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $p["playURL"]);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $t2 = curl_exec($ch);
  curl_close($ch);



$h=json_decode($t2);
$p=objectToArray($h);
}
}
$str_name=$p["high quality stream name"];
if (array_key_exists("streamUrl",$p)) {
$l=$p["streamUrl"];
$t1=explode("token=",$l);
if (sizeof($t1)>1) {
$t2=explode('|',$t1[1]);
$token=$t2[0];
}
$t1=explode('|',$l);
$l=$t1[0];
}
}
//print_r($p);
if (strpos($l,"radio") !== false) {
$audio=$p["audio stream name"];
$img=$p["thumbnail"];
}
if (!$token) {
$token=rand_string(48);
//print_r($token);
//$o=$p["other params"];
//$u=str_replace("&publisher=","&device_id=0&publisher=24",$o);
//$l="http://[%server_name%]:1937/seenow/".$str_name."?user_id=0&transaction_id=0&device_id=0&publisher=24&p_item_id=".$id."&token=".$token;
$u="user_id=0&transaction_id=0&p_item_id=".$id."&device_id=0&publisher=24";
if (!($pg_id==22 || $pg_id==5036)) $l="http://[%server_name%]:1937/seenow/_definst_/mp4:".$str_name."/playlist.m3u8?".$u."&token=".$token;
//}
//http://fms4.mediadirect.ro:8000/radio/_definst_/europafm?user_id=5114&p_item_id=5704
/*
if (strpos($l,"radio") !== false) {
$l=str_replace("?user_id=0&p_item_id=","/playlist.m3u8?user_id=0&p_item_id=",$l);
$t1=explode("?",$l);
$l=$t1[0]."/playlist.m3u8?user_id=0&p_item_id=".$id;
}
*/
}

if ($p) if (array_key_exists("subtitles",$p)) {
$t1=$p["subtitles"];
if (sizeof($t1) > 1) {
   $t2 = search_arr($t1, 'code', 'RO');
   $t3 = $t2[0];
   $sub=$t3["srt"];
}
else
   $sub = $t1;
if ($sub) {
   $t1 = '{"file": "'.$sub.'", "default": true}';
   $subtracks='"tracks": ['.$t1.']';
   }
}
$title = preg_replace('~[^\\pL\d.]+~u', ' ', $title);

if (strpos($base_pass,":") !== false) {
    $title = str_replace("Ş","S",$title);
    $title = str_replace("ş","S",$title);
    $title = str_replace("ș","s",$title);
    $title = str_replace("ș","s",$title);
    $title = str_replace("Ț","T",$title);
    $title = str_replace("ț","t",$title);
    $title = str_replace("ţ","t",$title);
    $title = str_replace("Ț","T",$title);
    $title = str_replace("Ţ","T",$title);
    $title = str_replace("ă","a",$title);
	$title = str_replace("â","a",$title);
	$title = str_replace("î","i",$title);
	$title = str_replace("Î","I",$title);
	$title = str_replace("Ă","A",$title);
}


//$srt_name=$str_name.".srt";
$movie_file=$title.".m3u8";
if ($p) if (array_key_exists("indexUrl",$p)) $svr=$p["indexUrl"];
if ($svr) {
$h=file_get_contents($svr);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0];
if ($serv == "") {
  $serv="fms60.mediadirect.ro";
}
}
/*
$out=str_replace("[%server_name%]",$serv,$l);
$out=str_replace("playlist",$title,$out);
//$out=str_replace("|COMPONENT=HLS","",$out);
$out=str_replace("seenow-smart/_definst_/","seenow/_definst_/mp4:",$out);
*/
if (!($pg_id==22 || $pg_id==5036)) {
$out=str_replace("[%server_name%]",$serv,$l);
$out=str_replace("playlist",$title,$out);
$out=str_replace("seenow-smart/_definst_/","seenow/_definst_/mp4:",$out);
$t1=explode('?',$out);
$out=$t1[0]."?user_id=0&transaction_id=0&publisher=24&p_item_id=".$id."&token=".$token;
} else {
$out=$l;
}
if (strpos($out,"mp4:") !== false)
  $srt_name=$title.".srt";
else {
$t1=explode(".",substr(strrchr($str_name, "/"), 1));
$srt_name = $t1[0].".srt";
}
//echo $out."<BR>";
//echo $srt_name;
//die();
if (file_exists($base_sub.$srt_name)) unlink($base_sub.$srt_name);

   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $sub);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
   }
if ($h) {
   $new_file = $base_sub.$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h);
   fclose($fh);
   
   $subtracks='"tracks": [{"file": "../subs/'.$srt_name.'", "default": true}]';

}
} else {
/** 
$l="http://index.mediadirect.ro:80/getUrl?app=radio&file=".$id.".stream&publisher=17";
$h=file_get_contents($l);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0]; **/
$serv="178.21.120.26";
//rtmp://178.21.120.26:1935/radio/_definst_/r3n.stream
$out="rtmp://".$serv.":1935/radio/_definst_/".$id.".stream";
}
//if ( strpos($_SERVER['HTTP_USER_AGENT'],'Android') !== false ) {
//if (strpos($base_pass,":") === false) {
if ( (strpos($base_pass,":") === false) && ($flash == "direct" || strpos($out,"mp4:") !== false) && $pg_id != 22) {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} elseif (strpos($out,"mp4:") !== false || $tv=="vlc") {  // || $pg_id==22
//echo $out;
//die();
echo '
<html>
   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
</style>
      <title>'.$title.'</title>
   </head>
<body>

<embed type="application/x-vlc-plugin" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2"
width="100%"
height="100%"
id="vlc"
target="'.$out.'">
</embed>


    <script language="Javascript">

    var vlc = document.getElementById("vlc");
    vlc.audio.toggleMute();
	vlc.video.aspectRatio="16:9";
    vlc.subtitle.track="1";


    </script>





    </body>
    </Html>
';
} elseif (strpos($out,"mp4") !== false  && $tv!="vlc") {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "mp4"}], 
'.$subtracks.'
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": "../hd4all.xml",
"stretching":"exactfit",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
} elseif (($pg_id=="22" || $pg_id=="5036")&& strpos($base_pass,":") !== false) {
$rtmp="rtmp://178.21.120.26:1935/radio/_definst_";
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="../filme/jwplayer.js"></script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"players": [{"type":"flash","src":"../filme/player.swf"}],
"image": "'.$img.'",
"file": "'.$audio.'",
"height": $(document).height(),
"width": $(document).width(),
"skin": "../skin.zip",
"stretching":"exactfit",
"dock": "true",
"autostart": "true",
"controlbar.position": "over",
"controlbar.idlehide": "false",
"backcolor": "000000",
"frontcolor": "ffffff",
"lightcolor": "f7b01e",
"streamer": "'.$rtmp.'",
"provider": "rtmp",
"volume": "100",
});
</script>
</BODY>
</HTML>
';
} elseif (($pg_id=="22" || $pg_id=="5036") && strpos($base_pass,":") === false) {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"image": "'.$img.'",
"sources": [{"file": "'.$out.'", "type": "mp4"}],
}],
"height": $(document).height(),
"width": $(document).width(),
"skin": "../hd4all.xml",
"stretching":"exactfit",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
} else {
$app="live3";
if ($tv=="fms38.mediadirect.ro")
 $serv="fms11".mt_rand(2,3).".mediadirect.ro";
$rtmp="rtmpe://".$serv."/".$app."/_definst_?token=".$token;

echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="../filme/jwplayer.js"></script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"players": [{"type":"flash","src":"../filme/player.swf"}],
"file": "'.$str_name.'",
"token": "'.$token.'",
"height": $(document).height(),
"width": $(document).width(),
"skin": "../skin.zip",
"stretching":"exactfit",
"dock": "true",
"autostart": "true",
"controlbar.position": "over",
"controlbar.idlehide": "false",
"backcolor": "000000",
"frontcolor": "ffffff",
"lightcolor": "f7b01e",
"streamer": "'.$rtmp.'",
"volume": "100",
});
</script>
</BODY>
</HTML>
';
}
?>
