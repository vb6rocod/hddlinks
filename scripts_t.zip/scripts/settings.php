<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
<link rel="stylesheet" type="text/css" href="./custom.css" />
      <title>Setari</title>


	  
</head>
<body>
<H2 style="background-color:deepskyblue;color:black;">Setari</H2>
<?php
error_reporting(0);
include ("common.php");
$tip=$_GET["tip"];
if ($tip) {
$user=$_GET["user"];
$user=str_replace("%40","@",$user);
$pass=$_GET["pass"];
if ($tip=="roshare") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."roshare.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="spicetv") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."spicetv.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="noobroom") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."noob_log.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="serialepenet") {
 $txt=$user;
 $new_file = $base_pass."serialepenet.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="vplus") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."vplus.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="amigo") {
 $txt=$user;
 $new_file = $base_pass."amigo.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="delete") {
 $f=$base_pass."noob_log.txt";
 unlink ($f);
} elseif ($tip=="movie-inn") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."movie-inn.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="airfun") {
 $txt=$user;
 $new_file = $base_pass."airfun.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
 } elseif ($tip=="adult") {
 $txt=$user;
 $new_file = $base_pass."adult.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="css") {
 $txt=$user;
 $new_file = $base_pass."css.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
 if ($txt=="ALB") {
 $out='
html { height: 100%;}
body {background-color:White;color:Black;margin:0px 25px 25px 25px;}
.balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
a { text-decoration:none }
a:link {color:Black;}      /* unvisited link */
a:visited {color:Black;}  /* visited link */
a:hover {color:Magenta;}  /* mouse over link */
a:active {color:Magenta;}  /* selected link */';
 $new_file = "custom.css";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $out);
 fclose($fh);
 } else {
 $out='
html { height: 100%;}
body {background-color:Black;color:White;margin:0px 25px 25px 25px;}
.balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
a { text-decoration:none }
a:link {color:White;}      /* unvisited link */
a:visited {color:White;}  /* visited link */
a:hover {color:Magenta;}  /* mouse over link */
a:active {color:Magenta;}  /* selected link */';
 $new_file = "custom.css";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $out);
 fclose($fh);
 }
} elseif ($tip=="220") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."220.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="seenow") {
 $txt=$user;
 $new_file = $base_pass."seenow.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="seenow1") {
 $txt=$user."|".$pass;
  $l="http://hdforall.freehostia.com/seenow.php?pass=".trim($pass);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $h = curl_exec($ch);
  curl_close($ch);
 if ($h=="OK") {
 $new_file = $base_pass."seenow1.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
 } else {
  unlink($base_pass."seenow1.txt");
 }
} elseif ($tip=="flash") {
 $txt=$user;
 $new_file = $base_pass."flash.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
}
}
$user="";
$pass="";
$f=$base_pass."airfun.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Tastatura PNI AirFun</h4>
<form action="settings.php">
Folosesc tastatura AirFun: <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>DA</option>
<option value="NU">NU</option>';
} else {
echo '
<option value="DA">DA</option>
<option value="NU" selected>NU</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="airfun">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."seenow.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Potrivire la ecran</h4>
<form action="settings.php">
Potrivire tabel la ecran: <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>DA</option>
<option value="NU">NU</option>';
} else {
echo '
<option value="DA">DA</option>
<option value="NU" selected>NU</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="seenow">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."flash.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Flash Radio</h4>
<form action="settings.php">
Flash Radio: <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>DA</option>
<option value="NU">NU</option>';
} else {
echo '
<option value="DA">DA</option>
<option value="NU" selected>NU</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="flash">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."css.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Foloseste fundal Alb sau Negru</h4>
<form action="settings.php">
Alege culoare fundal: <select id="user" name="user">
';
if ($user=="ALB") {
echo '
<option value="ALB" selected>ALB</option>
<option value="NEGRU">NEGRU</option>';
} else {
echo '
<option value="ALB">ALB</option>
<option value="NEGRU" selected>NEGRU</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="css">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."220.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont 220.ro (free)</h4>
<form action="settings.php">
User:<input type="text" name="user" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="220">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."roshare.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont roshare.info (free)</h4>
<form action="settings.php">
User:<input type="text" name="user" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="roshare">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."serialepenet.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cod activare serialepenet.ro</h4>
<form action="settings.php">
cod:<input type="text" name="user" value="'.$user.'"></BR>
<input type="hidden" name="tip" value="serialepenet">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."vplus.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont vplus.ro (free)</h4>
<form action="settings.php">
User:<input type="text" name="user" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="vplus">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."spicetv.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont spicetv.ro (free/premium)</h4>
<form action="settings.php">
E-mail:<input type="text" name="user" size="40" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" size="40" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="spicetv">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."noob_log.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont noobroom.com (premium)</h4>
<form action="settings.php">
E-mail:<input type="text" name="user" size="40" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" size="40" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="noobroom">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."amigo.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont amigo pentu noobroom.com (premium)</h4>
<form action="settings.php">
cod:<input type="text" name="user" value="'.$user.'"></BR>
<input type="hidden" name="tip" value="amigo">
<input type="submit" value="Memoreaza">
</form>
<BR>
<form action="settings.php">
<input type="hidden" name="tip" value="delete">
<input type="submit" value="Sterge cont noobroom, foloseste cod amigo">
</form>
<BR>
<hr>
';
$f=$base_pass."movie-inn.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont movie-inn.com</h4>
<form action="settings.php">
E-mail:<input type="text" name="user" size="40" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" size="40" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="movie-inn">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$user="";
$pass="";
$f=$base_pass."adult.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Continut (18+)</h4>
<form action="settings.php">
Permite accesul la continut (18+) : <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>DA</option>
<option value="NU">NU</option>';
} else {
echo '
<option value="DA">DA</option>
<option value="NU" selected>NU</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="adult">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$user="";
$pass="";
$f=$base_pass."seenow1.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Acces seenow</h4>
<form action="settings.php">
Permite accesul : <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>DA</option>
<option value="NU">NU</option>';
} else {
echo '
<option value="DA">DA</option>
<option value="NU" selected>NU</option>';
}
echo '</select>
</BR>
Pass:<input type="password" name="pass" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="seenow1">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
?>
<BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
<br></body>
</html>
