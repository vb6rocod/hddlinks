<!DOCTYPE html>
<?php
$query = $_GET["page"];
$pg="";
$pid="";
$tit="";
$search="";
$available="";
if($query) {
   $queryArr = explode(',', $query);
   $page= $queryArr[0];
if (sizeof($queryArr) > 1 )
   $search = $queryArr[1];
if (sizeof($queryArr) > 2 )
   $tit = urldecode($queryArr[2]);
   $tit=str_replace("\\","",$tit);
   $page_title=$tit;
}
if (!$search) {
if (!is_numeric($page)) $page=1;
$search=$_GET["search"];
$page_title=$_GET["title"];
$tit=$page_title;
}
include ("../common.php");
 include ("tvrplus_tv.php");
$filename = $base_pass."seenowtv.txt";
$cookie=$base_cookie."seenowtv.dat";
$f=$base_pass."seenow.txt";
$rest = substr($search, 0, -8);
$pg_id = substr(strrchr($rest, "-"), 1);
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
if ($t1[0]=="DA") {
  if  (($pg_id==22) || ($pg_id==5036))  {
	$wi="154";
	$hi="86";
  } else {
	$wi="171";
	$hi="96";
 }
} else {
  if  (($pg_id==22) || ($pg_id==5036))  {
	$wi="180";
	$hi="155";
  } else {
	$wi="200";
	$hi="180";
  }
}
} else {
  if  (($pg_id==22) || ($pg_id==5036))  {
	$wi="180";
	$hi="155";
  } else {
	$wi="200";
	$hi="180";
  }
}

//$wi="171";
//$hi="96";
if (file_exists($cookie)) unlink ($cookie);
if (file_exists($filename)) {
  $handle = fopen($filename, "r");
  $c = fread($handle, filesize($filename));
  fclose($handle);
  $a2=explode("|",$c);
  $a1=str_replace("?","@",$a2[0]);
  $user=urlencode($a1);
  $user=str_replace("@","%40",$user);
  $pass=trim($a2[1]);
if (!file_exists($cookie)) {
  $l="http://www.seenow.ro/login";
  $post="email=".$user."&password=".$pass."&submit=Login";
  //echo $post;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER,$l);
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
}
}
  //echo $html;
  //die;


?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <title><?php echo $tit; ?></title>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
</head>
<body>
<!-- h2 style="background-color:deepskyblue;color:black"><?php echo $tit; ?></H2 -->
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function search_arr($array, $key, $value)
{
    $results = array();

    if (is_array($array)) {
        if (isset($array[$key]) && $array[$key] == $value) {
            $results[] = $array;
        }

        foreach ($array as $subarray) {
            $results = array_merge($results, search_arr($subarray, $key, $value));
        }
    }

    return $results;
}
function xml_fix($string) {
    $v=str_replace("\u015e","S",$string);
    $v=str_replace("\u015f","s",$v);
    $v=str_replace("\u0163","t",$v);
    $v=str_replace("\u0162","T",$v);
    $v=str_replace("\u0103","a",$v);
    $v=str_replace("\u0102","A",$v);
    $v=str_replace("\u00a0"," ",$v);
    $v=str_replace("\u00e2","a",$v);
    $v=str_replace("\u021b","t",$v);
    $v=str_replace("\u201e","'",$v);
    $v=str_replace("\u201d","'",$v);
    $v=str_replace("\u0219","s",$v);
    $v=str_replace("\u00ee","i",$v);
    $v=str_replace("\u00ce","I",$v);
    $v=str_replace("\u2019","'",$v);
    $v=str_replace("\/","/",$v);
    return $v;
}
$search1=str_replace("&","|",$search);
$link=$search.$page;
//echo $link;

//$html = file_get_contents($link);

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);

$t1=explode('"',$html);
if ( count($t1) < 2 ) 
	$html = base64_decode($html);

  $t1=explode('textNav floatR',$html);
  if (sizeof($t1)<2) $t1=explode('class="floatR font20 grey',$html);
if (sizeof($t1)>1){
  $t2=explode(">",$t1[1]);
  $pg='Pagina curenta: '.$t2[1];
}
  $t1=explode('floatR textNav',$html);
  if (sizeof($t1)<2) $t1=explode('class="floatR font20 grey',$html);
if (sizeof($t1)>1){
  $t2=explode(">",$t1[1]);
  if ($t2[1]) $available=ucfirst(str_replace("-",".",strtolower($t2[1])));
}

echo '
<table border="0px" cellspacing="0" cellpadding="0" width="100%">
<TR><TD><BR><TD></TR>	
<TR><td style="background-color:deepskyblue;color:black;text-align:left;" colspan="3"><font size="5"><b>'.$tit.'</b></font></TD>
	<td style="background-color:deepskyblue;color:black;text-align:right;" colspan="1"><font size="5"><b>'.$available.'</b></font></TD></TR>
<TR><TD><BR><TD></TR>	
</table>
<table border="1px"  width="100%">
';
if ( $page <>"" ) {
echo '<tr>
<TD colspan="3"><form action="tvrplus_e.php">
<font size="4">'.$pg.'</font>
<font size="4">- Salt la pagina: </font>
<input type="text" name="page" id="page">
<input type="hidden" name="search" id="search" value="'.$search.'">
<input type="hidden" name="title" id="title" value="'.$page_title.'">
<input type="submit" value="GO!">
</form></td>
<TD colspan="2" align="right">';
if ($page > 1)
echo '<a href="tvrplus_e.php?page='.($page-1).','.$search1.','.urlencode($page_title).'"><font size="4"> << </font></a> | <a href="tvrplus_e.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4"> >> </font></a></TD></TR>';
else
echo '<a href="tvrplus_e.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4"> >> </font></a></TD></TR>';
}

$html=str_replace("premiumBackground","itemBackground",$html);
$html=str_replace('premiumDiv','class="itemBackground',$html);
$html=str_replace("premiumThumb","itemsThumb",$html);

$html=str_replace("floatL trailerHref","itemBackground",$html);
$html=str_replace("trailerItem","itemsThumb",$html);
$html=str_replace('title="','><>',$html);
$html=str_replace('" data-trailer-Id="','<',$html);
$html=str_replace('class="trailerDiv','a class="floatL',$html);

$html=str_replace('class="tvSpan','class="itemBackground',$html);
$html=str_replace("canaletvThumb","itemsThumb",$html);
$html=str_replace('floatL ccsSprites canaletvRightArrow','class="floatL ccsSprites RightArrow',$html);

$html=str_replace('radioA','class="itemBackground',$html);
$html=str_replace("radioThumb","itemsThumb",$html);
$html=str_replace('" rel="','<',$html);
$html=str_replace('floatL ccsSprites radioRight','class="floatL ccsSprites RightArrow',$html);


$html= str_between($html,'class="floatL itemsThumb">','class="floatL ccsSprites RightArrow');
$videos = explode('a class="floatL', $html);

unset($videos[0]);

$videos = array_values($videos);
$n=0;
foreach($videos as $video) {
  $t1=explode('href="',$video);
if ( sizeof($t1)>1) {
  $t2=explode('"',$t1[1]);
  $l=$t2[0];
  $rest = substr($l, 0, -2);
  $id = substr(strrchr($rest, "-"), 1);
  if (strpos($video,'idpl') !== false)
	$id = str_between($video,'id="idpl','"');
//  if (strpos($video,' data-id') !== false)
//	$id = str_between($video,' data-id="','"');

  $t1=explode('src="',$video);
if ( sizeof($t1)>1) {
  $t2=explode('"',$t1[1]);
  $image=$t2[0];

  $t1=explode('class="itemBackground',$video);
  $t2=explode(">",$t1[1]);
  $t3=explode("<",$t2[2]);
  $title=$t3[0];
  $title=str_replace('"','',$title);
}
}
  $rest = substr($search1, 0, -8);
  $pg_id = substr(strrchr($rest, "-"), 1);

  if (! is_numeric($id) ) {
  if (is_numeric($pg_id) ) {
  $items = $videos_arr;
  $h=search_arr($items, 'thumbnail', $image);
  if ($h) {
		$id="";
		$arr=$h[0];
		if (array_key_exists("willStartPlayingUrl",$arr)) {
			$t1=$arr['willStartPlayingUrl'];
			$t2=explode('/',$t1);
			$id=$t2[sizeof($t2)-1];
		} else 
		if (array_key_exists("streamUrl",$arr)) {
			$t1=$arr['streamUrl'];
			$t2=explode('=',$t1);
			$id=$t2[sizeof($t2)-1];
		}
	}
  }
}  
  if (! is_numeric($id) ) {
    $t0 = explode('href="',$video);
    $t1 = explode('"', $t0[1]);
    $l = "http://www.seenow.ro".$t1[0];
    $link = substr($l, 0, -1);
	$rest = substr($l, 0, -2);
	$id = substr(strrchr($rest, "-"), 1);
	$link="tvrplus_e.php?page=1,".urlencode($link).",".urlencode($title);
  } else {
	$link="tvrplus_e_link.php?file=".urlencode($id)."&pg_id=".urlencode($pg_id)."&title=".urlencode($title);
  }
  if ($n==0) echo '<TR>';
if (strpos($link,"remove") === false) {
echo '
<TD style="vertical-align:top;text-align:center;" colspan="1"><a href="'.$link.'" target="_blank"><img src="'.$image.'" width="'.$wi.'" height="'.$hi.'"><BR><font size="4"><b>'.$title.'</b></font></a></TD>

';
$n++;
}
if(($pg_id==22) || ($pg_id==5036)){
if ($n==5) {
echo '</TR>';
$n=0;
}
} else {
if ($n==4) {
echo '</TR>';
$n=0;
}
}
}
echo '</TABLE>';
?>
</body>
</html>
