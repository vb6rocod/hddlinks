<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
$link = $_GET["file"];
$html = file_get_contents($link);
$mod=str_between($html,"url_mode=","&");
$srv=str_between($html,"srv=","&");
$file=str_between($html,"file=","&");
if ($mod=="3")
  $link1=urldecode($file);
else if ($mod=="1")
  $link1=urldecode($srv."/key=".$file);
$out=$link1;
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="video.mp4"');
header("Location: $out");
?>
