<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$link = $_GET["file"];
$html = file_get_contents($link);
$mod=str_between($html,"url_mode=","&");
$srv=str_between($html,"srv=","&");
$file=str_between($html,"file=","&");
if ($mod=="3")
  $link1=urldecode($file);
else if ($mod=="1")
  $link1=urldecode($srv."/key=".$file);
$out=$link1;
//http://3.xhcdn.com/key=zUGGnPt1Xpg,end=1409832066/data=8B4F6888/speed=150k/1471293_hot_brunette_britney_got_dp_and_gangbang_fucked.flv
//http://154.56.81.89/key=EOdgOnTqvJg,end=1409832066/data=TmC9,8B4F6888/speed=150000/buffer=750000/reftag=5412162/1/21/7/4379507/1471293_hot_brunette_britney_got_dp_and_gangbang_fucked.flv
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $out);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, 1);
  curl_setopt($ch, CURLOPT_NOBODY, 1);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language: ro-ro,ro;q=0.8,en-us;q=0.6,en-gb;q=0.4,en;q=0.2","Accept-Encoding: gzip, deflate"));
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html = curl_exec($ch);
  curl_close($ch);

  $out=trim(str_between($html,"Location:","\n"));
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="video.mp4"');
header("Location: $out");
} else {
die();
}
?>
