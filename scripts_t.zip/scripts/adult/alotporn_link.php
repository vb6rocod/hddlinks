<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$link = $_GET["file"];
$html = file_get_contents($link);
/*
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html = curl_exec($ch);
  curl_close($ch);
echo $html;
die();
*/
$link = str_between($html, "var cnf='", "'");
$html = file_get_contents($link);
$link1 = str_between($html, "<file>", "</file>");
$link1=str_replace("&amp;","&",$link1);
$out=$link1;
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="video.mp4"');
header("Location: $out");
} else {
$a=urlencode(",");
$out=str_replace("&amp;","&",$out);
//$out=str_replace(",",$a,$out);
echo '
<!doctype html>
<HTML>
<HEAD>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
';
echo '
<script type="text/javascript" id="nuevo" src="http://cdn1.alotporn.com/media/player/nuevo8/player.js"></script>

</HEAD>
<BODY>
';
echo '
		<div id="nuevoplayer"></div>
		<script type="text/javascript">
';
echo "
var cnf='".$link."';
var w=$(document).width();
var h=$(document).height();
var h2=$(document).height();
nvplayer.start( {id:'nuevoplayer',config:'".$link."',width:w,height:h,height2:h2});
</script>
";
echo '
</BODY>
</HTML>
';
}
?>
