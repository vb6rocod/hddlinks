<!DOCTYPE html>
<?php
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page= $queryArr[0];
   $search = $queryArr[1];
   $tit = urldecode($queryArr[2]);
   $tit=str_replace("\\","",$tit);
   $page_title=$tit;
}
include ("../common.php");
$f=$base_pass."seenow.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
if ($t1[0]=="DA") {
$wi="171";
$hi="96";
} else {
$wi="200";
$hi="180";
}
} else {
$wi="200";
$hi="180";
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <title><?php echo $tit; ?></title>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<h2 style="background-color:deepskyblue;color:black"><?php echo $tit; ?></H2>
<table border="1px" width="100%">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function xml_fix($string) {
    $v=str_replace("\u015e","S",$string);
    $v=str_replace("\u015f","s",$v);
    $v=str_replace("\u0163","t",$v);
    $v=str_replace("\u0162","T",$v);
    $v=str_replace("\u0103","a",$v);
    $v=str_replace("\u0102","A",$v);
    $v=str_replace("\u00a0"," ",$v);
    $v=str_replace("\u00e2","a",$v);
    $v=str_replace("\u021b","t",$v);
    $v=str_replace("\u201e","'",$v);
    $v=str_replace("\u201d","'",$v);
    $v=str_replace("\u0219","s",$v);
    $v=str_replace("\u00ee","i",$v);
    $v=str_replace("\u00ce","I",$v);
    $v=str_replace("\u2019","'",$v);
    $v=str_replace("\/","/",$v);
    return $v;
}
$n=0;
if ($tit=="Private Hardcore")
include ("hardcore.php");
elseif ($tit=="Private Softcore")
include ("softcore.php");
else
include ("mix.php");
$search1=str_replace("&","|",$search);
if ( $page <>"" ) {
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="tvrplus_e.php?page='.($page-1).','.$search1.','.urlencode($page_title).'"><font size="4"> << </font></a> | <a href="tvrplus_e.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4"> >> </font></a></TD></TR>';
else
echo '<a href="tvrplus_e.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4"> >> </font></a></TD></TR>';
}
$k=count($a);
$start=1+ ($page-1)*12;
$end=min($k-1,1+ $page*12);
//$html = file_get_contents($link);
for ($i=$start;$i<$end+1;$i++) {
  $t1=explode('|',$a[$i]);
  $id=$t1[0];

  $image="http://static.seenow.ro/img/mediadirect/movie/thumb/".$t1[1];
  $title=$t1[2];
  $link="../tv/tvrplus_e_link.php?file=".urlencode($id)."&title=".urlencode($title);
  if ($n==0) echo '<TR>';
echo '
<TD style="vertical-align:top;text-align:center;" colspan="1"><a href="'.$link.'" target="_blank"><img src="'.$image.'" width="'.$wi.'" height="'.$hi.'"><BR><font size="4"><b>'.$title.'</b></font></a></TD>

';
$n++;
if ($n==4) {
echo '</TR>';
$n=0;
}
}
echo '</TABLE>';
?>
</body>
</html>
