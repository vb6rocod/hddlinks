<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>Adult</title>
<link rel="stylesheet" type="text/css" href="custom.css" />
<style>
td {
    font-style: bold;
    font-size: 20px;
    text-align: left;
}
</style>
<BODY>
<BR><BR>


<?php
include ("common.php");
$f=$base_pass."adult.txt";
if (!file_exists($f)) {
//echo '<h2 style="background-color:deepskyblue;color:black"><center>Activati sau dezactivati sectiunea Adult din setari!</center></h2>';
} else {
$h=file_get_contents($f);
$t1=explode("|",$h);
$adult=$t1[0];
}
if ($adult=="DA") {
echo '
<table border="1" align="center" width="90%">
<TR>
<th class="cat" colspan="4">Adult</Th>
</TR>
<TR>
<TD width="25%"><a href="adult/tube8_main.php" target="_blank">tube8</a></TD>
<TD width="25%"><a href="adult/youporn_main.php" target="_blank">youporn</a></TD>
<TD width="25%"><a href="adult/redtube_main.php" target="_blank">redtube</a></TD>
<TD width="25%"><a href="adult/xhamster_main.php" target="_blank">xhamster</a></TD>
</tr>
<tr>

<TD width="25%"><a href="adult/xnxx_main.php" target="_blank">xnxx</a></TD>
<TD width="25%"><a href="adult/xvideos_main.php" target="_blank">xvideos</a></TD>
<TD width="25%"><a href="adult/4tube_main.php" target="_blank">4tube</a></TD>
<TD width="25%"><a href="adult/milfzr_main.php" target="_blank">milfzr</a></TD
</tr>
<tr>

</tr>
<TR>
<TD width="25%"><a href="adult/pornjam_main.php" target="_blank">pornjam</a></TD>
<TD width="25%"><a href="adult/pornburst_main.php" target="_blank">pornburst</a></TD>
<TD width="25%"><a href="adult/anybunny_main.php" target="_blank">anybunny</a></TD>
<TD width="25%"><a href="adult/incestvidz_main.php" target="_blank">incestvidz</a></TD>
</TR>
<TR>


<TD width="25%"><a href="adult/slutload_main.php" target="_blank">slutload</a></TD>
<TD width="25%"><a href="adult/ah-me_main.php" target="_blank">ah-me</a></TD>
<TD width="25%"><a href="adult/fapbox_main.php" target="_blank">fapbox</a></TD>
<TD width="25%"><a href="adult/pornhub_main.php" target="_blank">porhub</a></TD>
</TR>
<TR>

<TD width="25%"><a href="adult/tnaflix_main.php" target="_blank">tnaflix</a></TD>
<TD width="25%"><a href="adult/jizzbunker_main.php" target="_blank">jizzbunker</a></TD>
<TD width="25%"><a href="adult/pornfree_main.php" target="_blank">pornfree.tv</a></TD>
<TD width="25%"><a href="adult/spankbang_main.php" target="_blank">spankbang</a></TD>
</TR>

<TR>
<TD width="25%"><a href="adult/thumbzilla_main.php" target="_blank">thumbzilla</a></TD>
<TD width="25%"><a href="adult/taboop_main.php" target="_blank">taboop</a></TD>
<TD width="25%"><a href="adult/lubetube_main.php" target="_blank">lubetube</a></TD>
<TD width="25%"><a href="adult/pornhd_main.php" target="_blank">pornhd</a></TD>
</TR>

<TR>
<TD width="25%"><a href="adult/youjizz_main.php" target="_blank">youjizz</a></TD>
<TD width="25%"><a href="adult/porn_main.php" target="_blank">porn.com</a></TD>
<TD width="25%"><a href="adult/drtuber_main.php" target="_blank">drtuber</a></TD>
<TD width="25%"><a href="adult/vporn_main.php" target="_blank">vporn</a></TD>
</TR>

<TR>
<TD width="25%"><a href="adult/nuvid_main.php" target="_blank">nuvid</a></TD>
<TD width="25%"><a href="adult/sunporno_main.php" target="_blank">sunporno</a></TD>
<TD width="25%"><a href="adult/porn300_main.php" target="_blank">porn300</a></TD>
<TD width="25%"><a href="adult/zbporn_main.php" target="_blank">zbporn</a></TD>
</TR>

<TR>
<TD width="25%"><a href="adult/mofosex_main.php" target="_blank">mofosex</a></TD>
<TD width="25%"><a href="adult/xbabe_main.php" target="_blank">xbabe</a></TD>
<TD width="25%"><a href="adult/porndroids_main.php" target="_blank">porndroids</a></TD>
<TD width="25%"><a href="adult/befuck_main.php" target="_blank">befuck</a></TD>
</TR>

<TR>
<TD width="25%"><a href="adult/hdmovz_main.php" target="_blank">hdmovz</a></TD>
<TD width="25%"><a href="adult/pornrox_main.php" target="_blank">pornrox</a></TD>
<TD width="25%"><a href="adult/pornmaki_main.php" target="_blank">pornmaki</a></TD>
<TD width="25%"><a href="adult/proporn_main.php" target="_blank">proporn</a></TD>
</TR>

<TR>
<TD width="25%"><a href="adult/pornhost_main.php" target="_blank">pornhost</a></TD>
<TD width="25%"><a href="adult/handjobhub_main.php" target="_blank">handjobhub</a></TD>
<TD width="25%"><a href="adult/vpornvideos_main.php" target="_blank">vpornvideos</a></TD>
<TD width="25%"><a href="adult/dansmovies_main.php" target="_blank">dansmovies</a></TD>
</TR>

<TR>
<TD width="25%"><a href="adult/pornheed_main.php" target="_blank">pornheed</a></TD>
<TD width="25%"><a href="adult/pornrabbit_main.php" target="_blank">pornrabbit</a></TD>
<TD width="25%"><a href="adult/eroxia_main.php" target="_blank">eroxia</a></TD>
<TD width="25%"><a href="adult/deviantclip_main.php" target="_blank">deviantclip</a></TD>
</TR>
<!--
<TR>
<TD width="25%"><a href="adult/h2porn_main.php" target="_blank">h2porn</a></TD>
</TR>
-->
';

echo '
</table>
';
}
?>
<BR><BR>
<?php
if (file_exists($base_pass."tastatura.txt")) {
$tast=trim(file_get_contents($base_pass."tastatura.txt"));
} else {
$tast="NU";
}
if ($tast=="DA") {
echo '
<table id="data" border="0" align="center" width="90%">
<TR><TD>* Folositi tasta 5 pentru a simula butonul de cautare.<TD></TR>
</TABLE>';
}
?>
</BODY>
</HTML>
