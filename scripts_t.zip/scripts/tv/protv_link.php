<?php

function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$flash="NU";
$link = $_GET["file"];
$title=urldecode($_GET["title"]);
$h = file_get_contents("http://protvplus.ro".urldecode($link));
$serv = str_between($h,"rtmp:","'");
//$t1 = str_between($h,'$.ajax(','$f(');
$t1=explode("$.ajax({",$h);
$linkajax=str_between($t1[1],'url: "','"');
//$linkajax="/lbin/ajax/config1.php?site=94000&realSite=94000&subsite=753&section=20720&media=61288956&jsVar=fltfm&mute=0&size=&pWidth=700&pHeight=435";
$h = file_get_contents("http://protvplus.ro/".$linkajax);
$h = str_replace("\\","",$h);
//echo $h;
$id = str_between($h,'url":"','"');
//$id=str_replace("x","_HD",$id);
$title =  str_between($h,'title":"','"');


//$out = "http:".$serv."/".$id."/".$title.".m3u8" - de facut
//echo $out; die();
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} else {
$out = $id."-HD-1.mp4";
$rtmp = "rtmp:".$serv."/";

echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.ucwords(strtolower($title)).'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="../filme/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>


</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"players": [{"type":"flash","src":"../filme/player.swf"}],
"file": "'.$out.'",
"type": "rtmp",
"height": $(document).height(),
"width": $(document).width(),
"dock": "true",
"autostart": "true",
"controlbar.position": "over",
"controlbar.idlehide": "false",
"backcolor": "000000",
"frontcolor": "ffffff",
"lightcolor": "f7b01e",
"streamer": "'.$rtmp.'",
"volume": "100",
});
</script>
</BODY>
</HTML>
';
}
?>
