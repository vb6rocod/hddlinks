<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>TVR Plus</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$wi="200";
$hi="160";
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><td style="color:black;background-color:deepskyblue;text-align:center" colspan="4"><font size="4"><b>TVR Plus</b></font></TD></TR>';
//http://www.tvrplus.ro/detalii/ajax-tab/tab/1/program_id/5487
$n=0;
$l="http://www.tvrplus.ro/emisiuni";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER, "http://www.tvrplus.ro/emisiuni");
  $html = curl_exec($ch);
  curl_close($ch);

$videos = explode('div class="emisiune', $html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  $t0 = explode('href="',$video);
  $t1 = explode('"', $t0[1]);
  if (strpos($t1[0],"http") !== false)
     $link=$t1[0];
  else
     $link = "http://www.tvrplus.ro".$t1[0];
  //$id = substr(strrchr($link, "-"), 1);
  $id=$link;
  $t1 = explode('class="pN">', $video);
  $t2 = explode('<', $t1[1]);
  $title = trim($t2[0]);

  $t1=explode('original="',$video);
  $t2=explode('"',$t1[1]);
  $image=$t2[0];
  $link="plus.php?id=".$id."&title=".urlencode($title);
    if ($title) {
	if ($n == 0) echo "<TR>"."\n\r";
	echo '<TD style="text-align:center">'.'<a href="'.$link.'" target="_blank"><img src="'.$image.'" width="'.$wi.'" height="'.$hi.'"><BR><font size="4">'.$title.'</a></font></TD>';
    $n++;
    if ($n == 4) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }
}
 if ($n<4) echo "</TR>"."\n\r";
 echo '</table>';
?>
<BODY>
</HTML>
