<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Sopcast</title>
      <link rel="stylesheet" type="text/css" href="../custom.css" />
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js?_=835925279"></script>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js?_=101377612"></script>
      <script type="text/javascript" src="<?php echo $noob; ?>/func.js"></script>
      <script type="text/javascript" src="../jquery-1.10.1.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
});
</script>
</head>
<body>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("canale.php");
//echo '<H3><center>Sopcast</center></H3>';
echo '<table border="2" width="100%">'."\n\r";
echo '<TR><td style="background-color:deepskyblue;color:black;text-align:center" colspan="6"><font size="4"></b>Sopcast</b></font></TD></TR>';
$n=0;
$link="http://streams.magazinmixt.ro/modules/channels/channels_store.php/?id_cat=&offline=0&search_txt=&country=&protocol=1";
$link="http://www.albanetinfo.ro/m/tv-live";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
$videos = explode("wtv_play(", $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    if ($n == 0) echo "<TR>"."\n\r";
    $t1=explode("'",$video);
    $t2=explode("'",$t1[1]);
    $sop="sop://broker.sopcast.com:3912/".$t2[0];
    $sop=str_replace("\\","",$sop);
    $t1=explode(">",$video);
    $t2=explode("<",$t1[1]);
	$title = trim($t2[0]);
    echo '<TD style="text-align:center"><font size="4"><font size="4">'.'<a href="'.$sop.'">'.$title.'</a></font></TD>';
    $n++;
	if (array_key_exists(strtolower($title), $a))
		echo '<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id='.$a[strtolower($title)].'&title='.urlencode($title).'"><font size="4">PROG</font></a></TD>';
	else
		echo '<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=&title='.urlencode($title).'"><font size="4">PROG</font></a></TD>';
    $n++;
    if ($n > 5) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }
 if ($n<6) echo "</TR>"."\n\r";
 echo '</table>';
?>
<br></body>
</html>
