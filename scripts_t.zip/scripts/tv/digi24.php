<!DOCTYPE html>
<?php
include ("../common.php");
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>Digi24</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
//http://www.hdfilm.ro/index.php?p=filme&gen=Actiune&page=1
echo '<h2 style="background-color:deepskyblue;color:black">Digi24</H2>';
echo '<table border="1px" width="100%">'."\n\r";
$html=file_get_contents("http://www.digi24.ro/rss/");
//$html=file_get_contents("http://www.digi24.ro/rss/Emisiuni/Digi24/");
$videos = explode('<item>', $html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  //$link = str_between($video,'media:content url="','"');
  $t1=explode('media:content url="',$video);
 if (sizeof ($t1) > 1 ) {
  $t2=explode('"',$t1[2]);
  $link=$t2[0];
  $link=str_replace("240p","360p",$link);
  $title = trim(str_between($video,"<title>","</title>"));

  $image = str_between($video,'media:thumbnail url="','"');
  $descriere = trim(str_between($video,"<description>","</description>"));
  $link1="direct_link.php?file=".$link."&title=".$title;
  if ($link) {
  echo '<TR><TD><table border="0" width="100%">'."\n\r";
  echo '<TR>';
  echo '<td align="center" width="30%"><a href="'.$link1.'" target="_blank"><img src="'.$image.'" width="180px" height="144px"><BR><font size="4">'.$title.'</font></a></TD>';
  echo '<td style="vertical-align:top;">'.$descriere.'</td>';
  echo '</tr>';
  echo '</table></TD></TR>';
  }
 }
}
echo "</table>";
?>
<br></body>
</html>
