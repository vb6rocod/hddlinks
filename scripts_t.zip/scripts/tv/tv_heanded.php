<!DOCTYPE html>

<html>

   <head>

      <meta charset="utf-8">
      <title>HTS Tvheadend</title>
      <link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
 $("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
  </head>
   <body>
<h2 style="background-color:deepskyblue;color:black;;text-align:center">TV Heanded</H2>

<table border="1px" width="100%">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}

$n=0;
//$link=str_replace('\"','"',$link);
$link="http://www.ahy.96.lt/htstvh.txt";
//$link=file_get_contents($link);
//echo $link;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html = curl_exec($ch);
  curl_close($ch);
//echo $html;
$n=0;
$videos = explode('<e2service>', $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
    $link=trim(str_between($video,'href="','"'));
	//$title=trim(str_between($video,'<div class="x-grid3-cell-inner x-grid3-col-1" unselectable="name">','</div>'));
	//$link=trim(str_between($video,"open_epg_pop('","'"));
    //$link=trim(str_between($video,'<a href="','">Play'));
	$title=trim(str_between($video,'unselectable="name">',"</div>"));
	//$title=trim(str_between($video,'name=',"'"));
    $link="heandedtv_link.php?link=".urlencode($link)."&title=".urlencode($title);
    $title1=strtolower($title);
    $title1=str_replace(" ","-",$title1);
    if ($title <> "") {
    if ($n == 0) echo "<TR>"."\n\r";
    echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
    $n++;
   	echo '	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id='.$title1.'&title='.urlencode($title).'"><font size="4">PROG</font></a></TD>';
    $n++;
    if ($n > 5) {
     echo '</TR>'."\n\r";
     $n=0;
    }
  }
}
if ($n<6) echo "</TR>"."\n\r";
 echo '</table>';
?>
</body>
</html>
