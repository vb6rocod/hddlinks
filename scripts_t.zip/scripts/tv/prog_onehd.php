<?php
error_reporting(0);
$id = $_GET["id"];
$title = urldecode($_GET["title"]);

function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function c($title) {
     $title = htmlentities($title);
     $title = str_replace("&ordm;","s",$title);
     $title = str_replace("&Ordm;","S",$title);
     $title = str_replace("&thorn;","t",$title);
     $title = str_replace("&Thorn;","T",$title);
     $title = str_replace("&icirc;","i",$title);
     $title = str_replace("&Icirc;","I",$title);
     $title = str_replace("&atilde;","a",$title);
     $title = str_replace("&Atilde;","I",$title);
     $title = str_replace("&ordf;","S",$title);
     $title = str_replace("&acirc;","a",$title);
     $title = str_replace("&Acirc;","A",$title);
     $title = str_replace("&oacute;","o",$title);
     $title = str_replace("&amp;", "&",$title);
     return $title;
}

/* by jumpinjk start */

function g_file ($link){
    $process = curl_init($link);
	curl_setopt($process, CURLOPT_HTTPGET, 1);
	curl_setopt($process, CURLOPT_USERAGENT, "MozillaXYZ/1.0");
	curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($process,CURLOPT_CONNECTTIMEOUT, 5);
	$html = curl_exec($process);
	curl_close($process);
	return $html;
}

function get_remote_time($location, $switch){
//get_remote_time use a remote database (from http://twiki.org) to provide remote local time; the database is up to date.
//to use this service without buying an api is necessary to trick the file get operation by identify as Mozilla; curl will do this trick... ;-) 

//format: 	get_remote_time("Region/City", switch);
//examples:
//			get_remote_time("Europe/Bucharest", 5);
//			get_remote_time("Europe/London", 4);
//			get_remote_time("America/Toronto", 7);

//switches:
//			0 return current remote location day in week (ex: Sun for Sunday)
//			1 return current remote location day in a month (ex: 27)
//			2 return current remote location month (ex: May)
//			3 return current remote location year (ex: 2012)
//			4 return current remote location time (23:20:12 - HH:MM:SS)
//			5 return current remote location time shift related to GMT(+4:00 for GMT+4:00)
//			6 return current remote location zone abbreviation (ex: EEST stands for EEST – Eastern European Summer Time)
//			7 return remote location unprocessed string (ex: "Sun, 13 May 2012, 16:57:10 -0400 (EDT)" for America/Toronto)

	$link = "http://twiki.org/cgi-bin/xtra/tzdate?tz=".$location;
	$string = str_between(g_file($link), "<!--tzdate:date-->", "<!--/tzdate:date-->");
	if ($switch < 7) {
	 $stk = explode(" ",$string);
	 $stk[0] = trim($stk[0], ',');
	 $stk[5] = substr($stk[5],0,3).":".substr($stk[5],3);
	 $stk[6] = trim($stk[6], '(,)');
	return $stk[$switch];
	}
	return $string;
}

function get_local_time_zone () {
	$link = "http://www.ip2location.com";
	$string = str_between(g_file($link), ">Time Zone</label></td>", "</tr>");
    $string = str_between($string, '<label for="chkTimeZone">', "</label>");
	return $string;
}

$tz = get_local_time_zone();
$tz1 = get_remote_time("Europe/Bucharest", 5);
$ora1 = strtotime($tz) - strtotime($tz1);

/* by jumpinjk end */

print '<font size="4">';

$link="http://www.livehd.tv/epg/epg.php";
//print("<b>".$title." ( GMT ".$tz." )"."</b><BR><BR>");
print('<h2 style="background-color:deepskyblue;color:black;text-align:left;"><b>'.$title.' ( GMT '.$tz.' )'.'</b></H2>');
if (($link) && ($id > 0)) {
$html = file_get_contents($link);
$t1=explode('table class="text3"',$html);
$html=$t1[$id];
if ($id > 0) {
$videos = explode('text=', $html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  $t1=explode('/',$video);
  $ora = trim(substr($t1[0],0,5));
  $ora=str_replace('&nbsp;','',$ora);
  
  $ora=strftime("%H:%M", strtotime($ora) - $ora1); 	// adjust EPG for local time
  
   $emisiune=trim(substr($t1[0],5,-1));
   $emisiune=str_replace('&nbsp;','',$emisiune);
   $emisiune=str_replace('"','',$emisiune);
   $emisiune=str_replace('.',' ',$emisiune);
   $emisiune=str_replace('_',' ',$emisiune);
   $emisiune=str_replace('.mp4','',$emisiune);
  print($ora."   ".$emisiune."<BR>");					// the curent EPG can be sorted and the current show can be eventualy highlited...
}
}
print "</font>";
} else {
echo "FARA PROGRAM";
}
?>
