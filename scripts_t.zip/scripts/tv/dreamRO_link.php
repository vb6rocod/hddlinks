<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$id=$_GET["link"];
$serv=trim($_GET["serv"]);
$opt[1]="http://188.26.30.180:8001/";
$opt[2]="http://79.116.18.76:8001/";
$opt[3]="http://79.118.49.96:8001/";

//$h=file_get_contents("http://217.162.34.65/api/zap?sRef=".$id."");
//http://94.177.57.213/ajax/epgpop?sref=1%3A0%3A1%3A76C2%3A2C0%3A600%3AE080000%3A0%3A0%3A0%3A

//$a=trim(str_between($h,"Active service is now '","'"));
$out=$serv.":8001/".$id;
$a="asasasas";
if ($a) {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} else {
die();
}
?>
