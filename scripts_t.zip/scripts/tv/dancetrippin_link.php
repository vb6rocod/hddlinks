<?php
function str_between($string, $start, $end){ 
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
include ("../common.php");
$cookie=$base_cookie."vimeo.dat";
$link = $_GET["file"];
//echo urldecode($link);

$html = file_get_contents(urldecode($link));
$l=str_between($html,"config=",'"');
$h=file_get_contents(urldecode($l));

$link = str_between($h, 'url": "', '"');
$filelink=str_replace("https","http",$link);
  if (strpos($filelink,"player.vimeo.com") !==false) {
     $t1=explode("?",$filelink);
     $filelink=$t1[0];
     $t1=explode("/",$filelink);
     $id=$t1[4];
  } else {
     $t1=explode("/",$filelink);
     $id=$t1[3];
  }
  //$cookie="D://cookie.txt";
  $l="http://vimeo.com/".$id;
  //echo $l."<BR>";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  $l1=str_between($html,'data-config-url="','"');
  $l1=str_replace("&amp;","&",$l1);
  //$l1="http://player.vimeo.com/config/".$id."?type=moogaloop&referrer=vimeo.com&cdn_server=a.vimeocdn.com&player_server=player.vimeo.com&clip_id=".$id;
  //echo $l1."<BR>";
  //$l1="http://player.vimeo.com/video/98321920/config?autoplay=0&byline=0&bypass_privacy=1&context=clip.main&default_to_hd=1&portrait=0&title=0&s=ee2f825e1cdcdacd5fd9264a39a56e45a0b44c45";
  //echo $l1."<BR>";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h1 = curl_exec($ch);
  curl_close($ch);
  //echo $h1;
  if (strpos($h1,'hd":') !== false) {
    $t1=explode('hd":',$h1);
    $link=str_between($t1[1],'url":"','"');
  } else {
    $t1=explode('sd":',$h1);
    $link=str_between($t1[1],'url":"','"');
  }
  /*
  $sig_param=str_between($h1,'signature":"','"');
  $player_url=str_between($h1,'player_url":"','"');
  $time_param=str_between($h1,'"timestamp":',',');
  if (strpos($h1,'hd":0') !== false)
    $hd="sd";
  else
    $hd="hd";
  $stream_url="http://".$player_url."/play_redirect?clip_id=".$id."&sig=".$sig_param."&time=".$time_param."&quality=".$hd."&codecs=H264,VP8,VP6&type=moogaloop&embed_location=&seek=0";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $stream_url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://a.vimeocdn.com/p/flash/moogaloop/5.2.49/moogaloop.swf?v=1.0.0");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch, CURLOPT_NOBODY, true);
  curl_setopt($ch, CURLOPT_HEADER  ,1);
  $html = curl_exec($ch);
  curl_close($ch);
  $t1=explode("Location:",$html);
  $t2=explode("\n",$t1[1]);
  $link=trim($t2[0]);

  */
  //echo $link;
  //die();
$movie=$link;
$movie_file=substr(strrchr($movie, "/"), 1);
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
?>
