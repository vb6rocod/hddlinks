<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Spice TV</title>
      <link rel="stylesheet" type="text/css" href="../custom.css" />
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js?_=835925279"></script>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js?_=101377612"></script>
      <script type="text/javascript" src="<?php echo $noob; ?>/func.js"></script>
      <script type="text/javascript" src="../jquery-1.10.1.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
});
</script>
<body>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
include ("canale.php");
$filename = $base_pass."spicetv.txt";
$cookie=$base_cookie."spicetv.dat";
$f=$base_pass."adult.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$adult=$t1[0];
} else {
$adult="NU";
}
if (file_exists($filename)) {
  $handle = fopen($filename, "r");
  $c = fread($handle, filesize($filename));
  fclose($handle);
  $a2=explode("|",$c);
  $a1=str_replace("?","@",$a2[0]);
  $user=urlencode($a1);
  $user=str_replace("@","%40",$user);
  $pass=trim($a2[1]);
if (!file_exists($cookie)) {
  $l="http://www.spicetv.ro/user/login";
  $post="email=".$user."&pass=".$pass."&submit=Login";
  //echo $post;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
}
}
  $link="http://www.spicetv.ro/tv-online";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
echo '<table border="1" align="center" width="100%">'."\n\r";
echo '<TR><td style="background-color:deepskyblue;color:black;text-align:center;" colspan="6"><font size="4"><b>Spice TV</b></font></TD></TR>';
$n=0;
$html=str_between($html,'ul class="overview','</ul');
$videos = explode('<li>', $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
   if ($n == 0) echo "<TR>"."\n\r";
   $t1=explode('href="',$video);
   $t2=explode('"',$t1[1]);
   $link=$t2[0];

   $t1=explode('title="',$video);
   $t2=explode('"',$t1[1]);
   $title1=$t2[0];
   $pos = strpos($title1, "18+");
 if (($pos === false) || ($adult === "DA")) {

   $tip=str_between($video,"<span>","</span>");
   if ($tip == "GRATUIT")
     $title=$title1." - ".$tip;
   else
     $title=$title1;

   $title2=str_replace(" (18+)","",str_replace(" Hungary","",str_replace(" Europe","",$title1)));
   $title1=str_replace("+","%2b",$title1);
   $t1=explode('src="',$video);
   $t2=explode('"',$t1[1]);
   $image=$t2[0];
	$link="spice_tv_link.php?file=".$link."&title=".urlencode($title1);
    echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
    echo '</TD>'."\n\r";
    $n++;
	$id_prog="";
	if (array_key_exists(strtolower(str_replace(" ","-",$title2)), $a))
		$id_prog=$a[strtolower(str_replace(" ","-",$title2))];
	echo '	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id='.$id_prog.'&title='.urlencode($title1).'"><font size="4">PROG</font></a></TD>';
    $n++;
    if ($n > 5) {
     echo '</TR>'."\n\r";
     $n=0;
    }
  }
 }
 if ($n<6) echo "</TR>"."\n\r";
 echo '</table>';
?>
<br></body>
</html>
