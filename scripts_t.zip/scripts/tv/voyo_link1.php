<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$link = $_GET["id"];
$tit = $_GET["title"];
$s="http://www.tastez.ro/tv.php?query=voyo&chn=".$link;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $s);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch,CURLOPT_REFERER,"http://www.dolcetv.ro");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
$p=str_between($html,"<object","</object");
$p="<object".$p."</object>";
//$p=str_replace('width="480"','width="728"',$p);
//$p=str_replace('height="270"','height="305"',$p);
?>

<!DOCTYPE html>
<html>



   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title><?php echo $tit ?></title>


      <style type="text/css">
         html { height: 100%; }
         body { height: 100%; margin:0; padding:0; background: #000000 }
         table { border-spacing: 0; border-collapse: collapse }
         td { padding: 0 }
         #header { background: #000000 url('Noobroom_files/opa.png'); border-bottom: 1px solid #ffffff; height: 120px }
         #footer { background: #000000 url('Noobroom_files/opa.png'); border-top: 1px solid #ffffff; height: 60px }
         a.hoverz:link { text-decoration:underline; }
         a.hoverz:active { text-decoration:underline; }
         a.hoverz:visited { text-decoration:underline; }
         a.hoverz:hover { text-decoration:underline; }
         a.hoverz:visited:hover { text-decoration:underline; }
         .balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
      </style>
<script src="http://static.voyo.ro.buc.cmestatic.com/static/ro/shared/js/swfobject.js" type="text/javascript"></script>
<script src="http://static.voyo.ro.buc.cmestatic.com/static/shared/js/eshop/videoPlayer.js?r=77210" type="text/javascript"></script>
<script src="http://static.voyo.ro.buc.cmestatic.com/static/shared/app/flowplayer/13-flowplayer-3.1.4.min-000.js" type="text/javascript"></script>
<script src="http://static.voyo.ro.buc.cmestatic.com/static/shared/app/flowplayer/flowplayer-video.js" type="text/javascript"></script>
   </head>



   <body>

<?php

if(!isset($_GET['screen_check']))
{
 echo "<script language='JavaScript'>
 <!-- 
 document.location=\"$PHP_SELF?screen_check=done&id=$link&title=$tit&Width=\"+window.innerWidth+\"&Height=\"+window.innerHeight;
 //-->
 </script>";
}
else 
{    
	if(isset($_GET['Width']) && isset($_GET['Height'])) {
		$w=$_GET['Width'];
		$h=$_GET['Height']-48;
		$p=str_replace('width="480"','width='.$w,$p);
		$p=str_replace('height="270"','height='.$h,$p);
	}
}
echo $p;
?>


</body></html>
