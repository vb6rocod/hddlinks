<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
//http://gradajoven.es/spicenew.php
//http://edge3.spicetvnetwork.de:1935/live/_definst_/mp4:spicetv/ro/6tv.stream/chunklist_w2087458837.m3u8?c=176&u=52409&e=1398753453&t=298944a96a9161b2300ae3ae072b85f4&d=android&i=1.30
//http://edge1.spicetvnetwork.de:1935/live/_definst_/mp4:spicetv/ro/6tv.streamchunklist_w2087458837.m3u8?c=176&u=52560&e=1398777448&t=3869972b307e53bfd2e048f093fd5f1c&d=site&i=Android%2C+Safari
$link = $_GET["file"];
$title = urldecode($_GET["title"]);
include ("../common.php");
$filename = $base_pass."spicetv.txt";
$cookie=$base_cookie."spicetv.dat";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERERE,"http://www.spicetv.ro/tv-online");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
  //echo $h;
//c=268&u=52741&e=1407652957&t=39796be28f01fdfe373706b4cecf7685&d=xbmc&i=HTTP
//c=268&u=52741&e=1407651660&t=9837cd6b7e03c26e1a35178b2ff39c4e&d=site&i=Windows+XP%2C+Firefox
//jsAppData=new Array("rtmp://core1.spicetv.ro:1935/redirect","mp4:spicetv/ro/Antena3.sdp","a9f811508037fa8566272aad0b890a51de1174301fd7210420092d838a6aab66");
//jsAppData=new Array("rtmp://origin1.eu.spicetvnetwork.zone:1935/redirect","mp4:spicetv/eu/BlackbeltTV.stream","c=268&u=52741&e=1407651660&t=9837cd6b7e03c26e1a35178b2ff39c4e&d=site&i=Windows+XP%2C+Firefox");var isMobile=false;
$h=str_between($h,'jsAppData=new Array("',")");
$h=str_replace('"',"",$h);
$t1=explode(",",$h);
$str=$t1[1];
$app=$t1[2];
$t1=explode("d=",$app);
$app=$t1[0]."d=Android&i=1.30";
//$title="playlist";
$out="http://edge".mt_rand(1,2).".spicetvnetwork.us:1935/live/_definst_/".$str."/".$title.".m3u8?".$app;
//$out="http://cdn".mt_rand(1,1).".eu.spicetvnetwork.zone:1935/live/_definst_/".$str."/".$title.".m3u8?".$app;
//echo $out;
//die();
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
?>
