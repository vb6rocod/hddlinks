<!DOCTYPE html>
<?php
$link=$_GET["id"];
$id = substr(strrchr($link, "-"), 1);
$pg_tit=urldecode($_GET["title"]);
$pg_tit=str_replace('\\',"",$pg_tit);
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $pg_tit; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function xml_fix($string) {
    $v=str_replace("\u015e","S",$string);
    $v=str_replace("\u015f","s",$v);
    $v=str_replace("\u0163","t",$v);
    $v=str_replace("\u0162","T",$v);
    $v=str_replace("\u0103","a",$v);
    $v=str_replace("\u0102","A",$v);
    $v=str_replace("\u00a0"," ",$v);
    $v=str_replace("\u00e2","a",$v);
    $v=str_replace("\u021b","t",$v);
    $v=str_replace("\u201e","'",$v);
    $v=str_replace("\u201d","'",$v);
    $v=str_replace("\u0219","s",$v);
    $v=str_replace("\u00ee","i",$v);
    $v=str_replace("\u00ce","I",$v);
    $v=str_replace("\u2019","'",$v);
    $v=str_replace("\/","/",$v);
    return $v;
}
$wi="200";
$hi="160";
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><td style="color:black;background-color:deepskyblue;text-align:center" colspan="4"><font size="4"><b>'.$pg_tit.'</b></font></TD></TR>';
//http://www.tvrplus.ro/detalii/ajax-tab/tab/1/program_id/5487
$n=0;
$l="http://www.tvrplus.ro/emisiuni";
$l="http://www.tvrplus.ro/detalii/ajax-tab/tab/1/program_id/".$id;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER, "http://www.tvrplus.ro/emisiuni");
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
if (strpos($html,'<div class="floatL arhivaScroll') !== false) {
$videos = explode('<div class="floatL artivaElement', $html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  $t0 = explode('href="',$video);
  $t1 = explode('"', $t0[1]);
  if (strpos($t1[0],"http") !== false)
     $link=$t1[0];
  else
     $link = "http://www.tvrplus.ro".$t1[0];
  $id = substr(strrchr($link, "-"), 1);

  $t1 = explode('<p>', $video);
  $t2 = explode('</p', $t1[1]);
  $title = trim($t2[0]);

  $t1=explode('alt="',$video);
  $t2=explode('"',$t1[1]);
  $image=$t2[0];

  $link="plus_link.php?id=".$id."&title=".urlencode($title);
    if ($title) {
	if ($n == 0) echo "<TR>"."\n\r";
	echo '<TD style="text-align:center">'.'<a href="'.$link.'" target="_blank"><img src="'.$image.'" width="'.$wi.'" height="'.$hi.'"><BR><font size="4">'.$title.'</a></font></TD>';
    $n++;
    if ($n == 4) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }
}

} else {
$html = file_get_contents($link);

$link= str_between($html,'flashvars.json_url="','"');
$html = file_get_contents($link);
$html =xml_fix($html);
$videos = explode('title":"', $html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  $t1=explode('"',$video);
  $title=$t1[0];
  $link=str_between($video,'url":"','"');
  $id = substr(strrchr($link, "-"), 1);
  $image=str_between($video,'image":"','"');
  //$image=str_replace("\/","/",$image);
  $title = str_between($video,'description":"','"');
  $link="plus_link.php?id=".$id."&title=".urlencode($title);
    if ($title) {
	if ($n == 0) echo "<TR>"."\n\r";
	echo '<TD style="text-align:center">'.'<a href="'.$link.'" target="_blank"><img src="'.$image.'" width="'.$wi.'" height="'.$hi.'"><BR><font size="4">'.$title.'</a></font></TD>';
    $n++;
    if ($n == 4) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }
}
}
 if ($n<4) echo "</TR>"."\n\r";
 echo '</table>';
?>
<BODY>
</HTML>
