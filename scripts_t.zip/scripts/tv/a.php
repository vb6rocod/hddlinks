<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$l="dolce.php";
$h=file_get_contents($l);
$h=str_between($h,'Seenow TV ***','</table');
$videos = explode('<TD style="text-align:',$h);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
 $t1=explode("id=",$video);
 $t2=explode('&',$t1[1]);
 $file=$t2[0];
 $t2=explode("&",$t1[2]);
 $id=$t2[0];
 $t3=explode("title=",$video);
 $t4=explode('"',$t3[1]);
 $title=urldecode($t4[0]);
 if (!preg_match("/Antena 3|Party|Transilvania Look/i",$title))
 $arr[]=array($title, $file,$id);
}
 asort($arr);
foreach ($arr as $key => $val) {
 $title=$arr[$key][0];
 $file=$arr[$key][1];
 $id=$arr[$key][2];
echo '
     <item>
     <title>'.$title.'</title>
     <onClick>
     <script>
     showIdle();
     url="http://127.0.0.1/cgi-bin/scripts/tv/php/seenow_tv_link.php?file='.$file.'," + buf;
     url1=getUrl(url);
     movie="http://127.0.0.1/cgi-bin/scripts/util/translate.cgi?stream," + url1;
     cancelIdle();
    streamArray = null;
    streamArray = pushBackStringArray(streamArray, "");
    streamArray = pushBackStringArray(streamArray, "");
    streamArray = pushBackStringArray(streamArray, movie);
    streamArray = pushBackStringArray(streamArray, movie);
    streamArray = pushBackStringArray(streamArray, video/mp4);
    streamArray = pushBackStringArray(streamArray, "'.$title.'");
    streamArray = pushBackStringArray(streamArray, "1");
    writeStringToFile(storagePath_stream, streamArray);
    doModalRss("rss_file:///usr/local/etc/www/cgi-bin/scripts/util/videoRenderer_tv1.rss");
     </script>
     </onClick>
    <id>'.$id.'</id>
     </item>
';
}
?>
