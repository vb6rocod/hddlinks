<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$id = $_GET["id"];
$title = urldecode($_GET["title"]);
$l="http://www.seenow.ro/service3/play/index/id/".$id."/platform_id/19";
$h = file_get_contents($l);
$h=str_replace("\\","",$h);
$l1=str_between($h,'streamUrl":"','|');
$s=str_between($h,'indexUrl":"','"');
$h = file_get_contents($s);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0];
if ($serv == "") {
  $serv="fms1.mediadirect.ro";
}
$out=str_replace("[%server_name%]",$serv,$l1);
$out=str_replace("playlist",$title,$out);
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
?>
