<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."tv.txt")) {
$tv=trim(file_get_contents($base_pass."tv.txt"));
} else {
$tv="dinamic";
}
$id = $_GET["id"];
$title = urldecode($_GET["title"]);
$PHP_SELF="";
$l="http://www.seenow.ro/service3/play/index/id/".$id."/platform_id/19";
$h = file_get_contents($l);
$h=str_replace("\\","",$h);
$t1=explode('high quality stream name":"',$h);
$t2=explode('"',$t1[1]);
$str=$t2[0];
$t1=explode('token=',$h);
$t2=explode('|',$t1[1]);
$token=$t2[0];
$l1=str_between($h,'streamUrl":"','|');
$s=str_between($h,'indexUrl":"','"');
$h = file_get_contents($s);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);

$serv=$t2[0];
if ($serv == "") {
  $serv="fms1.mediadirect.ro";
}
$out=str_replace("[%server_name%]",$serv,$l1);

if ($flash == "direct") {
$out=str_replace("playlist",$title,$out);
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} elseif (($flash=="html5" || $flash=="flash") && ($tv<>"vlc")) {
$app="live3";
if ($tv=="fms38.mediadirect.ro")
 $serv="fms38.mediadirect.ro";
$rtmp="rtmpe://".$serv."/".$app."/_definst_?token=".$token;

echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="../filme/jwplayer.js"></script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"players": [{"type":"flash","src":"../filme/player.swf"}],
"file": "'.$str.'",
"token": "'.$token.'",
"height": $(document).height(),
"width": $(document).width(),
"dock": "true",
"autostart": "true",
"controlbar.position": "over",
"controlbar.idlehide": "false",
"backcolor": "000000",
"frontcolor": "ffffff",
"lightcolor": "f7b01e",
"streamer": "'.$rtmp.'",
"volume": "100",
});
</script>
</BODY>
</HTML>
';
} else {
echo '
<html>
   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
</style>
      <title>'.$title.'</title>
   </head>
<body>

<embed type="application/x-vlc-plugin" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2"
width="100%"
height="100%"
id="vlc"
target="'.$out.'">
</embed>


    <script language="Javascript">

    var vlc = document.getElementById("vlc");
    vlc.audio.toggleMute();


    </script>

    </body>
    </Html>
';
}
?>
