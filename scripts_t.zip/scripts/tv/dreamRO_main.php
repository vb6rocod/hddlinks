<!DOCTYPE html>
<?php
//$link=$_GET["link"];
//$title=urldecode($_GET["title"]);
?>
<html>
<head>

      <meta charset="utf-8">
      <title>Dreambox TV</title>
      <link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
 $("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
  </head>
   <body>
<h2 style="background-color:deepskyblue;color:black;;text-align:center">Dreambox TV</H2>

<table border="1px" width="100%">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$link='http://hdforall3.strangled.net/ajax/bouquets';
//$link='http://217.162.34.65/ajax/channels?id=1%253A7%253A0%253A0%253A0%253A0%253A0%253A0%253A0%253A0%253A%2528provider%2520%253D%253D%2520%2522upc%2522%2529%2520%2526%2526%2520%2528type%2520%253D%253D%25201%2529%2520%257C%257C%2520%2528type%2520%253D%253D%252017%2529%2520%257C%257C%2520%2528type%2520%253D%253D%252022%2529%2520%257C%257C%2520%2528type%2520%253D%253D%252025%2529%2520%257C%257C%2520%2528type%2520%253D%253D%2520134%2529%2520%257C%257C%2520%2528type%2520%253D%253D%2520195%2529%2520ORDER%2520BY%2520name%2';
//$link = file_get_contents($link);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html = curl_exec($ch);
  curl_close($ch);
//echo $html;
$n=0;
//$videos = explode('<div class="channel_right">', $html);
$videos = explode('<a style="display: inline-block;"', $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
    //$link=trim(str_between($video,"open_epg_pop('","'"));
	$link=trim(str_between($video,'id="ajax/channels?id=','"'));
    //$title=trim(str_between($video,'name=',"'"));
	$title=trim(str_between($video,'">','</a>'));
	//$title=str_replace("Stream ","",$title);
    $link="dreamRO.php?link=".urlencode($link)."&title=".urlencode($title);
	//$link="dreamRO.php?link=".$link."&title=".$title"";
    if ($title <> "") {
    if ($n == 0) echo "<TR>"."\n\r";
    echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
    $n++;
    if ($n > 2) {
     echo '</TR>'."\n\r";
     $n=0;
    }
  }
}
if ($n<3) echo "</TR>"."\n\r";
 echo '</table>';
?>
</body>
</html>
