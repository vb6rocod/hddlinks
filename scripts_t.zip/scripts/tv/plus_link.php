<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}

$id = $_GET["id"];
$title = $_GET["title"];
$titlet=str_replace('\\',"",$title);
$link="http://www.tvrplus.ro/androidphone/show/editie/id/".$id;
$html = file_get_contents($link);
//echo $html;
$link="http://www.tvrplus.ro/androidphone/show/editie/id/".$id;
$html = file_get_contents($link);
$html=str_replace("\\","",$html);
$t1=explode('high quality stream name":"',$html);
$t2=explode('"',$t1[1]);
$str=$t2[0];

$t1=explode('application name":"',$html);
$t2=explode('"',$t1[1]);
$app=$t2[0];
if (!$app) $app="live3";

$t1=explode('token-high":"',$html);
$t2=explode('"',$t1[1]);
$token=$t2[0];

$s="http://index.mediadirect.ro/getUrl?publisher=68";
$s="http://index.mediadirect.ro/getUrl?file=".$str."&app=seenow&inst=_definst_&publisher=68";
$h = file_get_contents($s);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0];
if ($serv == "") {
  $serv="fms61.mediadirect.ro";
}
//http://fms61.mediadirect.ro:1937/seenow/_definst_/mp4:rectvrplus/2014/09/25/263364_Biziday_2014-09-25_22-00-00_576p_lp.mp4/25 sept. 2014.m3u8?user_id=0&transaction_id=0&device_id=0&publisher=24&client_ip=78.96.189.71&p_item_id=95927&token=f9266877f7e80acb03ec19bc59df4d0fbce5ed57c0c71144
$ip=$_SERVER['REMOTE_ADDR'];
$str="mp4:".$str;
$port="1937";
$app="seenow";

$out = "http://".$serv.":".$port."/".$app."/_definst_/".$str."/".$title.".m3u8?user_id=0&transaction_id=0&device_id=0&publisher=68&client_ip=".$ip."&p_item_id=".$id."&token=".$token;
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} else {
echo '
<html>
   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
</style>
      <title>'.$title.'</title>
   </head>
<body>

<embed type="application/x-vlc-plugin" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2"
width="100%"
height="100%"
id="vlc"
target="'.$out.'">
</embed>


    <script language="Javascript">

    var vlc = document.getElementById("vlc");
    vlc.audio.toggleMute();

    vlc.video.aspectRatio="16:9";


    </script>

    </body>
    </Html>
';
}
?>
