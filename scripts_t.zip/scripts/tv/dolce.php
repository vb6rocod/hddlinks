﻿<!DOCTYPE html>
<html>



   <head>

      <meta charset="utf-8">
      <title>Romania TV</title>
      <link rel="stylesheet" type="text/css" href="../custom.css" />
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js?_=835925279"></script>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js?_=101377612"></script>
      <script type="text/javascript" src="../jquery-1.10.1.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
});
</script>
  </head>
   <body>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("canale.php");
?>
<h2 style="background-color:deepskyblue;color:black;;text-align:center">Romania TV</H2>
<!-- *** TVR *** -->
<table border="1px" width="100%">
<TR><td style="background-color:deepskyblue;color:black;text-align:center;" colspan="6"><font size="4"><b>TVR</b></font></TD>
</TR>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=1&title=TVR+1" target="_blank">TVR 1</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10001&title=TVR+1"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=2&title=TVR+2" target="_blank">TVR 2</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10002&title=TVR+2"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=5&title=TVR+3" target="_blank">TVR 3</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10167&title=TVR+3"><font size="4">PROG</font></a></TD>
</TR>

<TR>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=18&title=TVR" target="_blank">TVR</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=&title=TVR"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=7&title=TVR+HD" target="_blank">TVR HD</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10190&title=TVR+HD"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=11&title=TVR News" target="_blank">TVR News</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10174&title=TVR+News"><font size="4">PROG</font></a></TD>
</TR>

<TR>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=12&title=TVR+Cluj" target="_blank">TVR Cluj</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10153&title=TVR+Cluj"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=13&title=TVR+Craiova" target="_blank">TVR Craiova</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10219&title=TVR+Craiova"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=14&title=TVR+Iaşi" target="_blank">TVR Iaşi</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10154&title=TVR+Iaşi"><font size="4">PROG</font></a></TD>
</TR>

<TR>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=15&title=TVR+Tîrgu-Mureş" target="_blank">TVR Tîrgu-Mureş</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10221&title=TVR+Tîrgu-Mureş"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=16&title=TVR+Timişoara" target="_blank">TVR Timişoara</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10220&title=TVR+Timişoara"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="tvr_tv_link.php?id=3&title=TVR+International" target="_blank">TVR International</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10015&title=TVR+International"><font size="4">PROG</font></a></TD>
</TR>

</table>

<table border="1px" width="100%">

<TR><td style="background-color:deepskyblue;color:black;text-align:center;" colspan="6" style="text-align:center"><font size="4"><b>OneHD Live!</b></font></TD></TR>
<TR>
	<TD style="text-align:center"><font size="4"><a href="onehd_tv_link.php?id=onehdhd&title=OneHD+-+Live!+Mix" target="_blank">OneHD - Live! Mix</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog_onehd.php?id=0&title=OneHD+-+Live!+Mix"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="onehd_tv_link.php?id=jazzhd&title=OneHD+-+Live!+Jazz" target="_blank">OneHD - Live! Jazz</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog_onehd.php?id=1&title=OneHD+-+Live!+Jazz"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="onehd_tv_link.php?id=classicshd&title=OneHD+-+Live!+Classics" target="_blank">OneHD - Live! Classics</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog_onehd.php?id=2&title=OneHD+-+Live!+Classics"><font size="4">PROG</font></a></TD>
</TR>

<TR>
	<TD style="text-align:center"><font size="4"><a href="onehd_tv_link.php?id=rockhd&title=OneHD+-+Live!+Rock" target="_blank">OneHD - Live! Rock</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog_onehd.php?id=3&title=OneHD+-+Live!+Rock"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="onehd_tv_link.php?id=pophd&title=OneHD+-+Live!+Pop" target="_blank">OneHD - Live! Pop</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog_onehd.php?id=4&title=OneHD+-+Live!+Pop"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="onehd_tv_link.php?id=dancehd&title=OneHD+-+Live!+Dance" target="_blank">OneHD - Live! Dance</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog_onehd.php?id=5&title=OneHD+-+Live!+Dance"><font size="4">PROG</font></a></TD>
</TR>
</table>

<!-- *** DolceTV *** -->
<?php
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><td style="background-color:deepskyblue;color:black;text-align:center;" colspan="6"><font size="4"><b>DolceTV</b></font></TD></TR>';
$n=0;
$link="http://www.dolcetv.ro/tv-live";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.dolcetv.ro");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
$html=str_replace("\\","",$html);
$videos = explode('<div class="station_program_cell', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {

	$t1 = explode('href="',$video);
	$t2 = explode('"',$t1[1]);
	$id = substr(strrchr($t2[0], "-"), 1);
	$title = str_between($video,'class="post">','<');
	$title = str_replace("u00e2","a",$title);
	$link="dolce_tv_link.php?id=".$id."&title=".urlencode($title);
	if( $id != '101' && $id != '107' && $id != '116' && $id != '134' && $id != '247') {
    if ($n == 0) echo "<TR>"."\n\r";
    echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
    $n++;
	$id_prog="";
	if (array_key_exists(strtolower(str_replace(" ","-",$title)), $a))
		$id_prog=$a[strtolower(str_replace(" ","-",$title))];
	echo '	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id='.$id_prog.'&title='.urlencode($title).'"><font size="4">PROG</font></a></TD>';
    $n++;
    if ($n > 5) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 //
}
}
if ($n<6) echo "</TR>"."\n\r";
 echo '</table>';
?>

<!-- *** DolceTV Sport *** -->
<?php
echo '<table border="2" width="100%">'."\n\r";
echo '<TR><td style="background-color:deepskyblue;color:black;text-align:center;" colspan="6"><font size="4"><b>DolceTV Sport</b></font></TD></TR>';
$n=0;
$link="http://sport.dolcetv.ro/tv-live?ajaxrequest=1";
#$link="http://www.dolcetv.ro/tv-live";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.dolcetv.ro");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
$html=str_replace("\\","",$html);
$videos = explode('<div class="station_program_cell', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    if ($n == 0) echo "<TR>"."\n\r";
	$t1 = explode('href="',$video);
	$t2 = explode('"',$t1[1]);
	$id = substr(strrchr($t2[0], "-"), 1);
	$title = str_between($video,'class="post">','<');
	$link="dolce_tv_link.php?id=".$id."&title=".$title;
    echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
    $n++;
	$id_prog="";
	if (array_key_exists(strtolower(str_replace(" ","-",$title)), $a))
		$id_prog=$a[strtolower(str_replace(" ","-",$title))];
	echo '	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id='.$id_prog.'&title='.urlencode($title).'"><font size="4">PROG</font></a></TD>';
    $n++;
    if ($n > 5) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }
 if ($n % 6 == 0)  {
//	echo '<TD></TD>';
 }
 if ($n<6) echo "</TR>"."\n\r";
 echo '</table>';
?>

<!--  *** DigiTV Sport *** -->
<table border="1px" width="100%">
<TR><td style="background-color:deepskyblue;color:black;text-align:center;" colspan="6"><font size="4"><b>DigiTV</b></font></TD></TR><TR>
<TR>
	<TD style="text-align:center"><font size="4"><a href="http://82.76.249.75:80/digiedge/digisport3mqlivehls/Digi%20Sport%203.m3u8">Digi Sport 3</a></font></TD>
    	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=<?php echo $a["digi sport 3"]; ?>&title=Digi+Sport+3"><font size="4">PROG</font></a></TD>
    <TD style="text-align:center"><font size="4"><a href="http://82.76.249.77:80/digi24edge/digi24hdhqhls/Digi%2024.m3u8">Digi 24</a></font></TD>
    	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=<?php echo $a["digi 24"]; ?>&title=Digi+24"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="http://82.76.249.77:80/digi24edge/digi24iasilivehls/Digi%2024%20Iasi.m3u8">Digi 24 Iasi</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=<?php echo $a["digi 24 iasi"]; ?>&title=Digi+24+Iasi"><font size="4">PROG</font></a></TD>
</TR>
<TR>
	<TD style="text-align:center"><font size="4"><a href="http://82.76.249.77:80/digi24edge/digi24craiovalive/Digi%2024%20Craiova.m3u8">Digi 24 Craiova</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=<?php echo $a["digi 24 craiova"]; ?>&title=Digi+24+Craiova"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="http://82.76.249.77:80/digi24edge/digi24constantalivehls/Digi%2024%20Constanta.m3u8">Digi 24 Constanta</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=<?php echo $a["digi 24 constanta"]; ?>&title=Digi+24+Constanta"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="http://82.76.249.77:80/digi24edge/digi24oradealivehls/Digi%2024%20Oradea.m3u8">Digi 24 Oradea</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=<?php echo $a["digi 24 oradea"]; ?>&title=Digi+24+Oradea"><font size="4">PROG</font></a></TD>
</TR>
<TR>
	<TD style="text-align:center"><font size="4"><a href="http://82.76.249.77:80/digi24edge/digi24timislivehls/Digi%2024%20Timisoara.m3u8">Digi 24 Timisoara</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=<?php echo $a["digi 24 timisoara"]; ?>&title=Digi+24+Timisoara"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="http://82.76.249.75:80/digiedge/digisport1livehls/Digi%20Sport%201.m3u8">Digi Sport 1</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=<?php echo $a["digi sport 1"]; ?>&title=Digi+Sport+1"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="http://82.76.249.75:80/digiedge/digisport2livehls/Digi%20Sport%202.m3u8">Digi Sport 2</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=<?php echo $a["digi sport 2"]; ?>&title=Digi+Sport+2"><font size="4">PROG</font></a></TD>
</TR>
</TABLE>

<!--  *** Seenow TV *** -->
<table border="2" width="100%">

<TR><td style="background-color:deepskyblue;color:black;text-align:center;" colspan="6"><font size="4"><b>Seenow TV</b></font></TD></TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6850&title=Alfa+Omega+TV" target="_blank">Alfa Omega TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10137&title=Alfa+Omega+TV"><font size="4">PROG</font></a></TD>
	<!--TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=103&title=Antena+3" target="_blank">Antena 3</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10055&title=Antena+3"><font size="4">PROG</font></a></TD -->
	<TD style="text-align:center;"><font size="4"><a href="seenow_tv_link.php?id=82730&title=Digi+24" target="_blank">Digi 24</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10282&title=Digi+24"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=107&title=B1+TV" target="_blank">B1 TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10022&title=B1+TV"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7492&title=Boomerang" target="_blank">Boomerang</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10081&title=Boomerang"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=110&title=CNN" target="_blank">CNN</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10115&title=CNN"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7508&title=Cartoon+Network" target="_blank">Cartoon Network</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10053&title=Cartoon+Network"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=9435&title=Comedy+Central" target="_blank">Comedy Central</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10270&title=Comedy+Central"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=502&title=Deutsche+Welle" target="_blank">Deutsche Welle</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10131&title=Deutsche+Welle"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7460&title=Disney+Channel" target="_blank">Disney Channel</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10018&title=Disney+Channel"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7461&title=Disney+Junior" target="_blank">Disney Junior</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10263&title=Disney+Junior"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7948&title=Docu+Box" target="_blank">Docu Box</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=&title=Docu+Box"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=8070&title=Dolce+Sport+HD" target="_blank">Dolce Sport HD</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10281&title=Dolce+Sport+HD"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=130&title=Etno+TV" target="_blank">Etno TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10037&title=Etno+TV"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7957&title=Fashion+Box" target="_blank">Fashion Box</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=&title=Fashion+Box"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=113&title=Fashion+TV" target="_blank">Fashion TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10078&title=Fashion+TV"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=131&title=Favorit+TV" target="_blank">Favorit TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10071&title=Favorit+TV"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7952&title=FightBox" target="_blank">FightBox</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=&title=FightBox"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7463&title=FilmBox" target="_blank">FilmBox</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10236&title=FilmBox"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7466&title=FilmBox+Family" target="_blank">FilmBox Family</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10238&title=FilmBox+Family"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7467&title=FilmBox+HD" target="_blank">FilmBox HD</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10239&title=FilmBox+HD"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7462&title=FilmBox+Plus" target="_blank">FilmBox Plus</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10237&title=FilmBox+Plus"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6846&title=France+24" target="_blank">France 24</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10128&title=France+24"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=112&title=GIGA+TV" target="_blank">GIGA TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10249&title=GIGA+TV"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7505&title=H!T+Music+Channel" target="_blank">H!T Music Channel</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10299&title=H!T+Music+Channel"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7747&title=Inedit+TV" target="_blank">Inedit TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10300&title=Inedit+TV"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=109&title=Kanal+D" target="_blank">Kanal D</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10097&title=Kanal+D"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=121&title=Kiss+TV" target="_blank">Kiss TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10008&title=Kiss+TV"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=60793&title=Money" target="_blank">Money</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=&title=Money"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6849&title=Music+Channel" target="_blank">Music Channel</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10158&title=Music+Channel"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=133&title=Mynele+TV" target="_blank">Mynele TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10206&title=Mynele+TV"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=111&title=Nasul+TV" target="_blank">Nasul TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10256&title=Nasul+TV"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=117&title=National+24+Plus" target="_blank">National 24 Plus</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10048&title=National+24+Plus"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=116&title=National+TV" target="_blank">National TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10031&title=National+TV"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6847&title=Neptun+TV" target="_blank">Neptun TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10151&title=Neptun+TV"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=9088&title=Nick+Jr" target="_blank">Nick Jr</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=&title=Nick+Jr"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7503&title=Nickelodeon" target="_blank">Nickelodeon</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10110&title=Nickelodeon"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6830&title=OTV" target="_blank">OTV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=&title=OTV"><font size="4">PROG</font></a></TD>
	<!--TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=134&title=Party" target="_blank">Party</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=&title=Party"><font size="4">PROG</font></a></TD -->
	<TD style="text-align:center;"><font size="4"><a href="seenow_tv_link.php?id=85225&title=Tvh" target="_blank">Tvh</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10029&title=Tvh"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=105&title=România+TV" target="_blank">România TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10245&title=România+TV"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=104&title=Realitatea+TV" target="_blank">Realitatea TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10019&title=Realitatea+TV"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=128&title=AGRO+TV" target="_blank">AGRO TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10304&title=AGRO+TV"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6675&title=Speranta+TV" target="_blank">Speranta TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10134&title=Speranta+TV"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=7496&title=TCM" target="_blank">TCM</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10054&title=TCM"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=119&title=TV+City" target="_blank">TV City</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10258&title=TV+City"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6848&title=TV5" target="_blank">TV5</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10041&title=TV5"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6855&title=TVR+1" target="_blank">TVR 1</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10001&title=TVR+1"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6856&title=TVR+2" target="_blank">TVR 2</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10002&title=TVR+2"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6857&title=TVR+3" target="_blank">TVR 3</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10167&title=TVR+3"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6858&title=TVR+Cluj" target="_blank">TVR Cluj</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10153&title=TVR+Cluj"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6862&title=TVR+Craiova" target="_blank">TVR Craiova</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10219&title=TVR+Craiova"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6860&title=TVR+Iaşi" target="_blank">TVR Iaşi</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10154&title=TVR+Iaşi"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=108&title=TVR+International" target="_blank">TVR International</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10015&title=TVR+International"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6854&title=TVR+News" target="_blank">TVR News</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10174&title=TVR+News"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6859&title=TVR+Tîrgu-Mureş" target="_blank">TVR Tîrgu-Mureş</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10221&title=TVR+Tîrgu-Mureş"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6861&title=TVR+Timişoara" target="_blank">TVR Timişoara</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10220&title=TVR+Timişoara"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=132&title=Taraf+TV" target="_blank">Taraf TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10101&title=Taraf+TV"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=127&title=Transilvania+L!VE" target="_blank">Transilvania L!VE</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10217&title=Transilvania+L!VE"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<!-- TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=126&title=Transilvania+Look" target="_blank">Transilvania Look</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=&title=Transilvania+Look"><font size="4">PROG</font></a></TD -->
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6852&title=Travel+Channel" target="_blank">Travel Channel</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10086&title=Travel+Channel"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=114&title=Travel+Mix" target="_blank">Travel Mix</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10231&title=Travel+Mix"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center;"><font size="4"><a href="seenow_tv_link.php?id=85219&title=Credo TV" target="_blank">Credo TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10223&title=Credo+TV"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=120&title=Trinitas+TV" target="_blank">Trinitas TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10145&title=Trinitas+TV"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=122&title=U+TV" target="_blank">U TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10096&title=U+TV"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=129&title=Valea+Prahovei+TV" target="_blank">Valea Prahovei TV</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10214&title=Valea+Prahovei+TV"><font size="4">PROG</font></a></TD>
</TR>

<TR>

	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6313&title=Viasat+Explorer" target="_blank">Viasat Explorer</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10039&title=Viasat+Explorer"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6314&title=Viasat+History" target="_blank">Viasat History</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10040&title=Viasat+History"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center"><font size="4"><a href="seenow_tv_link.php?id=6315&title=Viasat+Nature" target="_blank">Viasat Nature</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10207&title=Viasat+Nature"><font size="4">PROG</font></a></TD>

</TR>

<TR>

	<TD style="text-align:center;"><font size="4"><a href="seenow_tv_link.php?id=10665&title=TV+1000" target="_blank">TV 1000</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10060&title=TV+1000"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center;"><font size="4"><a href="seenow_tv_link.php?id=11144&title=AXN" target="_blank">AXN</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10033&title=AXN"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center;"><font size="4"><a href="seenow_tv_link.php?id=11148&title=AXN Black" target="_blank">AXN Black</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10072&title=AXN+Black"><font size="4">PROG</font></a></TD>

</TR>

<TR>

	<TD style="text-align:center;"><font size="4"><a href="seenow_tv_link.php?id=11145&title=AXN White" target="_blank">AXN White</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10073&title=AXN+White"><font size="4">PROG</font></a></TD>
	<TD style="text-align:center;"><font size="4"><a href="seenow_tv_link.php?id=11147&title=AXN Spin" target="_blank">AXN Spin</a></font></TD>
	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id=10298&title=AXN+Spin"><font size="4">PROG</font></a></TD>
	<TD></TD>
	<td></TD>
</TR>

</TR>

</table>
</body>
</html>
