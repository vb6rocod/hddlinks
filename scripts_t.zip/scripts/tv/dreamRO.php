<!DOCTYPE html>
<?php
include ("../common.php");
$link=urldecode($_GET["link"]);
$title=urldecode($_GET["title"]);
//$l=$_GET["base"];
?>
<html>



   <head>

      <meta charset="utf-8">
      <title><?php echo $title; ?></title>
      <link rel="stylesheet" type="text/css" href="../custom.css" />
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <script type="text/javascript" src="func.js"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
    function myFunc(url2) {
         msg = 'dreamRO_link.php?link=' + url2 + '&serv=' + document.getElementById('menu').value;
         window.open(msg);
    }
</script>
<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer

function ajaxrequest1(link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'menu='+ document.getElementById('menu').value;
  var php_file='dream_opt.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
    }
  }
}
</script>

<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
 $("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
  </head>
   <body>
<h2 style="background-color:deepskyblue;color:black;;text-align:center"><?php echo $title; ?></H2>
<?php
$dream_serv="http://hddlinks.netai.net/dream.srt";
$hserv=file_get_contents($dream_serv);
$serv=explode("\n",$hserv);
$nn=count($serv);
echo '<p>Alegeti unul din servere: <select name="menu" id="menu">';
for ($k=0;$k<$nn-1;$k=$k+2) {
$n=$k/2;
if ($serv[$k+1]==$opt_serv)
 echo '<option value="'.trim($serv[$k+1]).'" selected>'.trim($serv[$k]).'</option>';
else
 echo '<option value="'.trim($serv[$k+1]).'">'.trim($serv[$k]).'</option>';
}
echo '</select>';
//echo '<input type="submit" value="Memoreaza optiunile" onclick="ajaxrequest1()";>';
?>
<table border="1px" width="100%">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
$link=str_replace('\"','"',$link);
$link="http://hdforall3.strangled.net/ajax/channels?id=".urlencode($link);
//echo $link;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html = curl_exec($ch);
  curl_close($ch);
//echo $html;
$n=0;
$videos = explode('<div class="channel_right">', $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
    $link=trim(str_between($video,"open_epg_pop('","'"));
    $title=trim(str_between($video,'name=',"'"));
    //$link="dreamRO_link.php?link=".urlencode($link);
    $title1=strtolower($title);
    $title1=str_replace(" ro","",$title1);
    $title1=str_replace(" ","-",$title1);
    if ($title <> "") {
    if ($n == 0) echo "<TR>"."\n\r";
    echo '<TD style="text-align:center"><font size="4">'.'<a href="javascript:myFunc(\''.urlencode($link).'\');">'.$title.'</a></font></TD>';
    $n++;
   	echo '	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id='.$title1.'&title='.urlencode($title).'"><font size="4">PROG</font></a></TD>';
    $n++;
    if ($n > 5) {
     echo '</TR>'."\n\r";
     $n=0;
    }
  }
}
if ($n<6) echo "</TR>"."\n\r";
 echo '</table>';
?>
<a href="javascript:document.getElementById('menu').value + '/ajax/epgpop?sref=1%3A0%3A1%3A76C2%3A2C0%3A600%3AE080000%3A0%3A0%3A0%3A';><font size="4">
</body>
</html>
