<?php

function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$id=$_GET["link"];
$title=urldecode($_GET["title"]);
//$out=str_replace("playlist/","play/",$out);
$out=$out="http://heand.dns04.com:9981/".$id."";
if (strpos($base_pass,":") === false) {
header('Content-type: application/vnd.apple.mpegURL');
//header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} else {
$out=str_replace("&amp;","&",$out);
echo '
<html>
   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
      <title>'.$title.'</title>
   </head>
<body>

<embed type="application/x-vlc-plugin" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2"
width="100%"
height="100%"
id="vlc"
autoplay="yes"
target="'.$out.'">
</embed>



    <script language="Javascript">

    var vlc = document.getElementById("vlc");
    vlc.audio.toggleMute();
    vlc.subtitle.track="1";

    </script>





    </body>
    </html>
';
}
?>
