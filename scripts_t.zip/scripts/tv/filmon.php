<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />

      <meta charset="utf-8">
      <title>Filmon TV</title>
<body>
<table border="1" width="100%">

<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="3"><font size="4"><b>Filmon</b></font></TR>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie=$base_cookie."filmon.dat";
$l="http://www.filmon.com/tv/htmlmain";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 2.1-update1; ru-ru; GT-I9000 Build/ECLAIR) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Mobile Safari/530.17');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
//$p=json_decode($h,true);
//print_r($p);
$h=str_between($h,'var groups = [','if(!$.isArray(groups)){');
//echo $h;
//die();

$t1=explode('],"channels_count',$h);
$c=count($t1);

//print_r($p);
for ($i=0;$i<$c-1;$i++) {
$t2=explode('{"group_id":"',$t1[$i]);
//echo $t1[0];
$l='{"group_id":"'.$t2[1].'],"channels_count":28}];';
//$l = utf8_encode($l);
//$p=json_decode($l,true);
//print_r($p);
  //$desc=$p[title];
  $desc=str_between($l,'title":"','"');
  if (!preg_match("/LOCAL TV/",$desc)) {
  $n=0;
  echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="3"><font size="4">'.$desc.'</font></TD></TR>';
  $a1=explode('{"id":',$l);
  $k=count($a1);
  for ($j=1;$j<$k;$j++) {
//print_r($p);
  //$id=$p[channels][$j][id];
  $a2=explode('"',$a1[$j]);
  $id=$a2[0];
  $title=str_between($a1[$j],'"title":"','"');
  //$title=json_decode($title);
  //$title=$p[channels][$j][title];
    $link="filmon_link.php?file=".$id;
    if ($n == 0) echo "<TR>"."\n\r";
    echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
    echo '</TD>'."\n\r";
    $n++;
    if ($n > 2) {
     echo '</TR>'."\n\r";
     $n=0;
    }

}
if ($n<3) echo "</TR>"."\n\r";
}
}

?>
</table>
<br></body>
</html>
