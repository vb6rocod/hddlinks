<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />

      <meta charset="utf-8">
      <title>Filmon TV</title>
<body>
<table border="1" width="100%">

<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="3"><font size="4"><b>Filmon</b></font></TR>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie=$base_cookie."filmon.dat";
$l="http://www.filmon.com/tv/htmlmain";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 2.1-update1; ru-ru; GT-I9000 Build/ECLAIR) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Mobile Safari/530.17');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
$last_gr="";
$n=0;
$a=false;
$desc="";
    $videos = explode('"id":',$h);
    unset($videos[0]);
    $videos = array_values($videos);
    foreach($videos as $video) {
     //echo $video;
     $t1=explode('title":"',$video);
     $t2=explode('"',$t1[1]);
     $title=trim($t2[0]);
     $t1=explode('group":"',$video);
 if (sizeof ($t1) > 1 ) {
     $t2=explode('"',$t1[1]);
     $desc=$t2[0];
}
     if ($desc=="FOOD AND WINE") $a=true;
     if ($desc != $last_gr && $desc <> "" && $a) {
       if ($n>0) echo "</TR>"."\n\r";
       echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="3"><font size="4">'.$desc.'</font></TD></TR>';
       $n=0;
       $last_gr=$desc;
       }
     //$title=$title." (".$desc.")";
     //$t1=explode('id="',$video);
     $t2=explode(',',$video);
     $id=trim($t2[0]);

     if (($id <> "") && ($title <> "") && (strpos($video,'is_free_sd_mode":true') !== false) && (strpos($title,"featured") === false) && $a) {
      $link="filmon_link.php?file=".$id;
    if ($n == 0) echo "<TR>"."\n\r";
    echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
    echo '</TD>'."\n\r";
    $n++;
    if ($n > 2) {
     echo '</TR>'."\n\r";
     $n=0;
    }
     }
    }
if ($n<3) echo "</TR>"."\n\r";
?>
</table>
<br></body>
</html>
