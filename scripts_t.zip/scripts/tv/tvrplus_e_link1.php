<?php
$id = $_GET["file"];
$title = urldecode($_GET["title"]);
include ("../common.php");
if ( is_numeric($id) ) {
$l="http://www.seenow.ro/service3/play/index/id/".$id."/platform_id/24";
$h=file_get_contents($l);
$p=json_decode($h,1);
//print_r ($p);
$l=$p["streamUrl"];
$svr=$p["indexUrl"];
$sub=$p["subtitles"];
$title = preg_replace('~[^\\pL\d.]+~u', ' ', $title);
$srt_name=$title.".srt";
$movie_file=$title.".m3u8";
$h=file_get_contents($svr);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0];
$out=str_replace("[%server_name%]",$serv,$l);
$out=str_replace("playlist",$title,$out);

   unlink($base_sub.$srt_name);

   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $sub);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);
if ($h) {
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
   $new_file = $base_sub.$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h);
   fclose($fh);
}
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} else {
/** 
$l="http://index.mediadirect.ro:80/getUrl?app=radio&file=".$id.".stream&publisher=17";
$h=file_get_contents($l);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0]; **/
$serv="178.21.120.26";
//rtmp://178.21.120.26:1935/radio/_definst_/r3n.stream
$out="rtmp://".$serv.":1935/radio/_definst_/";
//$out="http://".$serv.":1935/radio/_definst_/".$id."/playlist.m3u8";
echo '
<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <title>'.$title.'</title>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript" src="../filme/jwplayer.js"></script>
</head>
<body>
<H2>'.$title.'</H2>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"skin": "../skin.zip",
"players": [{"type":"flash","src":"../filme/player.swf"}],
"provider": "rtmp",
"streamer": "rtmp://178.21.120.26:1935/radio/_definst_",
"file": "'.$id.'.stream",
"autostart": "true",
"volume": "100",
"height": "50",
"width": "400"
});
</script>
</body></html>
';
}
//echo $out;
//die();

?>
