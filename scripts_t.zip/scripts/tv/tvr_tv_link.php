<?php
$id = $_GET["id"];
$title = urldecode($_GET["title"]);
$s="http://index.mediadirect.ro/getUrl?publisher=2";
$h = file_get_contents($s);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0];
$link="http://www.tvrplus.ro/androidphone/show/live/id/".$id;
$html = file_get_contents($link);
$html=str_replace("\\","",$html);
$t1=explode('high quality stream name":"',$html);
$t2=explode('"',$t1[1]);
$str=$t2[0];
$t1=explode('token-high":"',$html);
$t2=explode('"',$t1[1]);
$token=$t2[0];
$out = "http://".$serv.":1937/live3/_definst_/".$str."/".$title.".m3u8?token=".$token;
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
?>
