<?php
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$id = $_GET["id"];
$title = urldecode($_GET["title"]);
$PHP_SELF="";
$s="http://index.mediadirect.ro/getUrl?publisher=2";
$h = file_get_contents($s);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0];
$link="http://www.dolcetv.ro/service/play/index/id/".$id."/category/0/type/live-tv/editionId/0/module_name/androidtablet";
$html = file_get_contents($link);
$html=str_replace("\\","",$html);
$t1=explode('high quality stream name":"',$html);
$t2=explode('"',$t1[1]);
$str=$t2[0];
$t1=explode('token-high":"',$html);
$t2=explode('"',$t1[1]);
$token=$t2[0];

if ($serv == "") {
  $serv="fms1.mediadirect.ro";
}

if ($flash == "direct") {
$out = "http://".$serv.":1937/live3/_definst_/".$str."/".$title.".m3u8?token=".$token;
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} else {
$app="live3";
$rtmp="rtmpe://".$serv."/".$app."/_definst_?token=".$token;

echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="../filme/jwplayer.js"></script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"players": [{"type":"flash","src":"../filme/player.swf"}],
"file": "'.$str.'",
"token": "'.$token.'",
"height": $(document).height(),
"width": $(document).width(),
"dock": "true",
"autostart": "true",
"controlbar.position": "over",
"controlbar.idlehide": "false",
"backcolor": "000000",
"frontcolor": "ffffff",
"lightcolor": "f7b01e",
"streamer": "'.$rtmp.'",
"volume": "100",
});
</script>
</BODY>
</HTML>
';
}
?>
