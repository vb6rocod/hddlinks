<?php
function rand_string( $length ) {
	$str = "";
	$characters = array_merge(range('a','f'), range('0','9'));
	$max = count($characters) - 1;
	for ($i = 0; $i < $length; $i++) {
		$rand = mt_rand(0, $max);
		$str .= $characters[$rand];
	}
 return $str;
}
function search_arr($array, $key, $value)
{
    $results = array();

    if (is_array($array)) {
        if (isset($array[$key]) && $array[$key] == $value) {
            $results[] = $array;
        }

        foreach ($array as $subarray) {
            $results = array_merge($results, search_arr($subarray, $key, $value));
        }
    }

    return $results;
}
$id = $_GET["file"];
$pg_id = $_GET["pg_id"];
$title = urldecode($_GET["title"]);
$sub="";
$token="";	
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if ( is_numeric($id) ) {
$l="http://www.seenow.ro/smarttv/placeholder/list/id/".$pg_id."/start/0/limit/24";
$h=file_get_contents($l);
$p=json_decode($h,1);
$items=$p['items'];
$items = array_values($items);

$willStartPlayingUrl = "http://www.seenow.ro/smarttv/historylist/add/id/".$id;
$h=search_arr($items, 'willStartPlayingUrl', $willStartPlayingUrl);

if (sizeof($h)>0) $p=$h[0];
  else  $p=$h;
if (array_key_exists("streamUrl",$p)) $l=$p["streamUrl"];
$t1=explode("token=",$l);
if (sizeof($t1)>1) {
$t2=explode('|',$t1[1]);
$token=$t2[0];
}
$t1=explode('|',$l);
$l=$t1[0];

if (!$p) {
$l="http://www.seenow.ro/service3/play/index/id/".$id."/platform_id/24";
$h=file_get_contents($l);
$p=json_decode($h,1);
}
//print_r ($p);
//die();
//$l=$p["streamUrl"];
$svr=$p["indexUrl"];
$str_name=$p["high quality stream name"];
if (!$token) {
$token=rand_string(48);
//$o=$p["other params"];
//$u=str_replace("&publisher=","&device_id=0&publisher=24",$o);
$u="user_id=0&transaction_id=0&p_item_id=".$id."&device_id=0&publisher=24";
$l="http://[%server_name%]:1937/seenow/_definst_/mp4:".$str_name."/playlist.m3u8?".$u."&token=".$token;
}
if (array_key_exists("subtitles",$p)) $sub=$p["subtitles"];
$title = preg_replace('~[^\\pL\d.]+~u', ' ', $title);
$srt_name=$title.".srt";
$movie_file=$title.".m3u8";
$h=file_get_contents($svr);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0];
if ($serv == "") {
  $serv="fms60.mediadirect.ro";
}
//$l="http://[%server_name%]:1937/seenow/_definst_/mp4:".$str_name."/playlist.m3u8?".$u."&token=".$token;
$out=str_replace("[%server_name%]",$serv,$l);
$out=str_replace("playlist",$title,$out);
$out=str_replace("seenow-smart/_definst_/","seenow/_definst_/mp4:",$out);

if (file_exists($base_sub.$srt_name)) unlink($base_sub.$srt_name);

   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $sub);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
   }
if ($h) {
   $new_file = $base_sub.$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h);
   fclose($fh);
}
} else {
/** 
$l="http://index.mediadirect.ro:80/getUrl?app=radio&file=".$id.".stream&publisher=17";
$h=file_get_contents($l);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0]; **/
$serv="178.21.120.26";
//rtmp://178.21.120.26:1935/radio/_definst_/r3n.stream
$out="rtmp://".$serv.":1935/radio/_definst_/".$id.".stream";
}
//if ( strpos($_SERVER['HTTP_USER_AGENT'],'Android') !== false ) {
if (strpos($base_pass,":") === false) {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} else {
echo '
<html>
   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
</style>
      <title>'.$title.'</title>
   </head>
<body>

<embed type="application/x-vlc-plugin" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2"
width="100%"
height="100%"
id="vlc"
target="'.$out.'">
</embed>


    <script language="Javascript">

    var vlc = document.getElementById("vlc");
    vlc.audio.toggleMute();
	vlc.video.aspectRatio="16:9";
    vlc.subtitle.track="1";


    </script>





    </body>
    </Html>
';
}
?>
