<!DOCTYPE html>
<?php
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page= $queryArr[0];
   $search = $queryArr[1];
   $tit = urldecode($queryArr[2]);
   $tit=str_replace("\\","",$tit);
   $page_title=$tit;
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <title><?php echo $tit; ?></title>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<h2 style="background-color:deepskyblue;color:black"><?php echo $tit; ?></h2>
<table border="1px" width="100%">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function xml_fix($string) {
    $v=str_replace("\u015e","S",$string);
    $v=str_replace("\u015f","s",$v);
    $v=str_replace("\u0163","t",$v);
    $v=str_replace("\u0162","T",$v);
    $v=str_replace("\u0103","a",$v);
    $v=str_replace("\u0102","A",$v);
    $v=str_replace("\u00a0"," ",$v);
    $v=str_replace("\u00e2","a",$v);
    $v=str_replace("\u021b","t",$v);
    $v=str_replace("\u201e","'",$v);
    $v=str_replace("\u201d","'",$v);
    $v=str_replace("\u0219","s",$v);
    $v=str_replace("\u00ee","i",$v);
    $v=str_replace("\u00ce","I",$v);
    $v=str_replace("\u2019","'",$v);
    $v=str_replace("\/","/",$v);
    return $v;
}
$search1=str_replace("&","|",$search);
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="tele-tv.php?page='.($page-1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="tele-tv.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="tele-tv.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

$link="http://www.tele-tv.info/pagini_e/".$search."/".$page;
//echo $link;
$html=file_get_contents($link);
$videos=explode('<div class="caseta_video">',$html);
unset($videos[0]);
$videos = array_values($videos);
$n=0;

foreach($videos as $video) {
    $t0=explode('class="caseta_video_titlu">',$video);
    $t1 = explode('href="', $t0[1]);
    $t2 = explode('"',$t1[1]);
    $link = $t2[0];

    $t3 = explode(">",$t0[1]);
    $t4 = explode("<",$t3[1]);
    $title=$t4[0];

    $t1 = explode('src="', $video);
    $t2 = explode('"', $t1[2]);
    $image = $t2[0];
  $link="tele-tv_link.php?file=".urlencode($link);
  if ($n==0) echo '<TR>';
echo '
<TD><table border="0px">
<TD align="center"><a href="'.$link.'" target="_blank"><img src="'.$image.'" width="171" height="96"></a><BR><a href="'.$link.'" target="_blank"><b>'.$title.'</b></a></TD>

</TABLE></TD>
';
$n++;
if ($n==4) {
echo '</TR>';
$n=0;
}
}
echo '</TABLE>';
?>
<br></body>
</html>
