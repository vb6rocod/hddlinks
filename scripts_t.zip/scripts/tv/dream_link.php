<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$id=$_GET["link"];
//$id="1:0:1:2AA8:1838:FBFF:820000:0:0:0:";
//$h=file_get_contents("http://fms3.dns04.com:1888/web/zap?sRef=http://fms3.dns04.com:8001/1:0:1:3644:C8:13E:820000:0:0:0:".$id."");
//1:0:1:2AA8:1838:FBFF:820000:0:0:0:
//http://csalami.dyndns.tv:8001/1:0:19:74CC:3F8:1:C00000:0:0:0:
$l="http://csalami.dyndns.tv/web/zap?sRef=http://csalami.dyndns.tv:8001/".$id;
//$h=file_get_contents("http://hdforall2.strangled.net/web/zap?sRef=http://hdforall1.strangled.net:8001/".$id."");
$h=file_get_contents($l);
//echo $h;
$a=trim(str_between($h,"http","</e2statetext>"));
$out="http".$a;
//echo $out1;
//die();
if ($a) {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} else {
die();
}
?>
